#![no_main]

//! Fuzz the basic no-panic streaming contract.
//!
//! The first byte toggles whether an explicit UTF-8 Content-Type is supplied;
//! the remaining bytes are fed as one chunk. The target accepts conversion
//! errors but rejects panics across charset detection, feed, and finalize.

use libfuzzer_sys::fuzz_target;
use nginx_markdown_converter::converter::ConversionOptions;
use nginx_markdown_converter::streaming::budget::MemoryBudget;
use nginx_markdown_converter::streaming::converter::StreamingConverter;

fuzz_target!(|data: &[u8]| {
    let (set_content_type, payload) = match data.split_first() {
        Some((flag, rest)) => ((flag & 1) == 0, rest),
        None => (true, data),
    };

    let mut conv = StreamingConverter::new(ConversionOptions::default(), MemoryBudget::default());
    if set_content_type {
        conv.set_content_type(Some("text/html; charset=UTF-8".to_string()));
    }

    let _ = conv.feed_chunk(payload);
    let _ = conv.finalize();
});
