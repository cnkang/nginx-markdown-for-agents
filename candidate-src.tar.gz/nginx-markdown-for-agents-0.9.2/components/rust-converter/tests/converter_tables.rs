//! Integration tests for HTML table to GFM Markdown table conversion.
//!
//! Tests cover:
//! - Basic table structure (headers + rows)
//! - Column alignment (left, center, right) via `<th>` style and `<col>` elements
//! - Edge cases: empty tables, single-column tables, mismatched column counts
//! - Tables without explicit `<thead>` (first `<tr>` used as header)
//! - Inline Markdown within table cells (links, emphasis, code)
//! - CommonMark fallback (tables traversed as inline content when GFM is off)

use nginx_markdown_converter::converter::{ConversionOptions, MarkdownConverter, MarkdownFlavor};
use nginx_markdown_converter::parser::parse_html;

fn convert_table_html(html: &[u8], flavor: MarkdownFlavor) -> String {
    convert_table_html_with_options(
        html,
        ConversionOptions {
            flavor,
            ..Default::default()
        },
    )
}

fn convert_table_html_with_options(html: &[u8], options: ConversionOptions) -> String {
    let dom = parse_html(html).expect("Parse failed");
    let converter = MarkdownConverter::with_options(options);

    converter.convert(&dom).expect("Conversion failed")
}

/// Verifies basic GFM table layout with headers and a data row.
#[test]
fn table_should_convert_basic_gfm_layout() {
    let result = convert_table_html(
        b"<table><thead><tr><th>Header 1</th><th>Header 2</th></tr></thead><tbody><tr><td>Cell 1</td><td>Cell 2</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| Header 1 | Header 2 |"));
    assert!(result.contains("| --- | --- |"));
    assert!(result.contains("| Cell 1 | Cell 2 |"));
}

/// Confirms that CommonMark mode falls back to plain text instead of emitting
/// GFM table syntax.
#[test]
fn table_should_fall_back_to_text_in_commonmark_mode() {
    let result = convert_table_html(
        b"<table><thead><tr><th>Header</th></tr></thead><tbody><tr><td>Cell</td></tr></tbody></table>",
        MarkdownFlavor::CommonMark,
    );

    assert!(!result.contains("|"));
    assert!(result.contains("Header"));
    assert!(result.contains("Cell"));
}

/// Verifies that left alignment via the `align` attribute produces the correct
/// GFM separator row.
#[test]
fn table_should_emit_left_alignment_separator() {
    let result = convert_table_html(
        b"<table><thead><tr><th align=\"left\">Left</th></tr></thead><tbody><tr><td>Data</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| --- |"));
    assert!(result.contains("| Left |"));
}

/// Verifies that center alignment via the `align` attribute produces the correct
/// GFM separator row with colons on both sides.
#[test]
fn table_should_emit_center_alignment_separator() {
    let result = convert_table_html(
        b"<table><thead><tr><th align=\"center\">Center</th></tr></thead><tbody><tr><td>Data</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| :---: |"));
    assert!(result.contains("| Center |"));
}

/// Verifies that right alignment via the `align` attribute produces the correct
/// GFM separator row with a trailing colon.
#[test]
fn table_should_emit_right_alignment_separator() {
    let result = convert_table_html(
        b"<table><thead><tr><th align=\"right\">Right</th></tr></thead><tbody><tr><td>Data</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| ---: |"));
    assert!(result.contains("| Right |"));
}

/// Verifies that mixed column alignments (left, center, right) are preserved
/// correctly in the GFM separator row.
#[test]
fn table_should_preserve_mixed_alignments() {
    let result = convert_table_html(
        b"<table><thead><tr><th align=\"left\">Left</th><th align=\"center\">Center</th><th align=\"right\">Right</th></tr></thead><tbody><tr><td>A</td><td>B</td><td>C</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| --- | :---: | ---: |"));
    assert!(result.contains("| Left | Center | Right |"));
    assert!(result.contains("| A | B | C |"));
}

/// Verifies that CSS `text-align` style attributes on `<th>` elements are
/// detected and used for column alignment.
#[test]
fn table_should_detect_style_based_alignment() {
    let result = convert_table_html(
        b"<table><thead><tr><th style=\"text-align: center\">Styled</th></tr></thead><tbody><tr><td>Data</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| :---: |"));
}

/// Verifies that tables without an explicit `<thead>` element still convert
/// correctly, using the first `<tr>` as the header row.
#[test]
fn table_should_convert_without_thead() {
    let result = convert_table_html(
        b"<table><tr><th>Header 1</th><th>Header 2</th></tr><tr><td>Cell 1</td><td>Cell 2</td></tr></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| Header 1 | Header 2 |"));
    assert!(result.contains("| --- | --- |"));
    assert!(result.contains("| Cell 1 | Cell 2 |"));
}

/// Verifies that multiple data rows are all included in the table output.
#[test]
fn table_should_include_multiple_rows() {
    let result = convert_table_html(
        b"<table><thead><tr><th>Name</th><th>Age</th></tr></thead><tbody><tr><td>Alice</td><td>30</td></tr><tr><td>Bob</td><td>25</td></tr><tr><td>Charlie</td><td>35</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| Name | Age |"));
    assert!(result.contains("| Alice | 30 |"));
    assert!(result.contains("| Bob | 25 |"));
    assert!(result.contains("| Charlie | 35 |"));
}

/// Verifies that empty table cells are preserved as empty pipe-delimited fields.
#[test]
fn table_should_preserve_empty_cells() {
    let result = convert_table_html(
        b"<table><thead><tr><th>Col1</th><th>Col2</th></tr></thead><tbody><tr><td>Data</td><td></td></tr><tr><td></td><td>Data</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| Col1 | Col2 |"));
    assert!(result.contains("| Data | |"));
    assert!(result.contains("| | Data |"));
}

/// Verifies that rows with fewer columns than the header are padded with empty
/// cells to maintain consistent column count.
#[test]
fn table_should_pad_uneven_rows() {
    let result = convert_table_html(
        b"<table><thead><tr><th>A</th><th>B</th><th>C</th></tr></thead><tbody><tr><td>1</td><td>2</td></tr><tr><td>3</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| A | B | C |"));
    assert!(result.contains("| 1 | 2 | |"));
    assert!(result.contains("| 3 | | |"));
}

/// Verifies that inline Markdown formatting (bold, italic) inside table cells
/// is preserved in the output.
#[test]
fn table_should_preserve_inline_formatting() {
    let result = convert_table_html(
        b"<table><thead><tr><th>Name</th><th>Status</th></tr></thead><tbody><tr><td><strong>Bold</strong></td><td><em>Italic</em></td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| Name | Status |"));
    assert!(result.contains("| **Bold** | *Italic* |"));
}

/// Verifies that Markdown links inside table cells are preserved correctly.
#[test]
fn table_should_preserve_links() {
    let result = convert_table_html(
        b"<table><thead><tr><th>Site</th></tr></thead><tbody><tr><td><a href=\"https://example.com\">Example</a></td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| Site |"));
    assert!(result.contains("| [Example](https://example.com) |"));
}

/// Verifies that inline code spans inside table cells are preserved correctly.
#[test]
fn table_should_preserve_inline_code() {
    let result = convert_table_html(
        b"<table><thead><tr><th>Function</th></tr></thead><tbody><tr><td><code>print()</code></td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| Function |"));
    assert!(result.contains("| `print()` |"));
}

/// Verifies that blank lines are emitted before and after the table block to
/// satisfy Markdown block element separation requirements.
#[test]
fn table_should_keep_blank_lines_around_block() {
    let result = convert_table_html(
        b"<p>Before table</p><table><thead><tr><th>Header</th></tr></thead><tbody><tr><td>Data</td></tr></tbody></table><p>After table</p>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("Before table\n\n|"));
    assert!(result.contains("|\n\nAfter table"));
}

/// Verifies that a table with only a `<thead>` (no `<tbody>`) renders correctly.
#[test]
fn table_should_render_thead_only_tables() {
    let result = convert_table_html(
        b"<table><thead><tr><th>Header</th></tr></thead></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| Header |"));
    assert!(result.contains("| --- |"));
}

/// Verifies that a table with `<td>` elements in the first row (no `<th>`)
/// still treats that row as the header.
#[test]
fn table_should_treat_first_td_row_as_header() {
    let result = convert_table_html(
        b"<table><tr><td>Header 1</td><td>Header 2</td></tr><tr><td>Cell 1</td><td>Cell 2</td></tr></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| Header 1 | Header 2 |"));
    assert!(result.contains("| --- | --- |"));
    assert!(result.contains("| Cell 1 | Cell 2 |"));
}

/// Verifies that an empty `<table></table>` element produces no Markdown output.
#[test]
fn table_should_skip_empty_table_markup() {
    let result = convert_table_html(b"<table></table>", MarkdownFlavor::GitHubFlavoredMarkdown);

    assert!(!result.contains("|"));
}

/// Verifies that leading/trailing whitespace in table cells is normalized and
/// internal multi-space runs are collapsed to single spaces.
#[test]
fn table_should_normalize_cell_whitespace() {
    let result = convert_table_html(
        b"<table><thead><tr><th>  Header  </th></tr></thead><tbody><tr><td>  Data  with   spaces  </td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| Header |"));
    assert!(result.contains("| Data with spaces |"));
}

/// Verifies that when `preserve_tables` is disabled, table content is flattened
/// to plain text without pipe-delimited table syntax.
#[test]
fn table_should_flatten_when_preserve_tables_is_disabled() {
    let result = convert_table_html_with_options(
        b"<table><thead><tr><th>Header</th></tr></thead><tbody><tr><td>Cell</td></tr></tbody></table>",
        ConversionOptions {
            flavor: MarkdownFlavor::GitHubFlavoredMarkdown,
            preserve_tables: false,
            ..Default::default()
        },
    );

    assert!(!result.contains("| Header |"));
    assert!(result.contains("Header"));
    assert!(result.contains("Cell"));
}

/// Verifies that non-`text-align` CSS properties in the `style` attribute are
/// ignored and do not affect column alignment.
#[test]
fn table_should_ignore_non_text_align_style_tokens() {
    let result = convert_table_html(
        b"<table><thead><tr><th style=\"padding-right: 10px\">Styled</th></tr></thead><tbody><tr><td>Data</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| --- |"));
    assert!(!result.contains("| ---: |"));
}

/// Verifies that pipe characters and newlines inside table cells are properly
/// escaped to prevent breaking the Markdown table structure.
#[test]
fn table_should_escape_cell_delimiters_and_newlines() {
    let result = convert_table_html(
        b"<table><thead><tr><th>A|B</th><th>C</th></tr></thead><tbody><tr><td>x|y</td><td>line1\nline2</td><td>extra</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(result.contains("| A\\|B | C |"));
    assert!(
        result.contains("| x\\|y | line1<br>line2 |") || result.contains("| x\\|y | line1 line2 |")
    );
}

#[test]
fn table_colgroup_col_alignment_with_align_attr() {
    // <colgroup>/<col> with align attribute should set column alignment.
    let result = convert_table_html(
        b"<table><colgroup><col align=\"left\"><col align=\"center\"><col align=\"right\"></colgroup><thead><tr><th>L</th><th>C</th><th>R</th></tr></thead><tbody><tr><td>1</td><td>2</td><td>3</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    // GFM: left alignment renders as "---" (no leading colon)
    assert!(
        result.contains("| --- | :---: | ---: |"),
        "expected colgroup align-driven alignment row, got: {result}"
    );
}

#[test]
fn table_colgroup_col_alignment_with_style() {
    // <colgroup>/<col> with style="text-align: ..." should also work.
    let result = convert_table_html(
        b"<table><colgroup><col style=\"text-align: left\"><col style=\"text-align: center\"><col style=\"text-align: right\"></colgroup><thead><tr><th>L</th><th>C</th><th>R</th></tr></thead><tbody><tr><td>1</td><td>2</td><td>3</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(
        result.contains("| --- | :---: | ---: |"),
        "expected colgroup style-driven alignment row, got: {result}"
    );
}

#[test]
fn table_colgroup_alignment_overrides_th_alignment() {
    // <colgroup> alignment should override <th> alignment.
    let result = convert_table_html(
        b"<table><colgroup><col align=\"right\"><col align=\"left\"></colgroup><thead><tr><th style=\"text-align: left\">A</th><th style=\"text-align: right\">B</th></tr></thead><tbody><tr><td>1</td><td>2</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    // col says right,left; th says left,right → col wins
    // GFM: left renders as "---", right as "---:"
    assert!(
        result.contains("| ---: | --- |"),
        "expected colgroup to override th alignment, got: {result}"
    );
}

#[test]
fn table_colgroup_bare_col_does_not_override_th_alignment() {
    let result = convert_table_html(
        b"<table><colgroup><col><col></colgroup><thead><tr><th style=\"text-align: right\">A</th><th>B</th></tr></thead><tbody><tr><td>1</td><td>2</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(
        result.contains("| ---: | --- |"),
        "expected bare colgroup columns to preserve th alignment, got: {result}"
    );
}

#[test]
fn table_colgroup_span_applies_alignment_to_multiple_columns() {
    let result = convert_table_html(
        b"<table><colgroup><col span=\"2\" align=\"center\"><col align=\"right\"></colgroup><thead><tr><th>A</th><th>B</th><th>C</th></tr></thead><tbody><tr><td>1</td><td>2</td><td>3</td></tr></tbody></table>",
        MarkdownFlavor::GitHubFlavoredMarkdown,
    );

    assert!(
        result.contains("| :---: | :---: | ---: |"),
        "expected col span to apply alignment to consecutive columns, got: {result}"
    );
}
