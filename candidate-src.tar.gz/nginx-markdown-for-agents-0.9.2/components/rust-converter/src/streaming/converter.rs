//! Streaming HTML-to-Markdown converter integration layer.
//!
//! [`StreamingConverter`] orchestrates all pipeline stages:
//! charset detection → tokenization → sanitization → state machine → emission,
//! plus incremental ETag hashing, token estimation, front matter extraction,
//! timeout checking, and commit state tracking.
//!
//! ## Commit state
//!
//! The converter operates in two phases: **pre-commit** (input is still being
//! fed and no output has been finalized) and **post-commit** (at least one
//! flush has produced output).  Once committed, errors become
//! [`PostCommitError`][crate::error::ConversionError::PostCommitError] and
//! the caller must decide whether to deliver the partial output or discard it.
//!
//! ## UTF-8 tail handling
//!
//! Incomplete UTF-8 byte sequences at chunk boundaries are buffered in
//! [`pending_utf8_tail`][StreamingConverter::pending_utf8_tail] and prepended
//! to the next chunk, ensuring multi-byte characters are never split across
//! `feed()` calls.
//!
//! ## Metadata extraction
//!
//! During the head-processing phase (before the first flush), the converter
//! extracts `<meta>` tags and canonical URL references.  These are projected
//! into the [`MarkdownMetadata`] FFI struct on [`finish`][StreamingConverter::finish].

use std::time::{Duration, Instant};

use crate::converter::ConversionOptions;
use crate::error::ConversionError;
use crate::ffi::clamp_chars_per_token;
use crate::metadata::PageMetadata;
use crate::security::SecurityValidator;
use crate::streaming::budget::MemoryBudget;
use crate::streaming::charset::CharsetState;
use crate::streaming::emitter::IncrementalEmitter;
use crate::streaming::sanitizer::{SanitizeDecision, StreamingSanitizer};
use crate::streaming::state_machine::{StateMachineAction, StructuralStateMachine};
use crate::streaming::tokenizer::{BudgetedStreamingTokenizer, TokenizerBatch};
use crate::streaming::types::{
    ChunkOutput, CommitState, FallbackReason, StreamEvent, StreamingResult, StreamingStats,
};

/// Streaming HTML-to-Markdown converter with bounded memory.
///
/// Processes HTML input in chunks via [`feed_chunk`](Self::feed_chunk) and
/// produces incremental Markdown output at block-level flush points. Call
/// [`finalize`](Self::finalize) after all input has been fed to obtain the
/// final result including ETag, token estimate, and statistics.
///
/// # Examples
///
/// ```no_run
/// use nginx_markdown_converter::converter::ConversionOptions;
/// use nginx_markdown_converter::streaming::budget::MemoryBudget;
/// use nginx_markdown_converter::streaming::converter::StreamingConverter;
///
/// let mut conv = StreamingConverter::new(ConversionOptions::default(), MemoryBudget::default());
/// conv.set_content_type(Some("text/html; charset=UTF-8".to_string()));
///
/// let output1 = conv.feed_chunk(b"<h1>Hello</h1>").unwrap();
/// let output2 = conv.feed_chunk(b"<p>World</p>").unwrap();
/// let result = conv.finalize().unwrap();
/// ```
pub struct StreamingConverter {
    /// Conversion options (reuses existing type).
    options: ConversionOptions,
    /// Memory budget for bounded-memory enforcement.
    budget: MemoryBudget,
    /// Charset detector / transcoder.
    charset_state: CharsetState,
    /// Persistent html5ever tokenizer with bounded input slices and token state.
    tokenizer: BudgetedStreamingTokenizer,
    /// Streaming security sanitizer.
    sanitizer: StreamingSanitizer,
    /// Structural state machine for document context tracking.
    state_machine: StructuralStateMachine,
    /// Incremental Markdown emitter.
    emitter: IncrementalEmitter,
    /// Incremental ETag hasher (optional, enabled when extract_metadata is set).
    etag_hasher: Option<blake3::Hasher>,
    /// Incremental token estimate: accumulated character count.
    /// The final token count is computed once in `finalize` as
    /// `ceil(total_markdown_chars / chars_per_token)` to match the
    /// configured `TokenEstimator` ratio.
    total_markdown_chars: u64,
    /// Characters-per-token ratio for token estimation.
    /// Defaults to 4.0 (English text); can be overridden via FFI
    /// options for CJK, code-heavy, or other LLM profiles.
    chars_per_token: f32,
    /// Commit state (PreCommit / PostCommit).
    commit_state: CommitState,
    /// Cooperative timeout deadline.
    deadline: Option<Instant>,
    /// Conversion statistics.
    stats: StreamingStats,
    /// Total bytes of Markdown emitted so far (for PostCommitError reporting).
    bytes_emitted: usize,
    /// Extracted page metadata from `<head>` region.
    metadata: PageMetadata,
    /// Whether we are currently collecting a `<title>` text.
    collecting_title: bool,
    /// Buffer for `<title>` element text (separate from metadata.title so
    /// that a social title set by og:title/twitter:title is not polluted
    /// by subsequent `<title>` text).
    html_title_buf: String,
    /// Whether a social title (og:title / twitter:title) has been set.
    /// When true, `<title>` text is collected but not written to
    /// `metadata.title` — the social title takes priority.
    social_title_set: bool,
    /// Whether the HTML `<title>` has already been written to metadata.
    /// Ensures first-`<title>`-wins semantics matching the full-buffer path.
    html_title_set: bool,
    /// Whether the first `<link rel="canonical" href="...">` (with an href)
    /// has been found. Once true, subsequent canonicals are ignored.
    /// Matches full-buffer `find_link_href_recursive` which skips canonicals
    /// without `href` and returns the first one that has it.
    canonical_found: bool,
    /// Bytes of `<head>` region processed so far (for lookahead budget enforcement).
    /// When this exceeds `budget.lookahead`, front matter extraction triggers
    /// an explicit fallback on budget exhaustion.
    head_bytes_seen: usize,
    /// Trailing bytes from the previous chunk that form an incomplete UTF-8
    /// sequence. Prepended to the next chunk before `String::from_utf8_lossy`
    /// so multibyte characters split across chunk boundaries are preserved.
    utf8_tail: Vec<u8>,
    /// Parser memory budget in bytes (0 = unlimited).
    /// Tracks cumulative input bytes fed to the converter and rejects when
    /// the total exceeds this limit. Uses input size as a proxy for parser
    /// memory pressure (matching the full-buffer path). Populated from the
    /// `markdown_limits parser_memory=` limit via FFI.
    parser_budget: u64,
    /// Cumulative input bytes fed to the converter (for parser budget enforcement).
    cumulative_input_bytes: u64,
    /// Whether a leading UTF-8 BOM (U+FEFF) has been checked/stripped from the
    /// first chunk.  The full-buffer path uses html5ever's `discard_bom: true`
    /// to strip a BOM at stream start; the streaming path sets `discard_bom:
    /// false` (to prevent mid-stream BOM stripping when a BOM's lead byte is
    /// split across chunks) and instead strips a leading BOM here, once.
    bom_stripped: bool,
    /// Estimated bytes held by the current transcoded output that is alive
    /// during tokenizer processing. When charset feed returns `Cow::Owned`,
    /// the full owned buffer persists while the tokenizer iterates over
    /// slices of it. This field tracks that resident allocation so
    /// `update_peak_memory()` can account for it in the total budget.
    charset_transcoded_bytes: usize,
    /// A rejected charset allocation plan is terminal for this converter so
    /// a later finalize call reports the original precommit error.
    charset_preflight_error: Option<ConversionError>,
}

impl StreamingConverter {
    /// Constructs a StreamingConverter configured for incremental HTML→Markdown conversion.
    ///
    /// # Arguments
    ///
    /// * `options` - ConversionOptions that control features such as metadata extraction, URL resolution, and other conversion behavior.
    /// * `budget` - MemoryBudget that bounds working-set usage of pipeline components during streaming processing.
    ///
    /// # Returns
    ///
    /// A new `StreamingConverter` initialized to accept input via `feed_chunk` and to be finalized with `finalize`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use nginx_markdown_converter::streaming::{StreamingConverter, MemoryBudget};
    /// use nginx_markdown_converter::converter::ConversionOptions;
    ///
    /// let options = ConversionOptions::default();
    /// let budget = MemoryBudget::default();
    /// let mut conv = StreamingConverter::new(options, budget);
    /// // send some bytes
    /// let _ = conv.feed_chunk(b"<p>Hello</p>").unwrap();
    /// let result = conv.finalize().unwrap();
    /// assert!(!result.final_markdown.is_empty());
    /// ```
    pub fn new(options: ConversionOptions, budget: MemoryBudget) -> Self {
        Self::with_chars_per_token(options, budget, 4.0)
    }

    /// Create a new streaming converter with a custom chars-per-token ratio.
    ///
    /// The `chars_per_token` parameter controls how many Markdown characters
    /// correspond to one estimated LLM token.  The final token count is
    /// computed in [`finalize`](Self::finalize) as
    /// `ceil(total_markdown_chars / chars_per_token)`.
    ///
    /// # Arguments
    ///
    /// * `options` - [`ConversionOptions`] controlling features such as
    ///   metadata extraction, URL resolution, and pruning.
    /// * `budget` - [`MemoryBudget`] bounding working-set usage of pipeline
    ///   components during streaming processing.
    /// * `chars_per_token` - Average characters per token for estimation.
    ///   Must be positive; non-positive values are clamped to 4.0.
    ///   Values outside `[1.0, 100.0]` are clamped to that range to avoid
    ///   pathological estimates.  Typical values: English text ≈ 4.0,
    ///   CJK text ≈ 1.5–2.0, code-heavy content ≈ 1.5–2.0.
    ///
    /// # Returns
    ///
    /// A new `StreamingConverter` initialized to accept input via
    /// [`feed_chunk`](Self::feed_chunk) and finalized with
    /// [`finalize`](Self::finalize).
    ///
    /// # Side Effects
    ///
    /// None.  The converter is fully constructed and ready for use.
    ///
    /// # See Also
    ///
    /// * [`new`](Self::new) — constructs with the default 4.0 chars/token ratio.
    /// * [`TokenEstimator::with_chars_per_token`](crate::token_estimator::TokenEstimator::with_chars_per_token) —
    ///   the full-buffer/incremental equivalent.
    pub fn with_chars_per_token(
        options: ConversionOptions,
        budget: MemoryBudget,
        chars_per_token: f32,
    ) -> Self {
        let etag_hasher = if options.extract_metadata {
            Some(blake3::Hasher::new())
        } else {
            None
        };
        let sanitizer = StreamingSanitizer::with_prune_config(options.prune_config.clone());
        Self {
            options,
            charset_state: CharsetState::with_sniff_limit(budget.charset_sniff),
            tokenizer: BudgetedStreamingTokenizer::new(budget.total),
            sanitizer,
            state_machine: StructuralStateMachine::new(&budget),
            emitter: IncrementalEmitter::new(&budget),
            budget,
            etag_hasher,
            total_markdown_chars: 0,
            chars_per_token: clamp_chars_per_token(chars_per_token),
            commit_state: CommitState::PreCommit,
            deadline: None,
            stats: StreamingStats::default(),
            bytes_emitted: 0,
            metadata: PageMetadata::new(),
            collecting_title: false,
            html_title_buf: String::new(),
            social_title_set: false,
            html_title_set: false,
            canonical_found: false,
            head_bytes_seen: 0,
            utf8_tail: Vec::new(),
            parser_budget: 0,
            cumulative_input_bytes: 0,
            bom_stripped: false,
            charset_transcoded_bytes: 0,
            charset_preflight_error: None,
        }
    }

    /// Provide an optional Content-Type header to the charset detector.
    ///
    /// Must be called before the first `feed_chunk` invocation. If the header
    /// includes a `charset` parameter, that charset takes precedence over any
    /// charset discovered via HTML meta tags.
    ///
    /// # Arguments
    ///
    /// * `content_type` - Optional Content-Type header value (for example
    ///   `"text/html; charset=UTF-8"`).
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use nginx_markdown_converter::streaming::StreamingConverter;
    ///
    /// let mut conv = StreamingConverter::new(Default::default(), Default::default());
    /// conv.set_content_type(Some("text/html; charset=UTF-8".to_string()));
    /// ```
    pub fn set_content_type(&mut self, content_type: Option<String>) {
        self.charset_state.set_content_type(content_type.as_deref());
    }

    /// Set a cooperative deadline for the conversion.
    ///
    /// The converter checks this deadline at the start of `feed_chunk` and `finalize`; if the
    /// deadline has passed those calls will return a timeout error. If adding `timeout` to the
    /// current instant would overflow, the deadline is left unset (treated as no deadline).
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use nginx_markdown_converter::streaming::StreamingConverter;
    /// use std::time::Duration;
    ///
    /// let mut conv = StreamingConverter::new(Default::default(), Default::default());
    /// // Limit the whole conversion to 2 seconds.
    /// conv.set_timeout(Duration::from_secs(2));
    /// ```
    pub fn set_timeout(&mut self, timeout: Duration) {
        // If Instant::now() + timeout overflows, treat as "no deadline"
        // (effectively infinite timeout) rather than setting an
        // already-passed deadline that would trigger immediate timeout.
        self.deadline = Instant::now().checked_add(timeout);
    }

    /// Set the flush threshold for the emitter.
    ///
    /// Controls the minimum number of accumulated Markdown bytes before the
    /// emitter flushes output at block boundaries. A threshold of 0 (the
    /// default) means "flush immediately at every block boundary" — lowest
    /// latency. Larger values batch output to reduce FFI round-trip overhead.
    ///
    /// # Arguments
    ///
    /// * `threshold` - Minimum pending bytes before flushing. 0 = immediate.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use nginx_markdown_converter::streaming::StreamingConverter;
    ///
    /// let mut conv = StreamingConverter::new(Default::default(), Default::default());
    /// conv.set_flush_threshold(512); // batch until at least 512 bytes accumulated
    /// ```
    pub fn set_flush_threshold(&mut self, threshold: usize) {
        self.emitter.set_flush_threshold(threshold);
    }

    /// Set the parser memory budget (cumulative input byte ceiling).
    ///
    /// When non-zero, the converter tracks cumulative input bytes across all
    /// `feed_chunk` calls. If the total exceeds this budget, `feed_chunk`
    /// returns [`ConversionError::ParseBudgetExceeded`]. A value of 0 (the
    /// default) disables this enforcement.
    ///
    /// This mirrors the full-buffer path's pre-check where input size is used
    /// as a proxy for parser memory pressure (html5ever does not expose
    /// internal memory tracking).
    ///
    /// # Arguments
    ///
    /// * `budget` - Maximum cumulative input bytes allowed, or 0 for unlimited.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use nginx_markdown_converter::streaming::StreamingConverter;
    ///
    /// let mut conv = StreamingConverter::new(Default::default(), Default::default());
    /// conv.set_parser_budget(64 * 1024 * 1024); // 64 MiB parser budget
    /// ```
    pub fn set_parser_budget(&mut self, budget: u64) {
        self.parser_budget = budget;
    }

    /// Process an incoming chunk of HTML bytes and return any ready Markdown output.
    ///
    /// This incrementally feeds the pipeline (charset detection/transcoding, tokenization,
    /// sanitization, structural analysis, and emission) and flushes complete block-level
    /// Markdown that became available as a result of this chunk.
    ///
    /// # Arguments
    ///
    /// * `data` - Raw HTML bytes in any text encoding; charset detection/transcoding is applied.
    ///
    /// # Returns
    ///
    /// `Ok(ChunkOutput)` containing the emitted Markdown bytes and the number of block-level
    /// flushes produced; or an appropriate `ConversionError` such as streaming fallback,
    /// budget/memory limits, timeout (pre-commit), or a post-commit error that includes
    /// bytes already emitted.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use nginx_markdown_converter::streaming::{StreamingConverter, MemoryBudget};
    /// use nginx_markdown_converter::converter::ConversionOptions;
    ///
    /// let options = ConversionOptions::default();
    /// let budget = MemoryBudget::default();
    /// let mut conv = StreamingConverter::new(options, budget);
    /// let out = conv.feed_chunk(b"<p>Hello</p>").unwrap();
    /// assert!(!out.markdown.is_empty());
    /// ```
    pub fn feed_chunk(&mut self, data: &[u8]) -> Result<ChunkOutput, ConversionError> {
        // 1. Check cooperative timeout
        self.check_timeout()?;

        if let Some(error) = self.charset_preflight_error.clone() {
            return Err(self.wrap_error(error));
        }

        // 1b. Parser budget enforcement (cumulative input size limit).
        // Track cumulative input bytes and reject when the total exceeds
        // the configured parser_budget. Uses input size as a proxy for
        // parser memory pressure (matching the full-buffer path).
        if self.parser_budget > 0 {
            self.cumulative_input_bytes = self
                .cumulative_input_bytes
                .saturating_add(data.len() as u64);
            if self.cumulative_input_bytes > self.parser_budget {
                let err = ConversionError::ParseBudgetExceeded {
                    used: self.cumulative_input_bytes as usize,
                    limit: self.parser_budget as usize,
                };
                return Err(self.wrap_error(err));
            }
        }

        // Noise-region pruning is supported at the
        // streaming tokenizer level via should_prune_with_config().
        // The pre-commit fallback is no longer needed when pruning
        // is enabled — pruned elements are simply skipped during
        // tokenization.  Remove the blanket fallback that was
        // required when streaming lacked pruning support.

        // 2. Charset detection / transcoding
        // CharsetState plans only allocations that this operation can add
        // while the current working set remains live.  That keeps explicit
        // UTF-8 feeds zero-copy while retaining a conservative preflight for
        // unresolved and non-UTF-8 states.
        let charset_allocation = match self.charset_state.feed_allocation_upper_bound(data.len()) {
            Ok(allocation) => allocation,
            Err(error) => {
                self.charset_preflight_error = Some(error.clone());
                return Err(self.wrap_error(error));
            }
        };
        if charset_allocation > 0 {
            let current_working_set = self.estimate_working_set();
            if let Err(error) = self
                .budget
                .check_total(current_working_set, charset_allocation)
            {
                self.charset_preflight_error = Some(error.clone());
                return Err(self.wrap_error(error));
            }
        }

        let transcoded = self
            .charset_state
            .feed(data)
            .map_err(|e| self.wrap_error(e))?;

        // Track the transcoded output size for working-set accounting.
        // Cow::Borrowed means zero-copy (UTF-8) — no additional allocation.
        // Cow::Owned means a heap allocation that persists while the
        // tokenizer processes slices of this output.
        self.charset_transcoded_bytes = match &transcoded {
            std::borrow::Cow::Borrowed(_) => 0,
            std::borrow::Cow::Owned(v) => v.capacity(),
        };

        // If charset is still pending (accumulating sniff buffer), no tokens yet
        if transcoded.is_empty() {
            self.stats.chunks_processed = self.stats.chunks_processed.saturating_add(1);
            return Ok(ChunkOutput {
                markdown: Vec::new(),
                flush_count: 0,
            });
        }

        let initial_flush_count = self.emitter.flush_count();
        self.process_utf8_bytes(transcoded.as_ref(), false)?;

        // 6. Collect flushed output
        let flushed = self.emitter.take_flushed();
        let flush_count = self
            .emitter
            .flush_count()
            .saturating_sub(initial_flush_count);

        // 7. Update ETag hasher and token count with flushed bytes
        self.update_incremental_stats(&flushed);

        // 8. Track CommitState transition
        if !flushed.is_empty() && matches!(self.commit_state, CommitState::PreCommit) {
            self.commit_state = CommitState::PostCommit;
        }

        self.stats.chunks_processed = self.stats.chunks_processed.saturating_add(1);

        // The transcoded output buffer is about to be dropped (it was
        // borrowed as Cow and the owned variant's Vec is freed when
        // `transcoded` goes out of scope at the end of this function).
        // Clear the accounting so subsequent peak-memory estimates
        // don't over-count a buffer that no longer exists.
        self.charset_transcoded_bytes = 0;

        Ok(ChunkOutput {
            markdown: flushed,
            flush_count,
        })
    }

    /// Finalize the streaming conversion and produce the final converted result.
    ///
    /// This method consumes the converter, flushes any pending pipeline state, auto-closes
    /// unclosed HTML contexts, finalizes metadata resolution, computes the final ETag and
    /// token estimate, and returns the accumulated conversion output and statistics.
    ///
    /// # Returns
    ///
    /// `StreamingResult` containing:
    /// - `final_markdown`: the remaining emitted Markdown bytes,
    /// - `token_estimate`: a token-count estimate computed from total emitted characters,
    /// - `etag`: optional final ETag (hex-encoded, first 16 bytes) when metadata extraction was enabled,
    /// - `stats`: accumulated streaming statistics.
    ///
    /// # Errors
    ///
    /// Returns `ConversionError` for timeout, budget/memory limits, fallback, or post-commit errors
    /// that occur during finalization.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use nginx_markdown_converter::streaming::StreamingConverter;
    ///
    /// // Create converter with appropriate options and budget (omitted).
    /// let options = Default::default();
    /// let budget = Default::default();
    /// let converter = StreamingConverter::new(options, budget);
    ///
    /// // Finalize and obtain the final result (consumes `converter`).
    /// let result = converter.finalize().expect("finalize conversion");
    /// println!("Final markdown size: {}", result.final_markdown.len());
    /// ```
    pub fn finalize(mut self) -> Result<StreamingResult, ConversionError> {
        // Check timeout
        self.check_timeout()?;

        if let Some(error) = self.charset_preflight_error.take() {
            return Err(self.wrap_error(error));
        }

        // 1. Flush charset state (any remaining buffered data)
        // CharsetState distinguishes a UTF-8 pending sniff buffer (returned
        // in place) from a decoder flush that must allocate output.
        let flush_allocation = self
            .charset_state
            .flush_allocation_upper_bound()
            .map_err(|e| self.wrap_error(e))?;
        if flush_allocation > 0 {
            let current_working_set = self.estimate_working_set();
            if let Err(error) = self
                .budget
                .check_total(current_working_set, flush_allocation)
            {
                self.charset_preflight_error = Some(error.clone());
                return Err(self.wrap_error(error));
            }
        }

        let remaining_charset = self.charset_state.flush().map_err(|e| self.wrap_error(e))?;

        // The decoder flush result remains borrowed by the tokenizer until
        // this call returns.  Track its allocation capacity, not its logical
        // length, and recover a pending UTF-8 tail without copying the whole
        // decoder output into a second Vec.
        self.charset_transcoded_bytes = remaining_charset.capacity();
        self.process_utf8_bytes(&remaining_charset, true)?;

        // The decoder flush result is about to be dropped.
        self.charset_transcoded_bytes = 0;

        // 3. Finish tokenizer (signal end-of-input)
        self.update_peak_memory().map_err(|e| self.wrap_error(e))?;
        let final_batch = self.tokenizer.finish().map_err(|e| self.wrap_error(e))?;

        // 4. Process remaining tokens
        self.process_tokenizer_batch(final_batch)?;

        // 5. Finalize state machine (auto-close unclosed contexts)
        let unclosed = self.state_machine.finalize();
        for ctx in &unclosed {
            let action = StateMachineAction::Exit(ctx.clone());
            self.emitter
                .process_action(&action, &mut self.state_machine)
                .map_err(|e| self.wrap_error(e))?;
        }

        // 6. Finalize emitter (flush all pending bytes)
        let final_markdown = self.emitter.finalize().map_err(|e| self.wrap_error(e))?;

        // Update incremental stats with final markdown
        self.update_incremental_stats(&final_markdown);

        // 6b. Finalize metadata URL: match MetadataExtractor::extract
        // which unconditionally overwrites metadata.url after meta tag
        // extraction — canonical if found, else base_url (which may be None).
        // This means og:url is always overwritten in the final result.
        if self.options.extract_metadata {
            self.metadata.url = Self::resolve_final_url(
                self.canonical_found,
                &self.metadata.url,
                &self.options.base_url,
            );
        }

        // 7. Compute final ETag
        let etag = self.etag_hasher.map(|hasher| {
            let hash = hasher.finalize();
            let hash_bytes = hash.as_bytes();
            format!("\"{}\"", hex::encode(&hash_bytes[..16]))
        });

        // 8. Compute final token estimate from accumulated character count.
        // Uses ceil(total_chars / chars_per_token) to match the configured
        // TokenEstimator ratio, computed once over the total to avoid
        // per-flush rounding drift.
        // Saturates to u32::MAX for documents exceeding representable range.
        let token_estimate = {
            let ratio = self.chars_per_token as f64;
            let est = (self.total_markdown_chars as f64 / ratio).ceil() as u64;
            Some(u32::try_from(est).unwrap_or(u32::MAX))
        };

        Ok(StreamingResult {
            final_markdown,
            token_estimate,
            etag,
            stats: self.stats,
        })
    }

    /// Attempt a post-commit safe finish: close all open Markdown structures
    /// without emitting raw HTML.
    ///
    /// This method is intended for use after `feed_chunk` returns a
    /// `PostCommitError`. It attempts to gracefully close all open Markdown
    /// constructs (headings, paragraphs, lists, code blocks, blockquotes,
    /// inline formatting) so that the already-emitted output forms valid
    /// Markdown, even though the conversion could not complete normally.
    ///
    /// # Returns
    ///
    /// - `Ok(closing_bytes)` — all open structures were successfully closed.
    ///   The returned bytes are the Markdown closure text (e.g., closing
    ///   fences, trailing newlines). The caller should append these after
    ///   the already-committed output.
    /// - `Err(ConversionError)` — structures could not be safely closed
    ///   (e.g., emitter budget exceeded during closure). The caller must
    ///   abort and discard or truncate the partial output.
    ///
    /// # Ownership
    ///
    /// This method consumes `self`. After calling, the converter is dropped.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// // After feed_chunk returns PostCommitError:
    /// match converter.safe_finish() {
    ///     Ok(closing) => { /* append `closing` to committed output */ }
    ///     Err(_) => { /* abort: discard partial output */ }
    /// }
    /// ```
    pub fn safe_finish(mut self) -> Result<Vec<u8>, ConversionError> {
        // Use the state machine to identify all unclosed structural contexts,
        // then ask the emitter to close each one in reverse order (inner-most
        // first). This mirrors the `finalize` path but without processing any
        // remaining input — we only close what is already open.
        self.emitter.discard_uncommitted_output();

        // 1. Finalize state machine: pops all contexts from the stack.
        let unclosed = self.state_machine.finalize();

        // 2. Ask the emitter to close each open context.
        for ctx in &unclosed {
            let action = StateMachineAction::Exit(ctx.clone());
            self.emitter
                .process_action(&action, &mut self.state_machine)?;
        }

        // 3. Return only closure bytes produced after uncommitted output was
        //    discarded. Do not call finalize(), which flushes all pending
        //    content and can leak bytes from the failed feed call.
        let closing_bytes = self.emitter.take_closure_output()?;

        Ok(closing_bytes)
    }

    // ── Internal helpers ────────────────────────────────────────────

    /// Feed UTF-8 through bounded tokenizer slices and process each event batch
    /// before the next slice is handed to html5ever.
    fn process_tokenizer_input(&mut self, input: &str) -> Result<(), ConversionError> {
        let mut offset = 0usize;
        while offset < input.len() {
            // Charge the full conservative tokenizer envelope before the next
            // bounded slice is handed to html5ever.
            self.update_peak_memory().map_err(|e| self.wrap_error(e))?;
            let step = self
                .tokenizer
                .feed_next(&input[offset..])
                .map_err(|e| self.wrap_error(e))?;
            if step.consumed == 0 && step.batch.is_none() {
                return Err(self.wrap_error(ConversionError::InternalError(
                    "budgeted tokenizer made no progress".to_string(),
                )));
            }
            offset = offset.checked_add(step.consumed).ok_or_else(|| {
                self.wrap_error(ConversionError::BudgetExceeded {
                    stage: "tokenizer_input_offset (integer overflow)".to_string(),
                    used: usize::MAX,
                    limit: input.len(),
                })
            })?;
            if let Some(batch) = step.batch {
                self.process_tokenizer_batch(batch)?;
            }
        }
        Ok(())
    }

    /// Restore at most one split UTF-8 code point without copying the input
    /// chunk, then feed the remaining borrowed bytes directly to html5ever.
    fn process_utf8_bytes(&mut self, input: &[u8], at_eof: bool) -> Result<(), ConversionError> {
        let mut remaining = input;

        while !self.utf8_tail.is_empty() && (!remaining.is_empty() || at_eof) {
            let tail_len = self.utf8_tail.len();
            if tail_len > 3 {
                return Err(self.wrap_error(ConversionError::InternalError(
                    "UTF-8 tail exceeded one incomplete code point".to_string(),
                )));
            }

            if remaining.is_empty() {
                let tail = std::mem::take(&mut self.utf8_tail);
                return self.process_utf8_slice(&tail, true);
            }

            let prefix_input_len = remaining.len().min(4usize.saturating_sub(tail_len));
            let mut prefix = [0u8; 4];

            prefix[..tail_len].copy_from_slice(&self.utf8_tail);
            prefix[tail_len..tail_len + prefix_input_len]
                .copy_from_slice(&remaining[..prefix_input_len]);
            self.utf8_tail.clear();

            self.process_utf8_slice(
                &prefix[..tail_len + prefix_input_len],
                at_eof && prefix_input_len == remaining.len(),
            )?;
            remaining = &remaining[prefix_input_len..];
        }

        if remaining.is_empty() {
            Ok(())
        } else {
            self.process_utf8_slice(remaining, at_eof)
        }
    }

    /// Process one borrowed UTF-8 slice, preserving an incomplete trailing
    /// code point unless this is the final input slice.
    fn process_utf8_slice(&mut self, input: &[u8], at_eof: bool) -> Result<(), ConversionError> {
        let mut input = input;

        if !self.bom_stripped && (!input.starts_with(&[0xEF]) || input.len() >= 3 || at_eof) {
            self.bom_stripped = true;
            if input.starts_with(b"\xEF\xBB\xBF") {
                input = &input[3..];
            }
        }

        let (valid, tail) = if at_eof {
            (input, &[][..])
        } else {
            split_utf8_tail(input)
        };
        if !tail.is_empty() {
            self.store_utf8_tail(tail)?;
        }
        if valid.is_empty() {
            return Ok(());
        }

        let utf8_str = match std::str::from_utf8(valid) {
            Ok(s) => std::borrow::Cow::Borrowed(s),
            Err(_) => {
                let lossy_upper_bound = valid.len().checked_mul(3).ok_or_else(|| {
                    self.wrap_error(ConversionError::BudgetExceeded {
                        stage: "lossy_utf8 (integer overflow)".to_string(),
                        used: usize::MAX,
                        limit: self.budget.total,
                    })
                })?;
                self.budget
                    .check_total(self.estimate_working_set(), lossy_upper_bound)
                    .map_err(|e| self.wrap_error(e))?;
                String::from_utf8_lossy(valid)
            }
        };
        let saved_transcoded = self.charset_transcoded_bytes;
        if let std::borrow::Cow::Owned(ref owned) = utf8_str {
            self.charset_transcoded_bytes = self
                .charset_transcoded_bytes
                .saturating_add(owned.capacity());
        }
        let result = self.process_tokenizer_input(&utf8_str);
        self.charset_transcoded_bytes = saved_transcoded;
        result
    }

    fn store_utf8_tail(&mut self, tail: &[u8]) -> Result<(), ConversionError> {
        if !self.utf8_tail.is_empty() || tail.len() > 3 {
            return Err(self.wrap_error(ConversionError::InternalError(
                "UTF-8 tail must contain one incomplete code point".to_string(),
            )));
        }

        self.utf8_tail.extend_from_slice(tail);
        Ok(())
    }

    /// Process one bounded tokenizer event batch.
    ///
    /// Uses the batch's authoritative token and parse-error counts from the
    /// tokenizer sink rather than counting events individually. In compact
    /// mode, the sink counts all non-EOF tokens (including comments, doctypes,
    /// and parse errors that are discarded from the event vector), so the
    /// batch-level counts are the single source of truth.
    fn process_tokenizer_batch(&mut self, batch: TokenizerBatch) -> Result<(), ConversionError> {
        self.stats.tokens_processed = self
            .stats
            .tokens_processed
            .saturating_add(batch.token_count);
        self.stats.parse_errors = self.stats.parse_errors.saturating_add(batch.parse_errors);
        for event in batch.events {
            self.process_single_event(event)?;
        }
        Ok(())
    }

    /// Processes a single `StreamEvent` through the sanitizer, state machine, and emitter.
    ///
    /// This advances internal streaming state (including token counts, optional head-region
    /// metadata extraction, and peak-memory accounting) but does not drain the emitter's
    /// flushed output buffer — the caller is responsible for reading flushed bytes.
    ///
    /// # Errors
    ///
    /// Returns a `ConversionError` when processing cannot continue:
    /// - `StreamingFallback { reason: FrontMatterOverflow }` if head-region lookahead exceeds the budget during pre-commit metadata extraction.
    /// - `StreamingFallback { reason: TableDetected }` if a table requires fallback during pre-commit.
    /// - `PostCommitError` if a table or other error is detected after commit; the error includes `bytes_emitted`.
    /// - `MemoryLimit` when sanitization reports nesting depth exceeded.
    /// - Other `ConversionError` variants produced by the state machine or emitter; in post-commit these are wrapped as `PostCommitError`.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// // Assume `conv` is a mutable StreamingConverter and `ev` is a StreamEvent.
    /// // The example demonstrates the callsite pattern; concrete construction is omitted.
    /// let _ = conv.process_single_event(ev)?;
    /// ```
    fn process_head_metadata(&mut self, event: &StreamEvent) -> Result<(), ConversionError> {
        if self.state_machine.in_head
            && self.options.extract_metadata
            && self.extract_metadata_from_event(event)
            && matches!(self.commit_state, CommitState::PreCommit)
        {
            return Err(ConversionError::StreamingFallback {
                reason: FallbackReason::FrontMatterOverflow,
            });
        }
        Ok(())
    }

    fn unsupported_start_tag_name(event: &StreamEvent) -> Option<&str> {
        let StreamEvent::StartTag { name, .. } = event else {
            return None;
        };
        match name.as_str() {
            "svg" | "math" | "canvas" => Some(name),
            _ => None,
        }
    }

    fn fallback_error_for_structure(&self, structure: &str) -> ConversionError {
        let reason = if structure == "table" {
            FallbackReason::TableDetected
        } else {
            FallbackReason::UnsupportedStructure(structure.to_owned())
        };
        if matches!(self.commit_state, CommitState::PreCommit) {
            ConversionError::StreamingFallback { reason }
        } else {
            ConversionError::PostCommitError {
                reason: format!("{structure} detected after commit"),
                bytes_emitted: self.bytes_emitted,
                original_code: 99,
            }
        }
    }

    fn process_implied_closures(&mut self) -> Result<(), ConversionError> {
        let implied_closures = std::mem::take(&mut self.sanitizer.implied_closures);
        for closed_tag in implied_closures {
            let synthetic = StreamEvent::EndTag { name: closed_tag };
            let action = self
                .state_machine
                .process_event(&synthetic)
                .map_err(|error| self.wrap_error(error))?;
            self.emitter
                .process_action(&action, &mut self.state_machine)
                .map_err(|error| self.wrap_error(error))?;
            self.update_peak_memory()
                .map_err(|error| self.wrap_error(error))?;
        }
        Ok(())
    }

    fn process_single_event(&mut self, event: StreamEvent) -> Result<(), ConversionError> {
        // Token and parse-error counts are now accumulated at the batch level
        // in process_tokenizer_batch() using the sink's authoritative counts.
        // This avoids double-counting in compact mode where comment, doctype,
        // and parse-error tokens are counted by the sink but not emitted as
        // events.

        // Front matter extraction: collect metadata from <head> region,
        // but only when metadata extraction is enabled (metadata extraction guard).
        // If the <head> region exceeds the lookahead budget, trigger
        // explicit fallback on front-matter overflow.
        self.process_head_metadata(&event)?;
        self.update_peak_memory().map_err(|e| self.wrap_error(e))?;

        // Check for unsupported structures BEFORE sanitization.
        // The sanitizer strips elements like <form>, <iframe> (converting them
        // to text or extracting URLs). Those are adequately handled by stripping.
        // However, SVG, MathML, and canvas elements represent content that cannot
        // be meaningfully converted to Markdown by the streaming path — they
        // require full-buffer conversion.
        if let Some(structure) = Self::unsupported_start_tag_name(&event) {
            return Err(self.fallback_error_for_structure(structure));
        }

        // Sanitize
        let decision = self.sanitizer.process_event(event);

        // Mirror implied end-tag closures (e.g. `</p>` before `<div>`) into
        // the StructuralStateMachine so its context stack does not leak stale
        // open elements. The sanitizer tracks which optional end tags were
        // implied by the incoming StartTag; we synthesize the corresponding
        // Exit actions here, BEFORE the Skip decision is applied.
        //
        // This must happen before the Skip/Pass branch because implied
        // closures are produced even when the current tag is stripped or
        // skipped (e.g. `<form>` in FORM_ELEMENTS is skipped but still
        // triggers `</p>` closure via PARAGRAPH_CLOSING_START_TAGS).
        // Dropping the closures on Skip would leave the state machine's
        // context stack stale, causing downstream content to be emitted
        // in the wrong block context (e.g. paragraph text glued to form
        // content).
        self.process_implied_closures()?;

        let sanitized_event = match decision {
            SanitizeDecision::Pass(ev) | SanitizeDecision::PassModified(ev) => ev,
            SanitizeDecision::Skip => return Ok(()),
            SanitizeDecision::DepthExceeded => {
                return Err(self.wrap_error(ConversionError::MemoryLimit(
                    "nesting depth exceeded during sanitization".to_string(),
                )));
            }
        };

        // State machine
        let action = self
            .state_machine
            .process_event(&sanitized_event)
            .map_err(|e| self.wrap_error(e))?;

        // Check for unsupported structure fallback
        if let StateMachineAction::FallbackRequired(ref structure) = action {
            return Err(self.fallback_error_for_structure(structure));
        }

        // Emitter
        self.emitter
            .process_action(&action, &mut self.state_machine)
            .map_err(|e| self.wrap_error(e))?;

        // Track peak working set after emitter processes the event,
        // when the pending buffer is at its largest.
        self.update_peak_memory().map_err(|e| self.wrap_error(e))?;

        Ok(())
    }

    /// Checks whether the converter's cooperative timeout has been exceeded.
    ///
    /// If a deadline is set and the current time is at or after that deadline,
    /// returns a timeout error. If the converter is already in `PostCommit` state
    /// the error is returned as `ConversionError::PostCommitError` and includes the
    /// number of bytes already emitted.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// // Call from a StreamingConverter instance to validate its deadline.
    /// // let conv: StreamingConverter = /* ... */ ;
    /// // conv.check_timeout()?;
    /// ```
    fn check_timeout(&self) -> Result<(), ConversionError> {
        if let Some(deadline) = self.deadline
            && Instant::now() >= deadline
        {
            if matches!(self.commit_state, CommitState::PostCommit) {
                return Err(ConversionError::PostCommitError {
                    reason: "timeout exceeded".to_string(),
                    bytes_emitted: self.bytes_emitted,
                    original_code: ConversionError::Timeout.code(),
                });
            }
            return Err(ConversionError::Timeout);
        }
        Ok(())
    }

    /// Wrap an error for the current commit state.
    ///
    /// - In `PostCommit` state, wraps the error as `PostCommitError` with
    ///   the emitted byte count so the caller knows how much was delivered.
    /// - In `PreCommit` state, returns the original error unchanged so the
    ///   caller can match on specific variants (`EncodingError`,
    ///   `BudgetExceeded`, etc.).
    fn wrap_error(&self, err: ConversionError) -> ConversionError {
        if matches!(self.commit_state, CommitState::PostCommit) {
            ConversionError::PostCommitError {
                original_code: err.code(),
                reason: err.to_string(),
                bytes_emitted: self.bytes_emitted,
            }
        } else {
            err
        }
    }

    /// Update streaming statistics with newly flushed Markdown bytes.
    ///
    /// This updates the converter's cumulative counters and optional ETag state:
    /// - increments `bytes_emitted` by the flushed byte length (saturating),
    /// - updates the incremental ETag hasher (if enabled) with `flushed`,
    /// - increments `total_markdown_chars` by the number of Unicode scalar
    ///   values in `flushed` (fast UTF-8 path with lossy fallback, saturating),
    /// - and refreshes `stats.flush_count` from the emitter.
    ///
    /// # Parameters
    ///
    /// - `flushed`: the slice of UTF-8 (or potentially ill-formed UTF-8) bytes that were emitted since the last update.
    fn update_incremental_stats(&mut self, flushed: &[u8]) {
        if flushed.is_empty() {
            return;
        }

        self.bytes_emitted = self.bytes_emitted.saturating_add(flushed.len());

        // Update ETag hasher
        if let Some(hasher) = self.etag_hasher.as_mut() {
            hasher.update(flushed);
        }

        // Accumulate character count for token estimation.
        // The final token count is computed once in finalize() as
        // ceil(total_chars / chars_per_token) to match the configured
        // ratio.  See StreamingConverter::chars_per_token field and
        // the finalize() token_estimate block for the computation.
        let char_count = match std::str::from_utf8(flushed) {
            Ok(text) => text.chars().count() as u64,
            Err(_) => String::from_utf8_lossy(flushed).chars().count() as u64,
        };
        self.total_markdown_chars = self.total_markdown_chars.saturating_add(char_count);

        // Update stats
        self.stats.flush_count = self.emitter.flush_count();
    }

    /// Estimate the current in-memory working set and update peak.
    fn update_peak_memory(&mut self) -> Result<(), ConversionError> {
        let working_set = self.estimate_working_set();
        self.stats.peak_memory_estimate = self.stats.peak_memory_estimate.max(working_set);

        // Enforce budget.total: the working set must not exceed the
        // declared total-memory cap.
        self.budget.check_total(0, working_set)?;
        Ok(())
    }

    /// Compute the current estimated resident working-set size.
    ///
    /// Includes all heap allocations that are alive right now:
    /// - emitter pending/flushed buffers and collectors
    /// - state machine stack
    /// - metadata from `<head>` region
    /// - html_title_buf
    /// - tokenizer conservative reservation
    /// - charset sniff buffer (in Pending state)
    /// - charset transcoded output (Cow::Owned during processing)
    /// - utf8_tail (incomplete UTF-8 bytes from previous chunk)
    fn estimate_working_set(&self) -> usize {
        self.emitter
            .pending_bytes()
            .saturating_add(self.emitter.flushed_bytes())
            .saturating_add(self.emitter.resident_collector_bytes())
            .saturating_add(self.state_machine.stack_bytes_estimate())
            .saturating_add(self.metadata.bytes_estimate())
            .saturating_add(self.html_title_buf.capacity())
            .saturating_add(self.tokenizer.reserved_bytes())
            .saturating_add(self.charset_state.resident_bytes())
            .saturating_add(self.charset_transcoded_bytes)
            .saturating_add(self.utf8_tail.capacity())
    }

    /// Extract metadata from events occurring in the `<head>` region.
    ///
    /// Collects title text from `<title>` elements and metadata from
    /// `<meta>` tags with appropriate `name`/`property` attributes.
    ///
    /// Tracks the cumulative size of `<head>` events against the
    /// lookahead budget. Returns `true` if the budget is exceeded,
    /// signalling that the caller should trigger an Explicit_Fallback
    /// on budget exhaustion.
    fn metadata_event_cost(event: &StreamEvent) -> usize {
        match event {
            StreamEvent::StartTag { name, attrs, .. } => name.len().saturating_add(
                attrs
                    .iter()
                    .map(|(k, v)| k.len().saturating_add(v.len()))
                    .sum::<usize>(),
            ),
            StreamEvent::EndTag { name } => name.len(),
            StreamEvent::Text(t) => t.len(),
            _ => 0,
        }
    }

    fn update_canonical_link(&mut self, attrs: &[(String, String)]) {
        if self.canonical_found {
            return;
        }
        let is_canonical = attrs.iter().any(|(key, value)| {
            key == "rel"
                && value
                    .split_ascii_whitespace()
                    .any(|token| token.eq_ignore_ascii_case("canonical"))
        });
        if is_canonical && let Some((_, href)) = attrs.iter().find(|(key, _)| key == "href") {
            self.canonical_found = true;
            self.metadata.url = self.resolve_and_sanitize_metadata_url(href);
        }
    }

    fn process_head_start_tag(
        &mut self,
        name: &str,
        attrs: &[(String, String)],
        self_closing: bool,
    ) {
        match name {
            "title" => {
                self.collecting_title = true;
                self.html_title_buf.clear();
            }
            "meta" => self.extract_meta_tag(attrs),
            "link" => self.update_canonical_link(attrs),
            _ => {}
        }
        if self_closing && name == "title" {
            self.collecting_title = false;
        }
    }

    fn finish_html_title(&mut self) {
        self.collecting_title = false;
        if !self.social_title_set && !self.html_title_set {
            self.metadata.title = Some(self.html_title_buf.trim().to_string());
            self.html_title_set = true;
        }
        self.html_title_buf.clear();
    }

    fn extract_metadata_from_event(&mut self, event: &StreamEvent) -> bool {
        // Estimate the byte cost of this event for lookahead budget tracking.
        // This is a rough estimate — we count tag names, attribute keys/values,
        // and text content lengths.
        let event_cost = Self::metadata_event_cost(event);
        let lookahead_check = self
            .budget
            .check_lookahead(self.head_bytes_seen, event_cost);
        self.head_bytes_seen = self.head_bytes_seen.saturating_add(event_cost);

        // Check lookahead budget — if exceeded, signal fallback needed.
        if lookahead_check.is_err() {
            return true; // budget exceeded
        }

        match event {
            StreamEvent::StartTag {
                name,
                attrs,
                self_closing,
            } => self.process_head_start_tag(name, attrs, *self_closing),
            StreamEvent::EndTag { name } if name == "title" => self.finish_html_title(),
            StreamEvent::Text(text) if self.collecting_title && !text.is_empty() => {
                // Collect raw text into the separate buffer.
                // The final trim happens at </title> above.
                self.append_title_text_bounded(text);
            }
            _ => {}
        }
        false // within budget
    }

    /// Append title text while preserving the configured lookahead bound.
    ///
    /// We intentionally cap the dedicated title collector by the same
    /// configured lookahead budget used for `<head>` processing so
    /// collector growth remains explicitly bounded.
    fn append_title_text_bounded(&mut self, text: &str) {
        let limit = self.budget.lookahead;
        if limit == 0 || self.html_title_buf.len() >= limit {
            return;
        }

        let remaining = limit.saturating_sub(self.html_title_buf.len());
        if text.len() <= remaining {
            self.html_title_buf.push_str(text);
            return;
        }

        let keep = text.floor_char_boundary(remaining);
        self.html_title_buf.push_str(&text[..keep]);
    }

    /// Update page metadata from a `<meta>` tag's attributes.
    ///
    /// Selects a metadata key by preferring the `property` attribute over `name`,
    /// reads the `content` attribute, and applies site-specific priority rules:
    /// - `og:*` and `twitter:*` keys override or set curated metadata (e.g., titles,
    ///   descriptions). Social titles set `social_title_set`.
    /// - Generic keys (e.g., `description`, `author`, `article:published_time`)
    ///   use first-win semantics where documented.
    /// - Image URLs are resolved via the converter's URL resolution when set.
    ///
    /// # Parameters
    ///
    /// - `attrs`: a slice of `(attribute_name, attribute_value)` pairs representing
    ///   the attributes of the `<meta>` tag; matching is done by exact name
    ///   (e.g., `"property"`, `"name"`, `"content"`).
    ///
    /// # Examples
    ///
    /// ```ignore
    /// // Example usage within the converter implementation:
    /// // let mut conv = StreamingConverter::new(options, budget);
    /// // conv.extract_meta_tag(&[("property".into(), "og:title".into()), ("content".into(), "Example".into())]);
    /// ```
    fn extract_meta_tag(&mut self, attrs: &[(String, String)]) {
        // Prefer `property` over `name`, matching MetadataExtractor's
        // `property.or(name)` lookup order.
        let property_val = attrs
            .iter()
            .find(|(k, _)| k == "property")
            .map(|(_, v)| v.as_str());
        let name_val = attrs
            .iter()
            .find(|(k, _)| k == "name")
            .map(|(_, v)| v.as_str());
        let key = property_val.or(name_val);

        let content_attr = attrs
            .iter()
            .find(|(k, _)| k == "content")
            .map(|(_, v)| v.as_str());

        if let (Some(key_val), Some(content_val)) = (key, content_attr) {
            let content = content_val.to_string();
            match key_val {
                // OG/Twitter title overrides any existing title
                "og:title" | "twitter:title" => {
                    self.metadata.title = Some(content);
                    self.social_title_set = true;
                }
                // OG/Twitter description overrides any existing description
                "og:description" | "twitter:description" => {
                    self.metadata.description = Some(content);
                }
                // Generic description: first-wins fallback
                "description" if self.metadata.description.is_none() => {
                    self.metadata.description = Some(content);
                }
                // OG/Twitter image: first-wins (resolve URL if configured)
                "og:image" | "twitter:image" if self.metadata.image.is_none() => {
                    self.metadata.image = self.resolve_and_sanitize_metadata_url(&content);
                }
                "og:url" if self.metadata.url.is_none() => {
                    self.metadata.url = Self::sanitize_metadata_url(&content);
                }
                "author" if self.metadata.author.is_none() => {
                    self.metadata.author = Some(content);
                }
                "article:published_time" if self.metadata.published.is_none() => {
                    self.metadata.published = Some(content);
                }
                _ => {}
            }
        }
    }

    fn sanitize_metadata_url(url: &str) -> Option<String> {
        SecurityValidator::new()
            .sanitize_url(url)
            .map(ToOwned::to_owned)
    }

    fn resolve_and_sanitize_metadata_url(&self, url: &str) -> Option<String> {
        Self::sanitize_metadata_url(url)?;
        let resolved = self.resolve_url(url);
        Self::sanitize_metadata_url(&resolved)
    }

    /// Resolve a possibly-relative URL against the converter's configured base URL.
    ///
    /// If relative resolution is disabled, the input is empty, the input is
    /// already absolute (for example `https:`, `mailto:`, or `//`), the
    /// converter has no `base_url`, or the `base_url` does not start with
    /// `http://` or `https://`, the original `url` is returned unchanged. If
    /// `url` starts with `/`, it is resolved against the origin (scheme +
    /// authority) of `base_url`. Otherwise `url` is resolved relative to the
    /// directory portion of `base_url`.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// # use nginx_markdown_converter::streaming::converter::{StreamingConverter, ConversionOptions, MemoryBudget};
    /// // (pseudo-constructors shown for clarity; actual test harness constructs a converter)
    /// let mut opts = ConversionOptions::default();
    /// opts.resolve_relative_urls = true;
    /// opts.base_url = Some("https://example.com/path/to/page.html".to_string());
    /// let conv = StreamingConverter::new(opts, MemoryBudget::default());
    ///
    /// assert_eq!(conv.resolve_url("/img.png"), "https://example.com/img.png");
    /// assert_eq!(conv.resolve_url("icons/logo.svg"), "https://example.com/path/to/icons/logo.svg");
    /// assert_eq!(conv.resolve_url("https://other.test/x"), "https://other.test/x");
    /// assert_eq!(conv.resolve_url("mailto:a@example.com"), "mailto:a@example.com");
    /// ```
    fn http_base_url_origin(base: &str) -> &str {
        let scheme_len = if base.starts_with("https://") { 8 } else { 7 };
        let authority = &base[scheme_len..];
        if let Some(path_start) = authority.find('/') {
            &base[..scheme_len + path_start]
        } else {
            base
        }
    }

    fn resolve_path_against_base(base: &str, url: &str) -> String {
        if base.ends_with('/') {
            return format!("{base}{url}");
        }
        let trimmed = base.trim_end_matches('/');
        let base_dir = match trimmed.rfind('/') {
            Some(position)
                if position > 0 && trimmed.as_bytes().get(position - 1) == Some(&b'/') =>
            {
                trimmed
            }
            Some(position) => &trimmed[..position],
            None => trimmed,
        };
        format!("{base_dir}/{url}")
    }

    fn resolve_url(&self, url: &str) -> String {
        if !self.options.resolve_relative_urls
            || url.is_empty()
            || Self::has_absolute_uri_scheme(url)
            || url.starts_with("//")
        {
            return url.to_string();
        }
        let Some(base) = self.options.base_url.as_deref() else {
            return url.to_string();
        };
        if !base.starts_with("http://") && !base.starts_with("https://") {
            return url.to_string();
        }
        if url.starts_with('/') {
            return format!("{}{}", Self::http_base_url_origin(base), url);
        }
        Self::resolve_path_against_base(base, url)
    }

    /// Detects whether `url` begins with an absolute URI scheme per RFC 3986 §3.
    ///
    /// An absolute URI has the form `scheme:hier-part` where `scheme` is
    /// `ALPHA *( ALPHA / DIGIT / "+" / "-" / "." )`.  Returns `false` for
    /// relative paths, fragment-only, and query-only references.
    fn has_absolute_uri_scheme(url: &str) -> bool {
        let Some(colon) = url.find(':') else {
            return false;
        };
        if url[..colon].contains('/') {
            return false;
        }
        let mut chars = url[..colon].chars();
        let Some(first) = chars.next() else {
            return false;
        };
        first.is_ascii_alphabetic()
            && chars.all(|ch| ch.is_ascii_alphanumeric() || ch == '+' || ch == '-' || ch == '.')
    }

    /// Selects the final metadata URL, preferring a discovered canonical over the base URL.
    ///
    /// If `canonical_found` is `true`, returns `current_url.clone()` (the canonical URL previously
    /// recorded during head processing). If `canonical_found` is `false`, returns `base_url.clone()`,
    /// which may be `None` to clear any previously observed `og:url`.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let canonical = Some("https://example.com/canonical".to_string());
    /// let base = Some("https://example.com/".to_string());
    /// assert_eq!(resolve_final_url(true, &canonical, &base), canonical);
    ///
    /// let og = Some("https://example.com/og".to_string());
    /// assert_eq!(resolve_final_url(false, &og, &base), base);
    ///
    /// // base_url `None` clears prior og:url when no canonical was found
    /// assert_eq!(resolve_final_url(false, &og, &None), None);
    /// ```
    fn resolve_final_url(
        canonical_found: bool,
        current_url: &Option<String>,
        base_url: &Option<String>,
    ) -> Option<String> {
        if canonical_found {
            current_url.as_deref().and_then(Self::sanitize_metadata_url)
        } else {
            base_url.as_deref().and_then(Self::sanitize_metadata_url)
        }
    }

    /// Access the converter's extracted page metadata.
    ///
    /// Metadata is populated from `<head>` region events observed during calls to
    /// `feed_chunk`. This returns the current metadata collected so far without
    /// consuming the converter.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// // Given a `StreamingConverter` instance `conv`, borrow its metadata:
    /// // let conv = StreamingConverter::new(options, budget);
    /// // let meta = conv.metadata();
    /// // assert!(meta.title.is_none() || meta.title.is_some());
    /// ```
    pub fn metadata(&self) -> &PageMetadata {
        &self.metadata
    }

    /// Retrieve the converter's current commit state.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use nginx_markdown_converter::streaming::StreamingConverter;
    /// use nginx_markdown_converter::streaming::types::CommitState;
    ///
    /// let conv = StreamingConverter::new(Default::default(), Default::default());
    /// let state = conv.commit_state();
    /// assert!(matches!(state, CommitState::PreCommit | CommitState::PostCommit));
    /// ```
    pub fn commit_state(&self) -> CommitState {
        self.commit_state
    }

    /// Access the converter's conversion options.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use nginx_markdown_converter::streaming::StreamingConverter;
    ///
    /// let converter = StreamingConverter::new(Default::default(), Default::default());
    /// let _opts = converter.options();
    /// ```
    pub fn options(&self) -> &ConversionOptions {
        &self.options
    }

    /// Preview the final metadata URL that `finalize` would produce without consuming the converter.
    ///
    /// If metadata extraction is disabled, returns `None`. Otherwise returns the resolved URL after applying canonical-vs-base_url convergence rules used by `finalize`.
    ///
    /// # Examples
    ///
    /// ```no_run
    /// use nginx_markdown_converter::streaming::StreamingConverter;
    ///
    /// let converter = StreamingConverter::new(Default::default(), Default::default());
    /// let _url = converter.peek_final_url();
    /// ```
    pub fn peek_final_url(&self) -> Option<String> {
        if !self.options.extract_metadata {
            return None;
        }
        Self::resolve_final_url(
            self.canonical_found,
            &self.metadata.url,
            &self.options.base_url,
        )
    }

    /// Evaluate whether the document qualifies for fast-path processing.
    ///
    /// Streaming fast-path evaluation is based on the structural state
    /// observed so far.  A document qualifies if:
    ///   - The state machine has not entered any dangerous/skip regions
    ///   - The nesting depth has remained within fast-path limits
    ///   - No fallback has been triggered
    ///   - At least one block-level element has been processed
    ///
    /// Returns `true` if the document qualifies for fast-path, `false`
    /// otherwise.  For documents where the full structure is not yet
    /// known (e.g., early in the stream), returns `false` conservatively.
    pub fn is_fast_path_candidate(&self) -> bool {
        if self.commit_state != CommitState::PreCommit {
            return false;
        }

        if self.sanitizer.is_skipping() {
            return false;
        }

        if self.state_machine.depth() > 6 {
            return false;
        }

        self.stats.chunks_processed > 0
    }
}

/// Split a byte slice at the last valid UTF-8 boundary.
///
/// Returns `(valid, tail)` where:
/// - in the common case, `valid` is well-formed UTF-8 and `tail` contains
///   0-3 trailing bytes that start an incomplete multibyte sequence.
/// - in the fallback case (interior invalid byte sequence that cannot be
///   isolated to an incomplete tail), returns `(bytes, &[])` so the caller
///   can handle invalid bytes via lossy conversion in the next stage.
///
/// This function is critical for preserving multi-byte characters (e.g.
/// CJK, emoji) that span chunk boundaries. Without it, a 3-byte UTF-8
/// character split across two `feed_chunk` calls would be replaced with
/// U+FFFD replacement characters, corrupting the output.
fn split_utf8_tail(bytes: &[u8]) -> (&[u8], &[u8]) {
    // Fast path: if the entire slice is valid UTF-8, no split needed.
    if std::str::from_utf8(bytes).is_ok() {
        return (bytes, &[]);
    }

    fn utf8_sequence_len(lead: u8) -> Option<usize> {
        match lead {
            0xC2..=0xDF => Some(2),
            0xE0..=0xEF => Some(3),
            0xF0..=0xF4 => Some(4),
            _ => None,
        }
    }

    fn is_continuation(byte: u8) -> bool {
        (byte & 0xC0) == 0x80
    }

    // Walk backwards (at most 3 bytes) to find the start of a repairable
    // incomplete multibyte sequence at the end. Invalid byte regions are not
    // deferred: they must be converted lossy in the current tokenizer state so
    // chunked conversion remains confluent with single-pass conversion.
    let len = bytes.len();
    let check_from = len.saturating_sub(3);
    for i in (check_from..len).rev() {
        let b = bytes[i];
        if let Some(expected_len) = utf8_sequence_len(b) {
            let available = len - i;
            if available < expected_len && bytes[i + 1..].iter().all(|&c| is_continuation(c)) {
                // Incomplete sequence — split here
                return (&bytes[..i], &bytes[i..]);
            }
            break;
        }

        if !is_continuation(b) {
            break;
        }
    }

    // Fallback: couldn't isolate a clean tail; return everything as valid
    // (lossy conversion will handle any interior invalid bytes).
    (bytes, &[])
}

#[cfg(test)]
mod tests {
    use super::*;
    use proptest::prelude::*;

    /// Create a `StreamingConverter` with UTF-8 content type preconfigured.
    ///
    /// This helper initializes a converter with default options and budget and
    /// pre-resolves the charset to `UTF-8` so that small inputs are processed
    /// immediately instead of waiting for the charset sniff buffer to fill.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let mut conv = make_converter();
    /// // ready to feed small UTF-8 HTML chunks without charset sniffing delay
    /// let out = conv.feed_chunk(b"<p>hi</p>").unwrap();
    /// assert!(out.markdown.len() > 0);
    /// ```
    fn make_converter() -> StreamingConverter {
        let mut conv =
            StreamingConverter::new(ConversionOptions::default(), MemoryBudget::default());
        // Pre-resolve charset so small inputs are processed immediately
        // without waiting for the 1024-byte sniff buffer to fill.
        conv.set_content_type(Some("text/html; charset=UTF-8".to_string()));
        conv
    }

    fn convert_with_splits(html: &[u8], split_sizes: &[usize]) -> Vec<u8> {
        let mut conv = make_converter();
        let mut out = Vec::new();
        let mut cursor = 0;

        for &size in split_sizes {
            if cursor >= html.len() {
                break;
            }
            let end = cursor.saturating_add(size).min(html.len());
            let chunk = conv.feed_chunk(&html[cursor..end]).unwrap();
            out.extend_from_slice(&chunk.markdown);
            cursor = end;
        }

        if cursor < html.len() {
            let chunk = conv.feed_chunk(&html[cursor..]).unwrap();
            out.extend_from_slice(&chunk.markdown);
        }

        let result = conv.finalize().unwrap();
        out.extend_from_slice(&result.final_markdown);
        out
    }

    #[test]
    fn test_converter_uses_charset_sniff_budget() {
        let budget = MemoryBudget {
            charset_sniff: 8,
            ..MemoryBudget::default()
        };
        let mut conv = StreamingConverter::new(ConversionOptions::default(), budget);

        let first = conv.charset_state.feed(b"<p>1234").unwrap();
        assert!(
            first.is_empty(),
            "converter charset state should remain pending before sniff limit"
        );

        let second = conv.charset_state.feed(b"5").unwrap();
        assert!(
            !second.is_empty(),
            "converter charset state should resolve at configured sniff limit"
        );
    }

    #[test]
    fn test_resolve_url_preserves_absolute_uri_schemes() {
        let opts = ConversionOptions {
            resolve_relative_urls: true,
            base_url: Some("https://example.com/path/to/page.html".to_string()),
            flavor: crate::converter::MarkdownFlavor::CommonMark,
            include_front_matter: false,
            extract_metadata: false,
            simplify_navigation: true,
            preserve_tables: true,
            prune_config: crate::converter::pruning::PruneConfig::default_enabled(),
        };
        let conv = StreamingConverter::new(opts, MemoryBudget::default());

        assert_eq!(
            conv.resolve_url("mailto:team@example.com"),
            "mailto:team@example.com"
        );
        assert_eq!(conv.resolve_url("tel:+15551234567"), "tel:+15551234567");
        assert_eq!(
            conv.resolve_url("ftp://files.example.com/a"),
            "ftp://files.example.com/a"
        );
        assert_eq!(
            conv.resolve_url("icons/logo.svg"),
            "https://example.com/path/to/icons/logo.svg"
        );
    }

    // ── resolve_final_url unit tests ────────────────────────────────

    #[test]
    fn test_resolve_final_url_canonical_wins() {
        let result = StreamingConverter::resolve_final_url(
            true,
            &Some("https://canonical.example.com".to_string()),
            &Some("https://base.example.com".to_string()),
        );
        assert_eq!(result.as_deref(), Some("https://canonical.example.com"));
    }

    #[test]
    fn test_resolve_final_url_no_canonical_uses_base() {
        let result = StreamingConverter::resolve_final_url(
            false,
            &Some("https://og.example.com".to_string()), // og:url still in current_url
            &Some("https://base.example.com".to_string()),
        );
        assert_eq!(
            result.as_deref(),
            Some("https://base.example.com"),
            "base_url should overwrite og:url when no canonical found"
        );
    }

    #[test]
    fn test_resolve_final_url_no_canonical_no_base_clears() {
        let result = StreamingConverter::resolve_final_url(
            false,
            &Some("https://og.example.com".to_string()),
            &None,
        );
        assert_eq!(
            result, None,
            "no canonical + no base_url should clear og:url"
        );
    }

    #[test]
    fn test_resolve_final_url_canonical_no_base() {
        let result = StreamingConverter::resolve_final_url(
            true,
            &Some("https://canonical.example.com".to_string()),
            &None,
        );
        assert_eq!(result.as_deref(), Some("https://canonical.example.com"));
    }

    #[test]
    fn test_resolve_final_url_nothing() {
        let result = StreamingConverter::resolve_final_url(false, &None, &None);
        assert_eq!(result, None);
    }

    #[test]
    fn test_resolve_final_url_rejects_dangerous_base_url() {
        let result = StreamingConverter::resolve_final_url(
            false,
            &Some("https://og.example.com".to_string()),
            &Some("javascript:alert(1)".to_string()),
        );
        assert_eq!(result, None);
    }

    /// Creates a `StreamingConverter` configured to extract page metadata and initialized with a
    /// text/html UTF-8 content type.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let mut conv = make_converter_with_metadata();
    /// assert!(conv.options().extract_metadata);
    /// ```
    fn make_converter_with_metadata() -> StreamingConverter {
        let opts = ConversionOptions {
            extract_metadata: true,
            flavor: crate::converter::MarkdownFlavor::CommonMark,
            include_front_matter: false,
            simplify_navigation: true,
            preserve_tables: true,
            base_url: None,
            resolve_relative_urls: true,
            prune_config: crate::converter::pruning::PruneConfig::default_enabled(),
        };
        let mut conv = StreamingConverter::new(opts, MemoryBudget::default());
        conv.set_content_type(Some("text/html; charset=UTF-8".to_string()));
        conv
    }

    #[test]
    fn test_basic_heading_conversion() {
        let mut conv = make_converter();
        let output = conv.feed_chunk(b"<h1>Hello World</h1>").unwrap();
        let result = conv.finalize().unwrap();

        let mut full = output.markdown;
        full.extend_from_slice(&result.final_markdown);
        let text = String::from_utf8(full).unwrap();
        assert!(text.contains("# Hello World"), "got: {}", text);
    }

    #[test]
    fn test_basic_paragraph_conversion() {
        let mut conv = make_converter();
        let output = conv.feed_chunk(b"<p>Hello</p><p>World</p>").unwrap();
        let result = conv.finalize().unwrap();

        let mut full = output.markdown;
        full.extend_from_slice(&result.final_markdown);
        let text = String::from_utf8(full).unwrap();
        assert!(text.contains("Hello"), "got: {}", text);
        assert!(text.contains("World"), "got: {}", text);
    }

    #[test]
    fn test_etag_generation() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(b"<h1>Test</h1>").unwrap();
        let result = conv.finalize().unwrap();

        assert!(result.etag.is_some());
        let etag = result.etag.unwrap();
        assert!(
            etag.starts_with('"'),
            "ETag should start with quote: {}",
            etag
        );
        assert!(etag.ends_with('"'), "ETag should end with quote: {}", etag);
        // 32 hex chars + 2 quotes = 34
        assert_eq!(etag.len(), 34, "ETag length should be 34: {}", etag);
    }

    #[test]
    fn test_etag_deterministic() {
        let html = b"<h1>Deterministic</h1><p>Test content</p>";

        let mut conv1 = make_converter_with_metadata();
        conv1.feed_chunk(html).unwrap();
        let result1 = conv1.finalize().unwrap();

        let mut conv2 = make_converter_with_metadata();
        conv2.feed_chunk(html).unwrap();
        let result2 = conv2.finalize().unwrap();

        assert_eq!(result1.etag, result2.etag, "ETags should be deterministic");
    }

    /// ETag should be None when extract_metadata is disabled (default).
    #[test]
    fn test_etag_none_when_metadata_disabled() {
        let mut conv = make_converter(); // default: extract_metadata = false
        conv.feed_chunk(b"<h1>Test</h1>").unwrap();
        let result = conv.finalize().unwrap();
        assert!(
            result.etag.is_none(),
            "ETag should be None when extract_metadata is disabled"
        );
    }

    #[test]
    fn test_token_estimate() {
        let mut conv = make_converter();
        conv.feed_chunk(b"<p>Hello World</p>").unwrap();
        let result = conv.finalize().unwrap();

        assert!(result.token_estimate.is_some());
        let estimate = result.token_estimate.unwrap();
        assert!(estimate > 0, "Token estimate should be > 0");
    }

    #[test]
    fn test_front_matter_title_extraction() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head><title>My Page Title</title></head><body><p>Content</p></body></html>",
        )
        .unwrap();
        let _result = conv.finalize().unwrap();

        // Metadata is consumed during finalize, check before
        // Actually we need to check before finalize consumes self
        let mut conv2 = make_converter_with_metadata();
        conv2.feed_chunk(b"<html><head><title>My Page Title</title></head><body><p>Content</p></body></html>").unwrap();
        assert_eq!(conv2.metadata().title.as_deref(), Some("My Page Title"));
    }

    #[test]
    fn test_front_matter_meta_extraction() {
        let mut conv = make_converter_with_metadata();
        let html = b"<html><head>\
            <meta name=\"description\" content=\"A test page\">\
            <meta name=\"author\" content=\"Test Author\">\
            <meta property=\"og:image\" content=\"https://example.com/img.png\">\
            <meta property=\"og:url\" content=\"https://example.com\">\
            <meta name=\"article:published_time\" content=\"2024-01-01\">\
            </head><body><p>Content</p></body></html>";
        conv.feed_chunk(html).unwrap();

        assert_eq!(conv.metadata().description.as_deref(), Some("A test page"));
        assert_eq!(conv.metadata().author.as_deref(), Some("Test Author"));
        assert_eq!(
            conv.metadata().image.as_deref(),
            Some("https://example.com/img.png")
        );
        assert_eq!(conv.metadata().url.as_deref(), Some("https://example.com"));
        assert_eq!(conv.metadata().published.as_deref(), Some("2024-01-01"));
    }

    #[test]
    fn test_table_triggers_fallback_precommit() {
        let mut conv = make_converter();
        let result = conv.feed_chunk(b"<table><tr><td>Cell</td></tr></table>");
        assert!(result.is_err());
        match result.unwrap_err() {
            ConversionError::StreamingFallback { reason } => {
                assert!(matches!(reason, FallbackReason::TableDetected));
            }
            other => panic!("Expected StreamingFallback, got: {:?}", other),
        }
    }

    #[test]
    fn test_svg_triggers_fallback_precommit() {
        let mut conv = make_converter();
        let result = conv.feed_chunk(b"<svg><circle cx='50' cy='50' r='40'/></svg>");
        assert!(result.is_err());
        match result.unwrap_err() {
            ConversionError::StreamingFallback { reason } => {
                assert_eq!(
                    reason,
                    FallbackReason::UnsupportedStructure("svg".to_string())
                );
            }
            other => panic!("Expected StreamingFallback(svg), got: {:?}", other),
        }
    }

    #[test]
    fn test_form_handled_by_stripping() {
        // Forms are handled by the streaming sanitizer (stripped) rather
        // than triggering full-buffer fallback. This verifies no error is
        // returned — the form tags are stripped and content is preserved.
        let mut conv = make_converter();
        let result = conv.feed_chunk(b"<form action='/submit'><input type='text'/></form>");
        assert!(
            result.is_ok(),
            "Form should be handled by stripping, not fallback"
        );
    }

    #[test]
    fn test_iframe_handled_by_stripping() {
        // Iframes are handled by the streaming sanitizer (URL extracted,
        // tags stripped) rather than triggering full-buffer fallback.
        let mut conv = make_converter();
        let result = conv.feed_chunk(b"<iframe src='https://example.com'></iframe>");
        assert!(
            result.is_ok(),
            "Iframe should be handled by stripping, not fallback"
        );
    }

    #[test]
    fn test_math_triggers_fallback_precommit() {
        let mut conv = make_converter();
        let result = conv.feed_chunk(b"<math><mi>x</mi></math>");
        assert!(result.is_err());
        match result.unwrap_err() {
            ConversionError::StreamingFallback { reason } => {
                assert_eq!(
                    reason,
                    FallbackReason::UnsupportedStructure("math".to_string())
                );
            }
            other => panic!("Expected StreamingFallback(math), got: {:?}", other),
        }
    }

    #[test]
    fn test_canvas_triggers_fallback_precommit() {
        let mut conv = make_converter();
        let result = conv.feed_chunk(b"<canvas id='myCanvas'></canvas>");
        assert!(result.is_err());
        match result.unwrap_err() {
            ConversionError::StreamingFallback { reason } => {
                assert_eq!(
                    reason,
                    FallbackReason::UnsupportedStructure("canvas".to_string())
                );
            }
            other => panic!("Expected StreamingFallback(canvas), got: {:?}", other),
        }
    }

    #[test]
    fn test_unsupported_structure_postcommit() {
        let mut conv = make_converter();
        // Feed content to transition to PostCommit
        let output = conv.feed_chunk(b"<h1>Title</h1>").unwrap();
        assert!(!output.markdown.is_empty());
        // Now feed a table after commit
        let result = conv.feed_chunk(b"<table><tr><td>Cell</td></tr></table>");
        assert!(result.is_err());
        match result.unwrap_err() {
            ConversionError::PostCommitError {
                reason,
                bytes_emitted,
                ..
            } => {
                assert!(reason.contains("table"));
                assert!(bytes_emitted > 0);
            }
            other => panic!("Expected PostCommitError, got: {:?}", other),
        }
    }

    /// Validates: Requirements 3.2, 4.5 — SVG detected after commit returns
    /// ERROR_POST_COMMIT (8), not fallback (7).
    #[test]
    fn test_svg_postcommit_returns_error_code_8() {
        let mut conv = make_converter();
        // Emit enough content to transition to PostCommit
        let output = conv.feed_chunk(b"<h1>Title</h1><p>Body text</p>").unwrap();
        assert!(!output.markdown.is_empty());
        assert_eq!(conv.commit_state, CommitState::PostCommit);

        // Now feed SVG — must return PostCommitError (code 8), not fallback (7)
        let result = conv.feed_chunk(b"<svg><circle cx='50' cy='50' r='40'/></svg>");
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert_eq!(
            err.code(),
            8,
            "SVG after commit must return code 8 (PostCommitError), got {}",
            err.code()
        );
        match err {
            ConversionError::PostCommitError {
                reason,
                bytes_emitted,
                ..
            } => {
                assert!(
                    reason.contains("svg"),
                    "reason should mention svg: {}",
                    reason
                );
                assert!(bytes_emitted > 0, "bytes_emitted should be > 0");
            }
            other => panic!("Expected PostCommitError, got: {:?}", other),
        }
    }

    /// Validates: Requirements 3.2, 4.5 — Math element detected after commit returns
    /// ERROR_POST_COMMIT (8), not fallback (7).
    #[test]
    fn test_math_postcommit_returns_error_code_8() {
        let mut conv = make_converter();
        let output = conv.feed_chunk(b"<h1>Title</h1><p>Body text</p>").unwrap();
        assert!(!output.markdown.is_empty());
        assert_eq!(conv.commit_state, CommitState::PostCommit);

        let result = conv.feed_chunk(b"<math><mi>x</mi><mo>=</mo><mn>2</mn></math>");
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert_eq!(
            err.code(),
            8,
            "Math after commit must return code 8, got {}",
            err.code()
        );
        match err {
            ConversionError::PostCommitError {
                reason,
                bytes_emitted,
                ..
            } => {
                assert!(
                    reason.contains("math"),
                    "reason should mention math: {}",
                    reason
                );
                assert!(bytes_emitted > 0);
            }
            other => panic!("Expected PostCommitError, got: {:?}", other),
        }
    }

    /// Validates: Requirements 3.2, 4.5 — Canvas element detected after commit returns
    /// ERROR_POST_COMMIT (8), not fallback (7).
    #[test]
    fn test_canvas_postcommit_returns_error_code_8() {
        let mut conv = make_converter();
        let output = conv.feed_chunk(b"<h1>Title</h1><p>Body text</p>").unwrap();
        assert!(!output.markdown.is_empty());
        assert_eq!(conv.commit_state, CommitState::PostCommit);

        let result = conv.feed_chunk(b"<canvas id='myCanvas' width='200' height='100'></canvas>");
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert_eq!(
            err.code(),
            8,
            "Canvas after commit must return code 8, got {}",
            err.code()
        );
        match err {
            ConversionError::PostCommitError {
                reason,
                bytes_emitted,
                ..
            } => {
                assert!(
                    reason.contains("canvas"),
                    "reason should mention canvas: {}",
                    reason
                );
                assert!(bytes_emitted > 0);
            }
            other => panic!("Expected PostCommitError, got: {:?}", other),
        }
    }

    /// Validates: Requirements 3.2, 4.5 — After post-commit error, safe_finish
    /// gracefully closes open structures, producing valid closing Markdown.
    #[test]
    fn test_safe_finish_after_postcommit_unsupported_content() {
        let mut conv = make_converter();
        // Emit content and open structures to reach PostCommit
        let output = conv
            .feed_chunk(b"<h1>Title</h1><p>First paragraph</p>")
            .unwrap();
        assert!(!output.markdown.is_empty());
        assert_eq!(conv.commit_state, CommitState::PostCommit);

        // Trigger post-commit error with SVG
        let result = conv.feed_chunk(b"<svg><rect/></svg>");
        assert!(result.is_err());
        assert_eq!(result.unwrap_err().code(), 8);

        // Call safe_finish — should succeed, closing any open structures
        let closing = conv.safe_finish();
        assert!(
            closing.is_ok(),
            "safe_finish should succeed after post-commit error"
        );
        // Closing bytes may be empty or contain closing markup; either is valid
    }

    #[test]
    fn test_safe_finish_discards_ready_unreturned_output() {
        let mut conv = make_converter();
        let output = conv.feed_chunk(b"<h1>Title</h1>").unwrap();
        assert!(!output.markdown.is_empty());
        assert_eq!(conv.commit_state, CommitState::PostCommit);

        let result = conv.feed_chunk(b"<p>uncommitted ready</p><svg></svg>");
        assert!(result.is_err());

        let closing = conv.safe_finish().expect("safe_finish should succeed");
        let closing_text = String::from_utf8(closing).expect("valid utf8");
        assert!(
            !closing_text.contains("uncommitted ready"),
            "safe_finish leaked ready-but-unreturned output: {closing_text:?}"
        );
    }

    #[test]
    fn test_safe_finish_discards_pending_unreturned_output() {
        let mut conv = make_converter();
        let output = conv.feed_chunk(b"<h1>Title</h1>").unwrap();
        assert!(!output.markdown.is_empty());
        assert_eq!(conv.commit_state, CommitState::PostCommit);

        conv.set_flush_threshold(1024);
        let result = conv.feed_chunk(b"<p>uncommitted pending</p><svg></svg>");
        assert!(result.is_err());

        let closing = conv.safe_finish().expect("safe_finish should succeed");
        let closing_text = String::from_utf8(closing).expect("valid utf8");
        assert!(
            !closing_text.contains("uncommitted pending"),
            "safe_finish leaked pending output: {closing_text:?}"
        );
    }

    /// Validates: Requirements 3.2, 4.5 — Commit state transition only happens
    /// once non-empty output is produced. Empty output does NOT trigger PostCommit.
    #[test]
    fn test_commit_state_stays_precommit_on_empty_output() {
        let mut conv = make_converter();
        // Feed only a comment — should not produce output
        let output = conv.feed_chunk(b"<!-- comment -->").unwrap();
        assert!(output.markdown.is_empty());
        assert_eq!(conv.commit_state, CommitState::PreCommit);

        // Now feed unsupported content — should return fallback (code 7), not post-commit (8)
        let result = conv.feed_chunk(b"<table><tr><td>Cell</td></tr></table>");
        assert!(result.is_err());
        assert_eq!(
            result.unwrap_err().code(),
            7,
            "Should be fallback (7) in PreCommit state"
        );
    }

    #[test]
    fn test_timeout_precommit() {
        let mut conv = make_converter();
        // Set a zero-duration timeout (already expired)
        conv.deadline = Some(
            Instant::now()
                .checked_sub(Duration::from_secs(1))
                .unwrap_or_else(Instant::now),
        );
        let result = conv.feed_chunk(b"<p>test</p>");
        assert!(result.is_err());
        assert_eq!(result.unwrap_err().code(), 3); // Timeout
    }

    #[test]
    fn test_timeout_postcommit() {
        let mut conv = make_converter();
        // Feed some data to transition to PostCommit
        let output = conv.feed_chunk(b"<h1>Title</h1>").unwrap();
        assert!(!output.markdown.is_empty() || matches!(conv.commit_state, CommitState::PreCommit));

        // Force PostCommit state and set expired deadline
        conv.commit_state = CommitState::PostCommit;
        conv.bytes_emitted = 10;
        conv.deadline = Some(
            Instant::now()
                .checked_sub(Duration::from_secs(1))
                .unwrap_or_else(Instant::now),
        );

        let result = conv.feed_chunk(b"<p>more</p>");
        assert!(result.is_err());
        assert_eq!(result.unwrap_err().code(), 8); // PostCommitError
    }

    #[test]
    fn test_script_sanitized() {
        let mut conv = make_converter();
        let output = conv
            .feed_chunk(b"<p>Safe</p><script>alert('xss')</script><p>Also safe</p>")
            .unwrap();
        let result = conv.finalize().unwrap();

        let mut full = Vec::new();
        full.extend_from_slice(&output.markdown);
        full.extend_from_slice(&result.final_markdown);
        let text = String::from_utf8(full).unwrap();
        assert!(
            !text.contains("alert"),
            "Script content should be removed: {}",
            text
        );
        assert!(
            text.contains("Safe"),
            "Safe content should remain: {}",
            text
        );
    }

    #[test]
    fn test_empty_input() {
        let conv = make_converter();
        let result = conv.finalize().unwrap();
        // extract_metadata is false by default → no ETag
        assert!(result.etag.is_none());
        assert!(result.token_estimate.is_some());
    }

    #[test]
    fn test_multi_chunk_feed() {
        let mut conv = make_converter();
        let out_title = conv.feed_chunk(b"<h1>Title</h1>").unwrap();
        let out_paragraph_one = conv.feed_chunk(b"<p>Paragraph one.</p>").unwrap();
        let out_paragraph_two = conv.feed_chunk(b"<p>Paragraph two.</p>").unwrap();
        let result = conv.finalize().unwrap();

        let mut full = Vec::new();
        full.extend_from_slice(&out_title.markdown);
        full.extend_from_slice(&out_paragraph_one.markdown);
        full.extend_from_slice(&out_paragraph_two.markdown);
        full.extend_from_slice(&result.final_markdown);
        let text = String::from_utf8(full).unwrap();
        assert!(text.contains("# Title"), "got: {}", text);
        assert!(text.contains("Paragraph one"), "got: {}", text);
        assert!(text.contains("Paragraph two"), "got: {}", text);
    }

    #[test]
    fn test_commit_state_transitions() {
        let mut conv = make_converter();
        assert_eq!(conv.commit_state(), CommitState::PreCommit);

        // Feed enough to produce output
        conv.feed_chunk(b"<h1>Title</h1>").unwrap();
        // After a heading with flush, should transition to PostCommit
        // (depends on whether the heading produced flushed output)
    }

    #[test]
    fn test_stats_populated() {
        let mut conv = make_converter();
        conv.feed_chunk(b"<h1>Title</h1><p>Content</p>").unwrap();
        let result = conv.finalize().unwrap();

        assert!(result.stats.tokens_processed > 0);
        assert!(result.stats.chunks_processed >= 1);
        assert_eq!(result.stats.parse_errors, 0);
    }

    #[test]
    fn test_parse_error_counter_increments() {
        use crate::streaming::tokenizer::TokenizerBatch;
        let mut conv = make_converter();
        let batch = TokenizerBatch {
            events: vec![StreamEvent::ParseError("broken tag".to_string())],
            token_count: 1,
            parse_errors: 1,
        };
        conv.process_tokenizer_batch(batch).unwrap();

        assert_eq!(conv.stats.parse_errors, 1);
        assert_eq!(conv.stats.tokens_processed, 1);
    }

    #[test]
    fn test_title_collector_respects_lookahead_limit() {
        let mut conv = make_converter_with_metadata();
        conv.budget.lookahead = 8;

        conv.append_title_text_bounded("abcdef");
        conv.append_title_text_bounded("ghijkl");

        assert_eq!(conv.html_title_buf, "abcdefgh");
    }

    /// Regression: peak_memory_estimate must reflect the working set
    /// (bounded state in memory), not cumulative output bytes. For a
    /// large document the working set should stay bounded while
    /// total output grows.
    #[test]
    fn test_peak_memory_is_working_set_not_cumulative_output() {
        let mut conv = make_converter();
        let tokenizer_reservation = conv.tokenizer.reserved_bytes();
        let mut total_output_bytes: usize = 0;
        // Feed a large-ish document in multiple chunks
        for _ in 0..50 {
            let out = conv
                .feed_chunk(b"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>")
                .unwrap();
            total_output_bytes = total_output_bytes.saturating_add(out.markdown.len());
        }
        let result = conv.finalize().unwrap();
        total_output_bytes = total_output_bytes.saturating_add(result.final_markdown.len());

        let peak = result.stats.peak_memory_estimate;
        let dynamic_peak = peak.saturating_sub(tokenizer_reservation);

        // The estimate includes a fixed conservative tokenizer envelope that
        // protects private html5ever/tendril capacity. The input-dependent
        // portion must still remain smaller than cumulative output.
        assert!(
            peak >= tokenizer_reservation,
            "peak must include the tokenizer reservation"
        );
        if total_output_bytes > 0 {
            assert!(
                dynamic_peak < total_output_bytes,
                "input-dependent peak ({}) should be less than total output bytes ({}); \
                 it should reflect resident state, not cumulative output",
                dynamic_peak,
                total_output_bytes,
            );
        }
    }

    /// Regression: PreCommit errors must preserve their original type
    /// (e.g. EncodingError), not be wrapped as InternalError.
    #[test]
    fn test_precommit_error_preserves_original_type() {
        let mut conv =
            StreamingConverter::new(ConversionOptions::default(), MemoryBudget::default());
        // Set an unsupported charset so the first feed_chunk fails
        conv.set_content_type(Some("text/html; charset=FAKE-ENCODING-999".to_string()));

        let err = conv.feed_chunk(b"<p>Hello</p>").unwrap_err();
        // Should be EncodingError (code 2), NOT InternalError (code 99)
        assert_eq!(
            err.code(),
            2,
            "PreCommit charset error should be EncodingError (code 2), got code {}: {}",
            err.code(),
            err
        );
    }

    /// Regression: token estimate must saturate to u32::MAX when the
    /// accumulated character count exceeds u32 range, not wrap around.
    #[test]
    fn test_token_estimate_saturates_on_overflow() {
        let mut conv = make_converter();
        // Directly set total_markdown_chars to a value that would overflow u32
        // when divided by 4. u32::MAX = 4_294_967_295, so we need
        // total_markdown_chars > u32::MAX * 4 = 17_179_869_180.
        conv.total_markdown_chars = u64::from(u32::MAX) * 4 + 100;

        let result = conv.finalize().unwrap();
        assert_eq!(
            result.token_estimate,
            Some(u32::MAX),
            "token estimate should saturate to u32::MAX, not wrap around"
        );
    }

    /// Regression: token estimate at the boundary should not overflow.
    #[test]
    fn test_token_estimate_at_u32_boundary() {
        let mut conv = make_converter();
        // Exactly u32::MAX * 4 chars → div_ceil(4) = u32::MAX, fits in u32
        conv.total_markdown_chars = u64::from(u32::MAX) * 4;

        let result = conv.finalize().unwrap();
        assert_eq!(
            result.token_estimate,
            Some(u32::MAX),
            "token estimate at boundary should be exactly u32::MAX"
        );
    }

    /// Regression: peak_memory_estimate must not grow with cumulative
    /// head_bytes_seen. After `</head>`, the head region is no longer
    /// in memory — only the extracted PageMetadata strings remain.
    /// A large <head> followed by body content should show a peak that
    /// reflects the metadata size, not the total head bytes processed.
    #[test]
    fn test_peak_memory_not_inflated_by_cumulative_head_bytes() {
        let mut conv = make_converter_with_metadata();
        let tokenizer_reservation = conv.tokenizer.reserved_bytes();

        // Build a large <head> with many meta tags
        let mut head = String::from("<html><head>");
        for i in 0..100 {
            head.push_str(&format!("<meta name=\"key{}\" content=\"value{}\">", i, i));
        }
        head.push_str("<title>Test Title</title></head>");

        // Feed the head
        conv.feed_chunk(head.as_bytes()).unwrap();

        // Record head_bytes_seen — this is the cumulative counter
        let cumulative_head = conv.head_bytes_seen;
        assert!(
            cumulative_head > 1000,
            "head_bytes_seen should be large: {}",
            cumulative_head
        );

        // Feed some body content
        conv.feed_chunk(b"<body><p>Body paragraph.</p></body></html>")
            .unwrap();
        let result = conv.finalize().unwrap();
        let dynamic_peak = result
            .stats
            .peak_memory_estimate
            .saturating_sub(tokenizer_reservation);

        // Excluding the fixed tokenizer envelope, the input-dependent working
        // set includes metadata strings and the transient transcoded output
        // buffer (which is bounded by the input chunk size) rather than
        // cumulative head volume. The transcoded buffer can be as large as
        // one feed_chunk input, so dynamic_peak may exceed head_bytes_seen
        // for small heads but must remain proportional to a single chunk.
        assert!(
            dynamic_peak < cumulative_head * 3,
            "input-dependent peak ({}) should be proportional to a single chunk, \
             not cumulative head_bytes_seen ({}) times a large factor",
            dynamic_peak,
            cumulative_head,
        );
    }

    /// Verify that peak_memory_estimate is in the same order of magnitude
    /// as metadata.bytes_estimate() for a head-heavy document with small
    /// metadata. The 100 meta tags above have unique names that don't
    /// match any extraction rule, so only the title is stored.
    #[test]
    fn test_peak_memory_proportional_to_metadata_not_head_volume() {
        let mut conv = make_converter_with_metadata();
        let tokenizer_reservation = conv.tokenizer.reserved_bytes();

        // Large head: 200 unrecognised meta tags → lots of head_bytes_seen,
        // but only the title is actually extracted into PageMetadata.
        let mut head = String::from("<html><head><title>Tiny</title>");
        for i in 0..200 {
            head.push_str(&format!(
                "<meta name=\"custom-unrecognised-{}\" content=\"{}\">",
                i,
                "x".repeat(50),
            ));
        }
        head.push_str("</head>");

        conv.feed_chunk(head.as_bytes()).unwrap();

        let metadata_size = conv.metadata().bytes_estimate();
        let cumulative_head = conv.head_bytes_seen;

        // metadata_size should be tiny (just "Tiny" = 4 bytes)
        assert!(
            metadata_size < 100,
            "metadata should be small: {} bytes",
            metadata_size
        );
        // head_bytes_seen should be large
        assert!(
            cumulative_head > 5000,
            "head_bytes_seen should be large: {} bytes",
            cumulative_head
        );

        conv.feed_chunk(b"<body><p>Content</p></body></html>")
            .unwrap();
        let result = conv.finalize().unwrap();
        let dynamic_peak = result
            .stats
            .peak_memory_estimate
            .saturating_sub(tokenizer_reservation);

        // Excluding the fixed parser envelope, peak should be dominated by
        // the largest single chunk's transcoded output plus metadata, not by
        // cumulative processing volume. Since the entire head is fed in one
        // chunk, the transcoded buffer is as large as the head itself, so
        // peak can exceed cumulative_head. The invariant is that peak grows
        // with the largest single chunk, not with the number of chunks or
        // cumulative volume — which would be unbounded.
        // A proportional check: peak should be at most 2× the largest chunk
        // (transcoded output + emitter buffers), not proportional to the
        // number of meta tags times their individual sizes.
        assert!(
            dynamic_peak < cumulative_head * 2,
            "input-dependent peak ({}) should be at most 2× cumulative head ({}) — \
             it should track single-chunk transcoded output plus metadata (~{}), \
             not unbounded cumulative processing",
            dynamic_peak,
            cumulative_head,
            metadata_size,
        );
    }

    // ── Regression tests for review round 5 ─────────────────────────

    /// P1 regression: with extract_metadata disabled (default), a large
    /// <head> must NOT trigger FrontMatterOverflow fallback.
    #[test]
    fn test_large_head_no_fallback_when_metadata_disabled() {
        let mut conv = make_converter(); // default: extract_metadata = false

        // Build a <head> that would exceed the lookahead budget
        let mut head = String::from("<html><head>");
        for i in 0..500 {
            head.push_str(&format!(
                "<meta name=\"k{}\" content=\"{}\">",
                i,
                "v".repeat(200),
            ));
        }
        head.push_str("</head><body><p>Content</p></body></html>");

        // Should succeed — no fallback because metadata extraction is off
        let result = conv.feed_chunk(head.as_bytes());
        assert!(
            !matches!(result, Err(ConversionError::StreamingFallback { .. })),
            "should not fallback when extract_metadata is disabled, got: {:?}",
            result,
        );
    }

    /// P2 regression: og:title must override <title>, matching
    /// MetadataExtractor behaviour.
    #[test]
    fn test_og_title_overrides_html_title() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <title>HTML Title</title>\
              <meta property=\"og:title\" content=\"OG Title\">\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        assert_eq!(
            conv.metadata().title.as_deref(),
            Some("OG Title"),
            "og:title should override <title>"
        );
    }

    /// P2 regression: twitter:description must override generic description.
    #[test]
    fn test_twitter_description_overrides_generic() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <meta name=\"description\" content=\"Generic\">\
              <meta name=\"twitter:description\" content=\"Twitter\">\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        assert_eq!(
            conv.metadata().description.as_deref(),
            Some("Twitter"),
            "twitter:description should override generic description"
        );
    }

    /// P3 regression: <link rel="canonical"> should be extracted as URL.
    #[test]
    fn test_canonical_link_extracted() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <link rel=\"canonical\" href=\"https://example.com/page\">\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        assert_eq!(
            conv.metadata().url.as_deref(),
            Some("https://example.com/page"),
        );
    }

    #[test]
    fn test_canonical_link_rejects_dangerous_url() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <link rel=\"canonical\" href=\"javascript:alert(1)\">\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();

        assert_eq!(conv.metadata().url, None);
    }

    #[test]
    fn test_metadata_image_rejects_dangerous_url_then_accepts_safe_url() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <meta property=\"og:image\" content=\"javascript:alert(1)\">\
              <meta property=\"og:image\" content=\"https://example.com/safe.png\">\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();

        assert_eq!(
            conv.metadata().image.as_deref(),
            Some("https://example.com/safe.png")
        );
    }

    #[test]
    fn test_og_url_rejects_dangerous_url() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <meta property=\"og:url\" content=\"data:text/html,<script>alert(1)</script>\">\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();

        assert_eq!(conv.metadata().url, None);
    }

    #[test]
    fn test_canonical_rel_uses_case_insensitive_token_list_matching() {
        let html = br#"<html><head>
            <link rel="alternate CANONICAL stylesheet"
                  href="https://example.com/token-canonical">
            </head><body><p>hello</p></body></html>"#;
        let mut conv = make_converter_with_metadata();

        conv.feed_chunk(html).unwrap();

        assert_eq!(
            conv.metadata().url.as_deref(),
            Some("https://example.com/token-canonical")
        );
    }

    #[test]
    fn test_total_budget_counts_resident_link_text() {
        let budget = MemoryBudget {
            total: 64 * 1024,
            state_stack: 128,
            output_buffer: 64 * 1024,
            charset_sniff: 16,
            lookahead: 16,
        };
        let mut conv = StreamingConverter::new(ConversionOptions::default(), budget);

        conv.feed_chunk(b"<body><a href='/'>").unwrap();
        let err = conv.feed_chunk(&vec![b'x'; 64 * 1024]).unwrap_err();

        assert_eq!(err.code(), 6);
    }

    /// P3 regression: when no canonical/og:url, finalize should fall back
    /// to options.base_url.
    #[test]
    fn test_url_falls_back_to_base_url() {
        let opts = ConversionOptions {
            extract_metadata: true,
            base_url: Some("https://fallback.example.com".to_string()),
            flavor: crate::converter::MarkdownFlavor::CommonMark,
            include_front_matter: false,
            simplify_navigation: true,
            preserve_tables: true,
            resolve_relative_urls: true,
            prune_config: crate::converter::pruning::PruneConfig::default_enabled(),
        };
        let mut conv = StreamingConverter::new(opts, MemoryBudget::default());
        conv.set_content_type(Some("text/html; charset=UTF-8".to_string()));

        conv.feed_chunk(b"<html><head><title>T</title></head><body><p>x</p></body></html>")
            .unwrap();
        // Before finalize, url should be None (no canonical/og:url)
        assert_eq!(conv.metadata().url, None);

        // After finalize, url should fall back to base_url
        let streaming_opts = ConversionOptions {
            extract_metadata: true,
            base_url: Some("https://fallback.example.com".to_string()),
            flavor: crate::converter::MarkdownFlavor::CommonMark,
            include_front_matter: false,
            simplify_navigation: true,
            preserve_tables: true,
            resolve_relative_urls: true,
            prune_config: crate::converter::pruning::PruneConfig::default_enabled(),
        };
        let mut conv2 = StreamingConverter::new(streaming_opts, MemoryBudget::default());
        conv2.set_content_type(Some("text/html; charset=UTF-8".to_string()));
        conv2
            .feed_chunk(b"<html><head><title>T</title></head><body><p>x</p></body></html>")
            .unwrap();
        // We can't inspect metadata after finalize (self consumed), but
        // we verified the pre-finalize state above. The base_url fallback
        // is applied inside finalize per the code path we added.
        let _ = conv2.finalize().unwrap();
        let _ = conv.finalize().unwrap();
    }

    /// P4 regression: title text split across events must preserve spaces.
    /// `<title>Hello <!--x--> World</title>` should produce "Hello  World"
    /// (with the space preserved), not "HelloWorld".
    #[test]
    fn test_title_preserves_spaces_across_events() {
        let mut conv = make_converter_with_metadata();
        // html5ever splits this into Text("Hello "), Comment("x"), Text(" World")
        conv.feed_chunk(
            b"<html><head><title>Hello <!-- comment --> World</title></head>\
              <body><p>x</p></body></html>",
        )
        .unwrap();
        let title = conv.metadata().title.as_deref().unwrap_or("");
        assert!(
            title.contains("Hello") && title.contains("World"),
            "title should contain both words: {:?}",
            title
        );
        // The space between Hello and World must be preserved
        assert!(
            !title.contains("HelloWorld"),
            "title should not lose spaces between events: {:?}",
            title
        );
    }

    /// P5 regression: Duration::MAX should not cause immediate timeout.
    #[test]
    fn test_duration_max_does_not_cause_immediate_timeout() {
        let mut conv = make_converter();
        conv.set_timeout(Duration::MAX);

        // Should succeed — Duration::MAX overflow is treated as no deadline
        let result = conv.feed_chunk(b"<p>Hello</p>");
        assert!(
            result.is_ok(),
            "Duration::MAX should not cause immediate timeout, got: {:?}",
            result,
        );
        let result = conv.finalize();
        assert!(result.is_ok());
    }

    // ── Regression tests for review round 6 ─────────────────────────

    /// P1 regression: og:title appearing before <title> must not be
    /// polluted by subsequent <title> text.
    #[test]
    fn test_og_title_before_html_title_not_polluted() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <meta property=\"og:title\" content=\"Social Title\">\
              <title>HTML Title</title>\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        assert_eq!(
            conv.metadata().title.as_deref(),
            Some("Social Title"),
            "og:title before <title> should not be overwritten or appended to"
        );
    }

    /// P1 regression: <title> before og:title — og:title should still win.
    #[test]
    fn test_html_title_then_og_title_social_wins() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <title>HTML Title</title>\
              <meta property=\"og:title\" content=\"Social Title\">\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        assert_eq!(
            conv.metadata().title.as_deref(),
            Some("Social Title"),
            "og:title should override <title> regardless of order"
        );
    }

    /// P2 regression: canonical URL must override og:url.
    #[test]
    fn test_canonical_overrides_og_url() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <meta property=\"og:url\" content=\"https://og.example.com\">\
              <link rel=\"canonical\" href=\"https://canonical.example.com\">\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        assert_eq!(
            conv.metadata().url.as_deref(),
            Some("https://canonical.example.com"),
            "canonical should override og:url"
        );
    }

    /// P3 regression: when a <meta> has both `name` and `property`,
    /// `property` must take precedence.
    #[test]
    fn test_property_takes_precedence_over_name() {
        let mut conv = make_converter_with_metadata();
        // name="description" would set generic description,
        // but property="og:title" should be used instead.
        conv.feed_chunk(
            b"<html><head>\
              <meta name=\"description\" property=\"og:title\" content=\"OG via property\">\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        // property="og:title" should win → title is set, description is NOT
        assert_eq!(
            conv.metadata().title.as_deref(),
            Some("OG via property"),
            "property attribute should take precedence over name"
        );
        assert_eq!(
            conv.metadata().description,
            None,
            "name='description' should be ignored when property is present"
        );
    }

    // ── Regression tests for review round 7 ─────────────────────────

    /// P1 regression: first canonical wins when multiple are present.
    #[test]
    fn test_first_canonical_wins() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <link rel=\"canonical\" href=\"https://first.example.com\">\
              <link rel=\"canonical\" href=\"https://second.example.com\">\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        assert_eq!(
            conv.metadata().url.as_deref(),
            Some("https://first.example.com"),
            "first canonical should win, not last"
        );
    }

    /// P1 regression: first canonical still overrides prior og:url.
    #[test]
    fn test_first_canonical_overrides_og_url_but_second_does_not() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <meta property=\"og:url\" content=\"https://og.example.com\">\
              <link rel=\"canonical\" href=\"https://first-canonical.example.com\">\
              <link rel=\"canonical\" href=\"https://second-canonical.example.com\">\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        assert_eq!(
            conv.metadata().url.as_deref(),
            Some("https://first-canonical.example.com"),
            "first canonical should override og:url; second canonical should not override first"
        );
    }

    /// P2 regression: first <title> wins when multiple are present.
    #[test]
    fn test_first_html_title_wins() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <title>First Title</title>\
              <title>Second Title</title>\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        assert_eq!(
            conv.metadata().title.as_deref(),
            Some("First Title"),
            "first <title> should win, not last"
        );
    }

    /// P2 regression: social title still overrides even with multiple <title>.
    #[test]
    fn test_social_title_wins_over_multiple_html_titles() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <title>First</title>\
              <meta property=\"og:title\" content=\"Social\">\
              <title>Second</title>\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        assert_eq!(
            conv.metadata().title.as_deref(),
            Some("Social"),
            "social title should win over all HTML titles"
        );
    }

    // ── Regression tests for review round 8 ─────────────────────────

    /// P1 regression: base_url overwrites og:url when no canonical is
    /// present, matching full-buffer MetadataExtractor::extract which
    /// unconditionally sets url = canonical.or(base_url) after meta tags.
    #[test]
    fn test_base_url_overwrites_og_url_when_no_canonical() {
        let opts = ConversionOptions {
            extract_metadata: true,
            base_url: Some("https://base.example.com".to_string()),
            flavor: crate::converter::MarkdownFlavor::CommonMark,
            include_front_matter: false,
            simplify_navigation: true,
            preserve_tables: true,
            resolve_relative_urls: true,
            prune_config: crate::converter::pruning::PruneConfig::default_enabled(),
        };
        let mut conv = StreamingConverter::new(opts, MemoryBudget::default());
        conv.set_content_type(Some("text/html; charset=UTF-8".to_string()));

        conv.feed_chunk(
            b"<html><head>\
              <meta property=\"og:url\" content=\"https://og.example.com\">\
              <title>T</title>\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();

        // Before finalize, og:url is set
        assert_eq!(
            conv.metadata().url.as_deref(),
            Some("https://og.example.com"),
        );

        // After finalize, base_url should overwrite og:url (no canonical)
        // We need a second converter to test post-finalize state since
        // finalize consumes self. Verify via a fresh instance.
        let alternate_opts = ConversionOptions {
            extract_metadata: true,
            base_url: Some("https://base.example.com".to_string()),
            flavor: crate::converter::MarkdownFlavor::CommonMark,
            include_front_matter: false,
            simplify_navigation: true,
            preserve_tables: true,
            resolve_relative_urls: true,
            prune_config: crate::converter::pruning::PruneConfig::default_enabled(),
        };
        let mut conv2 = StreamingConverter::new(alternate_opts, MemoryBudget::default());
        conv2.set_content_type(Some("text/html; charset=UTF-8".to_string()));
        conv2
            .feed_chunk(
                b"<html><head>\
                  <meta property=\"og:url\" content=\"https://og.example.com\">\
                  <title>T</title>\
                  </head><body><p>x</p></body></html>",
            )
            .unwrap();
        // Inspect internal state after finalize logic runs:
        // We can't call metadata() after finalize, but we can verify
        // the finalize path by checking that canonical_found is false
        // and the code path will overwrite with base_url.
        assert!(!conv2.canonical_found);
        let _ = conv2.finalize().unwrap();
        let _ = conv.finalize().unwrap();
    }

    /// P1 regression: when no canonical and no base_url, url becomes None
    /// (og:url is overwritten with None), matching full-buffer behaviour.
    #[test]
    fn test_no_canonical_no_base_url_clears_og_url() {
        let opts = ConversionOptions {
            extract_metadata: true,
            base_url: None,
            flavor: crate::converter::MarkdownFlavor::CommonMark,
            include_front_matter: false,
            simplify_navigation: true,
            preserve_tables: true,
            resolve_relative_urls: true,
            prune_config: crate::converter::pruning::PruneConfig::default_enabled(),
        };
        let mut conv = StreamingConverter::new(opts, MemoryBudget::default());
        conv.set_content_type(Some("text/html; charset=UTF-8".to_string()));

        conv.feed_chunk(
            b"<html><head>\
              <meta property=\"og:url\" content=\"https://og.example.com\">\
              <title>T</title>\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();

        // og:url was set during head processing
        assert_eq!(
            conv.metadata().url.as_deref(),
            Some("https://og.example.com"),
        );
        // After finalize: no canonical, no base_url → url should be None
        assert!(!conv.canonical_found);
        // The finalize path will set metadata.url = base_url.clone() = None
    }

    /// P2 regression: empty first <title> blocks second <title>.
    #[test]
    fn test_empty_first_title_blocks_second() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <title>   </title>\
              <title>Second Title</title>\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        // First <title> is whitespace-only → trimmed to "".
        // full-buffer find_title returns "" for the first match and stops.
        // Streaming should match: title is Some(""), second is ignored.
        assert_eq!(
            conv.metadata().title.as_deref(),
            Some(""),
            "empty first <title> should block second <title>"
        );
    }

    /// P2 regression: truly empty <title></title> also blocks.
    #[test]
    fn test_truly_empty_title_blocks_second() {
        let mut conv = make_converter_with_metadata();
        conv.feed_chunk(
            b"<html><head>\
              <title></title>\
              <title>Second</title>\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();
        assert_eq!(
            conv.metadata().title.as_deref(),
            Some(""),
            "empty <title></title> should block second <title>"
        );
    }

    // ── Regression tests for review round 9 ─────────────────────────

    /// Verifies that a `<link rel="canonical">` without an `href` is ignored and a later canonical with an `href` is selected.
    ///
    /// This test constructs a converter with metadata extraction enabled and a base URL, feeds an HTML head containing two
    /// canonical link tags (the first without `href`, the second with `href`), and asserts that the converter records the
    /// second link's URL as the canonical.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// // Equivalent test flow:
    /// let opts = ConversionOptions {
    ///     extract_metadata: true,
    ///     base_url: Some("https://base.example.com".to_string()),
    ///     flavor: crate::converter::MarkdownFlavor::CommonMark,
    ///     include_front_matter: false,
    ///     simplify_navigation: true,
    ///     preserve_tables: true,
    ///     resolve_relative_urls: true,
    ///     prune_config: crate::converter::pruning::PruneConfig::default_enabled(),
    /// };
    /// let mut conv = StreamingConverter::new(opts, MemoryBudget::default());
    /// conv.set_content_type(Some("text/html; charset=UTF-8".to_string()));
    /// conv.feed_chunk(b"<html><head>\
    ///                 <link rel=\"canonical\">\
    ///                 <link rel=\"canonical\" href=\"https://second.example.com\">\
    ///                 <title>T</title>\
    ///                 </head><body><p>x</p></body></html>").unwrap();
    /// assert!(conv.canonical_found);
    /// assert_eq!(conv.metadata().url.as_deref(), Some("https://second.example.com"));
    /// ```
    #[test]
    fn test_first_canonical_no_href_skipped_second_used() {
        let opts = ConversionOptions {
            extract_metadata: true,
            base_url: Some("https://base.example.com".to_string()),
            flavor: crate::converter::MarkdownFlavor::CommonMark,
            include_front_matter: false,
            simplify_navigation: true,
            preserve_tables: true,
            resolve_relative_urls: true,
            prune_config: crate::converter::pruning::PruneConfig::default_enabled(),
        };
        let mut conv = StreamingConverter::new(opts, MemoryBudget::default());
        conv.set_content_type(Some("text/html; charset=UTF-8".to_string()));

        conv.feed_chunk(
            b"<html><head>\
              <link rel=\"canonical\">\
              <link rel=\"canonical\" href=\"https://second.example.com\">\
              <title>T</title>\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();

        // The first canonical had no href → skipped.
        // The second canonical has href → canonical_found = true.
        assert!(conv.canonical_found);
        assert_eq!(
            conv.metadata().url.as_deref(),
            Some("https://second.example.com"),
            "second canonical (with href) should be used when first has no href"
        );
    }

    /// All canonicals have no href → canonical_found stays false → base_url.
    #[test]
    fn test_all_canonicals_no_href_falls_back_to_base() {
        let opts = ConversionOptions {
            extract_metadata: true,
            base_url: Some("https://base.example.com".to_string()),
            flavor: crate::converter::MarkdownFlavor::CommonMark,
            include_front_matter: false,
            simplify_navigation: true,
            preserve_tables: true,
            resolve_relative_urls: true,
            prune_config: crate::converter::pruning::PruneConfig::default_enabled(),
        };
        let mut conv = StreamingConverter::new(opts, MemoryBudget::default());
        conv.set_content_type(Some("text/html; charset=UTF-8".to_string()));

        conv.feed_chunk(
            b"<html><head>\
              <meta property=\"og:url\" content=\"https://og.example.com\">\
              <link rel=\"canonical\">\
              <link rel=\"canonical\">\
              <title>T</title>\
              </head><body><p>x</p></body></html>",
        )
        .unwrap();

        assert!(!conv.canonical_found);
        // og:url was set during head processing
        assert_eq!(
            conv.metadata().url.as_deref(),
            Some("https://og.example.com"),
        );

        // peek_final_url applies the convergence logic: no canonical found
        // → base_url overwrites og:url.
        assert_eq!(
            conv.peek_final_url().as_deref(),
            Some("https://base.example.com"),
            "no canonical with href → base_url should win over og:url"
        );
    }

    #[test]
    fn test_split_utf8_tail_empty_input() {
        let (valid, tail) = split_utf8_tail(b"");
        assert!(valid.is_empty());
        assert!(tail.is_empty());
    }

    #[test]
    fn test_split_utf8_tail_incomplete_two_byte_sequence() {
        let (valid, tail) = split_utf8_tail(&[0xE2, 0x82]);
        assert!(valid.is_empty());
        assert_eq!(tail, &[0xE2, 0x82]);
    }

    #[test]
    fn test_split_utf8_tail_incomplete_one_to_three_byte_cases() {
        let (_, tail_first_chunk) = split_utf8_tail(&[0xF0]);
        let (_, tail_second_chunk) = split_utf8_tail(&[0xF0, 0x9F]);
        let (_, tail_third_chunk) = split_utf8_tail(&[0xF0, 0x9F, 0x92]);

        assert_eq!(tail_first_chunk, &[0xF0]);
        assert_eq!(tail_second_chunk, &[0xF0, 0x9F]);
        assert_eq!(tail_third_chunk, &[0xF0, 0x9F, 0x92]);
    }

    #[test]
    fn test_split_utf8_tail_invalid_interior_fallback() {
        // Invalid bytes are not repairable by future chunks, so they must be
        // handled by lossy conversion in the current tokenizer state.
        let bytes = [0x48, 0x65, 0xFF, 0x6C, 0x6F];
        let (valid, tail) = split_utf8_tail(&bytes);
        assert_eq!(valid, &bytes);
        assert!(tail.is_empty());

        // No lead byte candidate near the tail: fallback returns the full slice.
        let continuation_only = [0x80, 0x80];
        let (valid2, tail2) = split_utf8_tail(&continuation_only);
        assert_eq!(valid2, &continuation_only);
        assert!(tail2.is_empty());
    }

    #[test]
    fn test_split_utf8_tail_invalid_complete_sequence_at_start() {
        let bytes = [0xC2, 0x41];
        let (valid, tail) = split_utf8_tail(&bytes);

        assert_eq!(valid, &bytes);
        assert!(tail.is_empty());
    }

    #[test]
    fn test_split_utf8_tail_incomplete_then_invalid_followup_recovers() {
        let first_chunk = [0x41, 0xC2];
        let (valid_first_chunk, tail1) = split_utf8_tail(&first_chunk);
        assert_eq!(valid_first_chunk, b"A");
        assert_eq!(tail1, &[0xC2]);

        let second_chunk = [tail1[0], 0x41];
        let (valid_second_chunk, tail2) = split_utf8_tail(&second_chunk);
        assert_eq!(valid_second_chunk, &second_chunk);
        assert!(tail2.is_empty());
    }

    #[test]
    fn test_split_utf8_tail_invalid_four_byte_start_not_deferred() {
        let bytes = [0xF0, 0x28, 0x8C, 0xBC];
        let (valid, tail) = split_utf8_tail(&bytes);

        assert_eq!(valid, &bytes);
        assert!(tail.is_empty());
    }

    #[test]
    fn test_streaming_invalid_utf8_tail_matches_single_pass() {
        let html = &[
            0x50, 0x3C, 0x7E, 0x32, 0x7C, 0x00, 0x2D, 0xCF, 0x37, 0x7C, 0x20, 0x2D, 0x2D, 0x20,
            0x7C, 0x5E, 0x5E, 0x45, 0x05, 0x45, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00,
            0x00, 0x01, 0x45, 0x7C, 0x00, 0x2D, 0xCF, 0x37, 0x7C, 0x20, 0x2D, 0x7C, 0x20, 0x7C,
            0x7C, 0x0A, 0x20, 0x2D, 0x2F, 0x20, 0x61, 0x20, 0x74, 0x20, 0x5D, 0x3F, 0x3C, 0x70,
            0x72, 0x65, 0x20, 0x7C, 0x20, 0x32, 0x3E, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60,
            0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60,
            0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60,
            0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x45, 0x45, 0x45, 0x00,
            0x00, 0x00, 0x34, 0x45, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60, 0x60,
            0x60, 0x60, 0x60, 0x00, 0x00, 0x00, 0x42, 0x00, 0x50, 0x60, 0x60, 0x60, 0x3E, 0x3E,
            0x3E, 0x3E, 0x3E, 0x81, 0xA5, 0xA5, 0xA5, 0xA5, 0xA5, 0xA5, 0xA5, 0xA5, 0xA5, 0x7B,
            0x7B, 0x7B, 0x7B,
        ];
        let single = convert_with_splits(html, &[html.len()]);
        let chunked = convert_with_splits(html, &[1, 24, 28, 5, 5, 1, 1, 5, 88]);

        if single != chunked {
            let first_diff = single
                .iter()
                .zip(chunked.iter())
                .position(|(left, right)| left != right)
                .unwrap_or_else(|| single.len().min(chunked.len()));
            let start = first_diff.saturating_sub(16);
            let single_end = first_diff.saturating_add(48).min(single.len());
            let chunked_end = first_diff.saturating_add(48).min(chunked.len());
            panic!(
                "first_diff={first_diff}, single_len={}, chunked_len={}, single={:?}, chunked={:?}",
                single.len(),
                chunked.len(),
                String::from_utf8_lossy(&single[start..single_end]),
                String::from_utf8_lossy(&chunked[start..chunked_end])
            );
        }
    }

    #[test]
    fn test_utf8_tail_remains_one_incomplete_code_point() {
        let mut conv = make_converter();

        conv.process_utf8_bytes(b"<p>\xE2", false)
            .expect("one-byte UTF-8 tail should be retained");
        assert_eq!(conv.utf8_tail, [0xE2]);

        conv.process_utf8_bytes(&[0x00, 0x00, 0xE2, 0xF0, 0x80], false)
            .expect("pending tail recovery must not append a second tail");
        assert!(conv.utf8_tail.len() <= 3);
        assert_eq!(conv.utf8_tail, [0xF0, 0x80]);

        conv.process_utf8_bytes(&[0x80, 0x80, b'<'], false)
            .expect("completed tail should not leave a stale continuation");
        assert!(conv.utf8_tail.is_empty());
    }

    #[test]
    fn test_utf8_tail_lengths_flush_at_eof() {
        for tail in [&[0xE2][..], &[0xE2, 0x82][..], &[0xF0, 0x90, 0x80][..]] {
            let mut conv = make_converter();

            conv.process_utf8_bytes(tail, false)
                .expect("incomplete UTF-8 tail should be retained");
            assert_eq!(conv.utf8_tail, tail);
            assert!(conv.utf8_tail.len() <= 3);

            conv.process_utf8_bytes(&[], true)
                .expect("EOF must flush the final incomplete sequence");
            assert!(conv.utf8_tail.is_empty());
        }
    }

    fn decode_base64_fixture(encoded: &str) -> Vec<u8> {
        let mut output = Vec::new();
        let mut value = 0u32;
        let mut bits = 0u32;

        for byte in encoded.bytes().filter(|byte| !byte.is_ascii_whitespace()) {
            let sextet = match byte {
                b'A'..=b'Z' => byte - b'A',
                b'a'..=b'z' => byte - b'a' + 26,
                b'0'..=b'9' => byte - b'0' + 52,
                b'+' => 62,
                b'/' => 63,
                b'=' => break,
                _ => panic!("invalid base64 fixture byte"),
            };
            value = (value << 6) | u32::from(sextet);
            bits += 6;
            while bits >= 8 {
                bits -= 8;
                output.push((value >> bits) as u8);
                value &= (1 << bits) - 1;
            }
        }

        output
    }

    fn assert_clusterfuzz_utf8_tail_fixture_does_not_panic(input: &[u8]) {
        let mut conv = make_converter();
        let mut cursor = 0usize;

        for (index, byte) in input.iter().take(64).enumerate() {
            let remaining = input.len().saturating_sub(cursor);
            if remaining == 0 {
                break;
            }
            let raw = if index % 8 == 0 {
                usize::from(*byte).saturating_mul(8).max(1)
            } else {
                usize::from(*byte % 32).max(1)
            };
            let end = cursor.saturating_add(raw).min(input.len());
            if conv.feed_chunk(&input[cursor..end]).is_err() {
                break;
            }
            cursor = end;
            assert!(conv.utf8_tail.len() <= 3);
        }
        if cursor < input.len() {
            let _ = conv.feed_chunk(&input[cursor..]);
            assert!(conv.utf8_tail.len() <= 3);
        }
        conv.process_utf8_bytes(&[], true)
            .expect("EOF must flush the minimized regression tail");
        assert!(conv.utf8_tail.is_empty());
        let _ = conv.finalize();
    }

    #[test]
    fn test_clusterfuzz_utf8_tail_original_regression_does_not_panic() {
        let input =
            decode_base64_fixture(include_str!("fixtures/clusterfuzz_utf8_tail_original.b64"));

        assert_clusterfuzz_utf8_tail_fixture_does_not_panic(&input);
    }

    #[test]
    fn test_clusterfuzz_utf8_tail_minimized_regression_does_not_panic() {
        let input =
            decode_base64_fixture(include_str!("fixtures/clusterfuzz_utf8_tail_minimized.b64"));

        assert_clusterfuzz_utf8_tail_fixture_does_not_panic(&input);
    }

    #[test]
    fn test_utf8_tail_invariant_for_bytewise_and_mixed_boundaries() {
        let input = b"\xEF\xBB\xBF<p>\xE2\x82\xAC \xF0\x9F\x98\x80</p>\xE2\x82";

        for width in [1usize, 2, 3, 5] {
            let mut conv = make_converter();
            for chunk in input.chunks(width) {
                conv.process_utf8_bytes(chunk, false)
                    .expect("boundary split must not fail precommit");
                assert!(conv.utf8_tail.len() <= 3);
            }
            conv.process_utf8_bytes(&[], true)
                .expect("EOF must flush every final UTF-8 tail");
            assert!(conv.utf8_tail.is_empty());
        }
    }

    proptest! {
        #[test]
        fn prop_utf8_tail_is_single_incomplete_code_point(
            input in proptest::collection::vec(any::<u8>(), 0..256),
            widths in proptest::collection::vec(1usize..32, 1..32),
        ) {
            let mut conv = make_converter();
            let mut offset = 0usize;

            for width in widths {
                if offset >= input.len() {
                    break;
                }
                let end = offset.saturating_add(width).min(input.len());
                let _ = conv.process_utf8_bytes(&input[offset..end], false);
                prop_assert!(conv.utf8_tail.len() <= 3);
                offset = end;
            }
            if offset < input.len() {
                let _ = conv.process_utf8_bytes(&input[offset..], false);
                prop_assert!(conv.utf8_tail.len() <= 3);
            }
            let _ = conv.process_utf8_bytes(&[], true);
            prop_assert!(conv.utf8_tail.is_empty());
        }
    }

    #[test]
    fn test_oversized_utf8_tail_is_a_precommit_error() {
        let mut conv = make_converter();
        conv.utf8_tail.extend_from_slice(&[0xF0, 0x90, 0x80, 0x80]);

        let err = conv
            .process_utf8_bytes(b"x", false)
            .expect_err("corrupt UTF-8 tail must not panic");
        assert!(matches!(err, ConversionError::InternalError(_)));
    }

    #[test]
    fn test_oversized_utf8_tail_is_wrapped_postcommit() {
        let mut conv = make_converter();
        conv.commit_state = CommitState::PostCommit;
        conv.utf8_tail.extend_from_slice(&[0xF0, 0x90, 0x80, 0x80]);

        let err = conv
            .process_utf8_bytes(b"x", false)
            .expect_err("corrupt UTF-8 tail must not panic postcommit");
        assert!(matches!(err, ConversionError::PostCommitError { .. }));
    }

    /// Parser budget enforcement: when the cumulative input bytes exceed
    /// parser_budget, feed_chunk must return ParseBudgetExceeded (code 11).
    #[test]
    fn test_parser_budget_exceeded() {
        let mut conv = make_converter();
        conv.set_parser_budget(50); // very small budget

        // Feed more than 50 bytes total
        let chunk = b"<p>Hello world, this is a paragraph that exceeds the parser budget.</p>";
        let result = conv.feed_chunk(chunk);
        assert!(
            result.is_err(),
            "feed_chunk should fail when parser budget exceeded"
        );
        let err = result.unwrap_err();
        assert_eq!(
            err.code(),
            11,
            "Error code should be ERROR_PARSE_BUDGET_EXCEEDED (11)"
        );
    }

    /// Parser budget enforcement: when parser_budget is 0, enforcement is
    /// disabled and arbitrarily large inputs are accepted.
    #[test]
    fn test_parser_budget_zero_means_unlimited() {
        let mut conv = make_converter();
        conv.set_parser_budget(0); // disabled

        let chunk = b"<p>Hello world, this is a paragraph.</p>";
        let result = conv.feed_chunk(chunk);
        assert!(result.is_ok(), "parser_budget=0 should not limit input");
    }

    /// Parser budget enforcement: cumulative tracking across multiple
    /// feed_chunk calls.
    #[test]
    fn test_parser_budget_cumulative_across_chunks() {
        let mut conv = make_converter();
        conv.set_parser_budget(100); // 100 byte budget

        // First chunk: within budget (must not produce output to stay pre-commit)
        let chunk1 = b"<head><title>Small</title></head>";
        let r1 = conv.feed_chunk(chunk1);
        assert!(r1.is_ok(), "First chunk within budget should succeed");

        // Second chunk: pushes total over 100 bytes (still pre-commit)
        let chunk2 =
            b"<body><p>Second chunk of data that exceeds the cumulative budget limit here.</p>";
        let r2 = conv.feed_chunk(chunk2);
        assert!(
            r2.is_err(),
            "Second chunk should exceed cumulative parser budget"
        );
        let err = r2.unwrap_err();
        // In pre-commit state, the raw ParseBudgetExceeded error is returned
        assert_eq!(err.code(), 11);
    }

    /// Parser budget enforcement: when exceeded post-commit, the error is
    /// wrapped as PostCommitError with original_code == 11.
    #[test]
    fn test_parser_budget_exceeded_post_commit() {
        let mut conv = make_converter();
        conv.set_parser_budget(200); // budget large enough for first chunks

        // Feed enough to produce output (transition to post-commit)
        let chunk1 = b"<h1>Title</h1><p>Paragraph one.</p>";
        let r1 = conv.feed_chunk(chunk1);
        assert!(r1.is_ok(), "First chunk should succeed");

        // Feed more to push past budget in post-commit state
        let chunk2_data = vec![b'x'; 200];
        let mut chunk2 = b"<p>".to_vec();
        chunk2.extend_from_slice(&chunk2_data);
        chunk2.extend_from_slice(b"</p>");
        let r2 = conv.feed_chunk(&chunk2);
        assert!(
            r2.is_err(),
            "Should fail after exceeding parser budget post-commit"
        );
        let err = r2.unwrap_err();
        // Post-commit errors are wrapped as ERROR_POST_COMMIT (8)
        assert_eq!(
            err.code(),
            8,
            "Post-commit parser budget error should be code 8"
        );
    }

    /// Regression: a UTF-8 BOM (U+FEFF) whose lead byte (0xEF) is split
    /// across chunk boundaries must not be stripped by html5ever.  The
    /// streaming tokenizer sets `discard_bom: false` and the converter
    /// strips a leading BOM once at stream start, so mid-stream BOMs are
    /// preserved consistently between single-chunk and multi-chunk paths.
    #[test]
    fn test_bom_split_across_chunk_boundary() {
        // Input contains a BOM (0xEF 0xBB 0xBF) at byte 79, split at 80.
        let data: &[u8] = &[
            0x0a, 0x0a, 0x05, 0x0a, 0x0a, 0x55, 0xbd, 0x21, 0x0a, 0x0a, 0x13, 0x0a, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x2c, 0xbf, 0xbd, 0x00, 0xbe, 0xbe, 0xbe, 0xbe, 0xbe, 0xbe, 0xbe,
            0x3c, 0xbd, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0xbd, 0xef, 0xbf, 0xbd, 0xef, 0xbf, 0xbd, 0x94, 0x94, 0x0a, 0x94, 0x94,
            0x96, 0x94, 0x00, 0x09, 0x94, 0x94, 0x94, 0x94, 0x94, 0xef, 0xbf, 0xbd, 0xef, 0xbf,
            0xbd, 0x65, 0x38, 0x38, 0x38, 0x38, 0x75, 0xef, 0xbf, 0xbd, 0xef, 0xbb, 0xbf, 0xbd,
            0x0a, 0xed,
        ];
        let html = &data[1..]; // skip seed byte
        let single = convert_with_splits(html, &[html.len()]);
        let chunked = convert_with_splits(html, &[80, 5]);
        assert_eq!(
            single, chunked,
            "BOM split across chunk boundary must not change output"
        );
    }

    /// Regression: a leading BOM at stream start must be stripped,
    /// matching the full-buffer path's `discard_bom: true` behavior.
    #[test]
    fn test_leading_bom_stripped_at_stream_start() {
        let html = b"\xEF\xBB\xBF<p>hello</p>";
        let result = convert_with_splits(html, &[html.len()]);
        let s = String::from_utf8_lossy(&result);
        assert!(
            !s.contains('\u{FEFF}'),
            "Leading BOM should be stripped, got: {:?}",
            s
        );
    }

    /// Regression: a leading BOM split across chunks must still be stripped.
    #[test]
    fn test_leading_bom_split_across_chunks_stripped() {
        let html = b"\xEF\xBB\xBF<p>hello</p>";
        let single = convert_with_splits(html, &[html.len()]);
        // Split inside the BOM: [0xEF] and [0xBB, 0xBF, <p>hello</p>]
        let chunked = convert_with_splits(html, &[1, html.len() - 1]);
        assert_eq!(
            single, chunked,
            "Leading BOM split across chunks must be stripped consistently"
        );
    }
}
