//! Structural state machine for tracking HTML document context.
//!
//! Maintains a bounded stack of [`StructuralContext`] values that the
//! [`IncrementalEmitter`](super::emitter::IncrementalEmitter) uses to
//! produce correct Markdown syntax.

use crate::error::ConversionError;
use crate::streaming::budget::MemoryBudget;
use crate::streaming::types::StreamEvent;

/// Document structure context tracked on the state stack.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StructuralContext {
    /// Document root.
    Root,
    /// Heading level (h1-h6).
    Heading(u8),
    /// Paragraph.
    Paragraph,
    /// Ordered list with current item number.
    OrderedList(u32),
    /// Unordered list.
    UnorderedList,
    /// List item.
    ListItem,
    /// Code block with optional language identifier.
    CodeBlock(Option<String>),
    /// Inline code.
    InlineCode,
    /// Blockquote.
    Blockquote,
    /// Link with href.
    Link(String),
    /// Image with src and alt text.
    Image { src: String, alt: String },
    /// Bold text.
    Bold,
    /// Italic text.
    Italic,
    /// Table element (triggers fallback).
    Table,
}

/// Action produced by the state machine for the emitter.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StateMachineAction {
    /// Push a new context and begin emitting for it.
    Enter(StructuralContext),
    /// Pop the current context and finalize its emission.
    Exit(StructuralContext),
    /// Pop all contexts from the stack top down to and including the
    /// matching context.  Used for misnested HTML where the matching
    /// tag is not at the top of the stack.
    ExitMany(Vec<StructuralContext>),
    /// Emit text content within the current context.
    Text(String),
    /// An unsupported HTML structure was detected — signal fallback.
    ///
    /// The embedded string identifies the structure (e.g. `"table"`,
    /// `"svg"`, `"canvas"`) for internal fallback classification.
    FallbackRequired(String),
    /// No action needed (e.g., for ignored events).
    None,
}

/// Structural state machine with bounded stack.
///
/// Tracks document structure context for the Markdown emitter. The stack
/// depth is bounded by [`MemoryBudget::state_stack`] to enforce the
/// bounded-memory contract.
pub struct StructuralStateMachine {
    /// Bounded context stack.
    stack: Vec<StructuralContext>,
    /// Memory budget used for stack enforcement.
    budget: MemoryBudget,
    /// **Deprecated / dead field.** The [`IncrementalEmitter`](super::emitter::IncrementalEmitter)
    /// now manages block-separator state internally via its own `needs_block_separator`
    /// tracking, making this field redundant. Retained for internal API
    /// compatibility; safe to remove in the next breaking-change release.
    pub needs_block_separator: bool,
    /// Current list nesting depth (for indentation).
    pub list_depth: usize,
    /// Current blockquote nesting depth.
    pub blockquote_depth: usize,
    /// Whether we are inside the `<head>` region.
    pub in_head: bool,
    /// Whether we are inside a `<pre>` region.
    pub in_preformatted: bool,
    /// Current ordered list item counters per nesting level.
    ordered_list_counters: Vec<u32>,
}

impl StructuralStateMachine {
    pub(crate) fn is_safe_code_fence_language(value: &str) -> bool {
        if value.is_empty() {
            return false;
        }
        value.bytes().all(|byte| {
            byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'+' | b'.' | b'#' | b'-')
        })
    }

    /// Create a StructuralStateMachine with a maximum stack depth derived from `budget`.
    ///
    /// The `state_stack` byte allowance from `MemoryBudget` is enforced using
    /// an estimated 64 bytes per `StructuralContext` stack entry.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let budget = MemoryBudget { state_stack: 1024 };
    /// let sm = StructuralStateMachine::new(&budget);
    /// // new machine starts with an empty stack
    /// assert_eq!(sm.depth(), 0);
    /// ```
    pub fn new(budget: &MemoryBudget) -> Self {
        Self {
            stack: Vec::new(),
            budget: budget.clone(),
            needs_block_separator: false,
            list_depth: 0,
            blockquote_depth: 0,
            in_head: false,
            in_preformatted: false,
            ordered_list_counters: Vec::new(),
        }
    }

    /// Update the state machine with a stream event and produce the corresponding emitter action.
    ///
    /// Processes a sanitized `StreamEvent`, updating internal structural state (stack, nesting counters,
    /// and flags) as needed and returning a `StateMachineAction` that directs the emitter.
    ///
    /// # Returns
    ///
    /// `StateMachineAction` indicating how the emitter should proceed (`Enter`, `Exit`, `Text`,
    /// `FallbackRequired(structure)`, or `None`).
    ///
    /// # Errors
    ///
    /// Returns `ConversionError::BudgetExceeded` if pushing a new context would exceed the configured
    /// state stack budget.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// use nginx_markdown_converter::streaming::state_machine::{StructuralStateMachine, StreamEvent, StateMachineAction};
    /// use nginx_markdown_converter::memory::MemoryBudget;
    ///
    /// let budget = MemoryBudget { state_stack: 1024 }; // example budget
    /// let mut sm = StructuralStateMachine::new(&budget);
    /// let action = sm.process_event(&StreamEvent::Text("hello".into())).unwrap();
    /// assert_eq!(action, StateMachineAction::Text("hello".into()));
    /// ```
    pub fn process_event(
        &mut self,
        event: &StreamEvent,
    ) -> Result<StateMachineAction, ConversionError> {
        match event {
            StreamEvent::StartTag {
                name,
                attrs,
                self_closing,
            } => self.handle_start_tag(name, attrs, *self_closing),
            StreamEvent::EndTag { name } => self.handle_end_tag(name),
            StreamEvent::Text(text) => Ok(StateMachineAction::Text(text.clone())),
            StreamEvent::Comment(_) | StreamEvent::Doctype | StreamEvent::ParseError(_) => {
                Ok(StateMachineAction::None)
            }
        }
    }

    /// Handle an HTML start tag by updating the structural state machine and producing an action for the emitter.
    ///
    /// Recognizes common structural and inline tags, updates nesting trackers (lists, blockquotes, preformatted/head), extracts
    /// attributes for links/images/ordered lists/code languages, and either pushes a corresponding `StructuralContext` or
    /// returns an immediate action. Unsupported start tags (table, svg, math, canvas) produce
    /// `StateMachineAction::FallbackRequired(structure)`. Some tags
    /// (structural wrappers, unknown tags, and `head`) are ignored and produce `StateMachineAction::None`. A self-closing
    /// `img` produces an `Enter(Image { .. })` without pushing an additional inline context.
    ///
    /// # Errors
    /// Returns `ConversionError::BudgetExceeded` if pushing a new context would exceed the configured stack budget.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// use nginx_markdown_converter::streaming::state_machine::*;
    ///
    /// let budget = MemoryBudget::default();
    /// let mut sm = StructuralStateMachine::new(&budget);
    /// let action = sm.handle_start_tag("p", &[], false).unwrap();
    /// assert!(matches!(action, StateMachineAction::Enter(_)));
    /// ```
    fn handle_start_tag(
        &mut self,
        name: &str,
        attrs: &[(String, String)],
        _self_closing: bool,
    ) -> Result<StateMachineAction, ConversionError> {
        let ctx = match name {
            "h1" => StructuralContext::Heading(1),
            "h2" => StructuralContext::Heading(2),
            "h3" => StructuralContext::Heading(3),
            "h4" => StructuralContext::Heading(4),
            "h5" => StructuralContext::Heading(5),
            "h6" => StructuralContext::Heading(6),
            "p" => StructuralContext::Paragraph,
            "ol" => {
                let start = attrs
                    .iter()
                    .find(|(k, _)| k == "start")
                    .and_then(|(_, v)| v.parse::<u32>().ok())
                    .unwrap_or(1);
                self.list_depth = self.list_depth.saturating_add(1);
                self.ordered_list_counters.push(start);
                StructuralContext::OrderedList(start)
            }
            "ul" => {
                self.list_depth = self.list_depth.saturating_add(1);
                StructuralContext::UnorderedList
            }
            "li" => StructuralContext::ListItem,
            "pre" => {
                self.in_preformatted = true;
                StructuralContext::CodeBlock(None)
            }
            "code" => {
                // If parent is CodeBlock (pre>code), extract language from class
                if self.current_context() == Some(&StructuralContext::CodeBlock(None)) {
                    let lang = attrs.iter().find(|(k, _)| k == "class").and_then(|(_, v)| {
                        v.split_whitespace()
                            .filter_map(|class| {
                                class
                                    .strip_prefix("language-")
                                    .or_else(|| class.strip_prefix("lang-"))
                            })
                            .find(|language| Self::is_safe_code_fence_language(language))
                            .map(ToOwned::to_owned)
                    });
                    if lang.is_some() {
                        // Update the parent CodeBlock context with the language
                        if let Some(last) = self.stack.last_mut() {
                            *last = StructuralContext::CodeBlock(lang.clone());
                        }
                    }
                    // Don't push separate context for code inside pre
                    return Ok(StateMachineAction::None);
                }
                StructuralContext::InlineCode
            }
            "blockquote" => {
                self.blockquote_depth = self.blockquote_depth.saturating_add(1);
                StructuralContext::Blockquote
            }
            "a" => {
                let href = attrs
                    .iter()
                    .find(|(k, _)| k == "href")
                    .map(|(_, v)| v.clone())
                    .unwrap_or_default();
                StructuralContext::Link(href)
            }
            "img" => {
                let src = attrs
                    .iter()
                    .find(|(k, _)| k == "src")
                    .map(|(_, v)| v.clone())
                    .unwrap_or_default();
                let alt = attrs
                    .iter()
                    .find(|(k, _)| k == "alt")
                    .map(|(_, v)| v.clone())
                    .unwrap_or_default();
                let ctx = StructuralContext::Image { src, alt };
                // <img> is a void element — always emit Enter without
                // pushing to the stack, regardless of whether the HTML
                // uses XHTML-style self-closing (`<img />`). html5ever's
                // tokenizer sets self_closing only for the slash form,
                // but <img> never has a matching end tag either way.
                return Ok(StateMachineAction::Enter(ctx));
            }
            "video" | "audio" => {
                if let Some(src) = attrs
                    .iter()
                    .find(|(k, _)| k == "src")
                    .map(|(_, v)| v.clone())
                {
                    // Media elements with inline src are emitted as URL-bearing
                    // artifacts for parity with full-buffer URL extraction.
                    let ctx = StructuralContext::Image {
                        src,
                        alt: name.to_string(),
                    };
                    return Ok(StateMachineAction::Enter(ctx));
                }
                // No inline src (for example <video><source ...>): child tags
                // may still carry extractable URLs.
                return Ok(StateMachineAction::None);
            }
            "source" | "track" | "area" => {
                if let Some(src) = attrs
                    .iter()
                    .find(|(k, _)| *k == "src" || *k == "href")
                    .map(|(_, v)| v.clone())
                {
                    let ctx = StructuralContext::Image {
                        src,
                        alt: name.to_string(),
                    };
                    return Ok(StateMachineAction::Enter(ctx));
                }
                return Ok(StateMachineAction::None);
            }
            "strong" | "b" => StructuralContext::Bold,
            "em" | "i" => StructuralContext::Italic,
            "table" | "thead" | "tbody" | "tr" | "th" | "td" => {
                return Ok(StateMachineAction::FallbackRequired("table".to_string()));
            }
            "svg" | "math" => {
                return Ok(StateMachineAction::FallbackRequired(name.to_string()));
            }
            "canvas" => {
                return Ok(StateMachineAction::FallbackRequired("canvas".to_string()));
            }
            "head" => {
                self.in_head = true;
                return Ok(StateMachineAction::None);
            }
            // Structural wrappers and inline elements — pass through
            "html" | "body" | "div" | "span" | "section" | "article" | "main" | "header"
            | "footer" | "nav" | "aside" | "figure" | "figcaption" | "details" | "summary"
            | "mark" | "time" | "abbr" | "cite" | "dfn" | "sub" | "sup" | "small" | "del"
            | "ins" | "s" | "br" | "hr" | "wbr" => {
                // Implicit </head>: html5ever's tokenizer (not tree builder)
                // does not emit an EndTag("head") when <body> appears, so we
                // must clear in_head here to stop metadata extraction from
                // running on body content.
                if name == "body" {
                    self.in_head = false;
                }
                return Ok(StateMachineAction::None);
            }
            // Unknown elements — pass through
            _ => {
                return Ok(StateMachineAction::None);
            }
        };

        self.push_context(ctx.clone())?;
        Ok(StateMachineAction::Enter(ctx))
    }

    /// Process an HTML end tag, pop the corresponding structural context if present, and update
    /// internal nesting/tracking state accordingly.
    ///
    /// For matching contexts (e.g., headings, paragraphs, list items, pre/code, blockquotes,
    /// links, emphasis), this removes the nearest matching context from the stack, adjusts
    /// list or blockquote depths or the preformatted flag as appropriate,
    /// and returns `StateMachineAction::Exit` (or `ExitMany` for misnested HTML)
    /// with the popped context. Special-case behavior:
    /// - `ol` and `ul`: decrement `list_depth`; `ol` also pops the ordered-list counter.
    /// - `head`: sets `in_head` to `false` and does not modify the stack.
    /// - Unknown or unmatched end tags produce `StateMachineAction::None`.
    ///
    /// # Returns
    ///
    /// `StateMachineAction::Exit(ctx)` when a matching context `ctx` was popped, `StateMachineAction::None` otherwise.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// // Illustrative usage; actual construction of `StructuralStateMachine` and pushing of
    /// // contexts is required for a non-None result.
    /// let mut sm = StructuralStateMachine::new(&MemoryBudget::default());
    /// let action = sm.handle_end_tag("p").unwrap();
    /// // If no matching `Paragraph` context was on the stack, this yields `StateMachineAction::None`.
    /// assert!(matches!(action, StateMachineAction::None));
    /// ```
    fn handle_end_tag(&mut self, name: &str) -> Result<StateMachineAction, ConversionError> {
        match name {
            "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "p" | "li" | "pre" | "blockquote" | "a"
            | "strong" | "b" | "em" | "i" | "code" => self.pop_and_update_derived_state(name),
            "ol" | "ul" => self.pop_and_update_derived_state(name),
            "head" => {
                self.in_head = false;
                Ok(StateMachineAction::None)
            }
            _ => Ok(StateMachineAction::None),
        }
    }

    /// Shared end-tag logic: pop contexts up to `tag_name`, reconcile
    /// derived state for every popped context, and return the appropriate
    /// exit action.
    ///
    /// For each `StructuralContext` drained from the stack:
    /// - `OrderedList` → decrement `list_depth` and pop the counter
    /// - `UnorderedList` → decrement `list_depth`
    /// - `Blockquote` → decrement `blockquote_depth`
    /// - `CodeBlock` → clear `in_preformatted`
    ///
    /// This ensures misnested HTML that implicitly closes an `OrderedList`
    /// (e.g. `</ul>` or `</blockquote>` draining an inner `<ol>`) always
    /// leaves `ordered_list_counters` consistent with the stack.
    fn pop_and_update_derived_state(
        &mut self,
        tag_name: &str,
    ) -> Result<StateMachineAction, ConversionError> {
        let popped = self.pop_contexts_up_to(tag_name);
        if popped.is_empty() {
            return Ok(StateMachineAction::None);
        }
        for ctx in &popped {
            match ctx {
                StructuralContext::OrderedList(_) => {
                    self.list_depth = self.list_depth.saturating_sub(1);
                    self.ordered_list_counters.pop();
                }
                StructuralContext::UnorderedList => {
                    self.list_depth = self.list_depth.saturating_sub(1);
                }
                StructuralContext::Blockquote => {
                    self.blockquote_depth = self.blockquote_depth.saturating_sub(1);
                }
                StructuralContext::CodeBlock(_) => {
                    self.in_preformatted = false;
                }
                _ => {}
            }
        }
        if popped.len() == 1 {
            Ok(StateMachineAction::Exit(popped.into_iter().next().unwrap()))
        } else {
            Ok(StateMachineAction::ExitMany(popped))
        }
    }

    /// Pushes a `StructuralContext` onto the state's context stack while enforcing the configured maximum depth.
    ///
    /// If pushing another entry would exceed `budget.state_stack`, this returns
    /// `ConversionError::BudgetExceeded` with `stage` set to `"state_stack"` and
    /// `used`/`limit` reporting the estimated bytes consumed and allowed (each
    /// stack slot is accounted as 64 bytes).
    ///
    /// # Examples
    ///
    /// ```ignore
    /// // assuming `machine` is a `StructuralStateMachine` created elsewhere:
    /// let _ = machine.push_context(StructuralContext::Paragraph);
    /// ```
    fn push_context(&mut self, ctx: StructuralContext) -> Result<(), ConversionError> {
        let current_stack_bytes = self.stack.len().saturating_mul(64);
        self.budget.check_state_stack(current_stack_bytes, 64)?;
        self.stack.push(ctx);
        Ok(())
    }

    /// Pops all contexts from the stack top down to and including the
    /// nearest context matching `tag_name`, returning them in pop order
    /// (innermost first).
    ///
    /// For well-nested HTML the matching context is at the stack top, so
    /// only one element is returned.  For misnested HTML (e.g. a `</ol>`
    /// closing an ordered list that is not at the top), all intervening
    /// contexts are implicitly closed first.  This preserves derived-state
    /// consistency (`list_depth`, `blockquote_depth`, `in_preformatted`,
    /// `ordered_list_counters`).
    ///
    /// If no matching context exists, returns an empty `Vec`.
    fn pop_contexts_up_to(&mut self, tag_name: &str) -> Vec<StructuralContext> {
        let pos = self
            .stack
            .iter()
            .rposition(|ctx| context_matches_tag(ctx, tag_name));
        if let Some(idx) = pos {
            let mut drained: Vec<StructuralContext> = self.stack.drain(idx..).collect();
            // drain(idx..) returns outer-to-inner; callers need unwind order.
            drained.reverse();
            drained
        } else {
            Vec::new()
        }
    }

    /// Retrieve the current top structural context, if any.
    ///
    /// # Returns
    ///
    /// `Some(&StructuralContext)` with the innermost (top) context when the state stack is non-empty, `None` otherwise.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// # // Setup hidden helpers so the example focuses on `current_context`.
    /// # use nginx_markdown_converter::streaming::state_machine::{StructuralStateMachine, StructuralContext};
    /// # #[allow(dead_code)]
    /// # struct MemoryBudget { pub state_stack: usize }
    /// # impl MemoryBudget { fn new(bytes: usize) -> Self { MemoryBudget { state_stack: bytes } } }
    /// let sm = StructuralStateMachine::new(&MemoryBudget::new(1024));
    /// assert!(sm.current_context().is_none());
    /// ```
    pub fn current_context(&self) -> Option<&StructuralContext> {
        self.stack.last()
    }

    /// Get the next item number for the current ordered list and advance its counter.
    ///
    /// # Returns
    ///
    /// The current item number for the innermost ordered list; returns `1` if not inside any ordered list.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let mut sm = StructuralStateMachine::new(&MemoryBudget::default());
    /// // simulate an ordered list that starts at 3
    /// sm.ordered_list_counters.push(3);
    /// assert_eq!(sm.next_ordered_item_number(), 3);
    /// assert_eq!(sm.next_ordered_item_number(), 4);
    /// ```
    pub fn next_ordered_item_number(&mut self) -> u32 {
        if let Some(counter) = self.ordered_list_counters.last_mut() {
            let num = *counter;
            *counter = counter.saturating_add(1);
            num
        } else {
            1
        }
    }

    /// Determine whether any active structural context satisfies a predicate.
    ///
    /// The provided `check` predicate is applied to each context on the internal stack;
    /// the method returns `true` if at least one context makes the predicate evaluate to `true`.
    ///
    /// # Parameters
    ///
    /// - `check`: A predicate tested against each active `StructuralContext`.
    ///
    /// # Returns
    ///
    /// `true` if any stacked context satisfies `check`, `false` otherwise.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// // Check whether the state machine is currently inside a blockquote.
    /// let mut sm = StructuralStateMachine::new(&MemoryBudget::default());
    /// // ... events that may push Blockquote ...
    /// let inside_blockquote = sm.is_inside(&|ctx| matches!(ctx, StructuralContext::Blockquote));
    /// ```
    pub fn is_inside(&self, check: &dyn Fn(&StructuralContext) -> bool) -> bool {
        self.stack.iter().any(check)
    }

    /// Find the nearest enclosing list context (searching from stack top).
    ///
    /// Returns `Some(&StructuralContext)` for the innermost `OrderedList`
    /// or `UnorderedList`, or `None` if not inside any list.
    pub fn nearest_list_context(&self) -> Option<&StructuralContext> {
        self.stack.iter().rev().find(|ctx| {
            matches!(
                ctx,
                StructuralContext::OrderedList(_) | StructuralContext::UnorderedList
            )
        })
    }

    /// Auto-close all open structural contexts and return them.
    ///
    /// This will pop every context from the machine's stack, update internal
    /// nesting trackers (list and blockquote depths, `in_preformatted`) as each
    /// context is closed, clear any ordered-list counters, and collect the closed
    /// contexts in pop order.
    ///
    /// Returns the list of contexts that were auto-closed, in the order they were
    /// popped (innermost first).
    ///
    /// # Examples
    ///
    /// ```ignore
    /// // Given a state machine with some open contexts:
    /// // let mut sm = StructuralStateMachine::new(&memory_budget);
    /// // ... (push some contexts)
    /// let closed = sm.finalize();
    /// // `closed` contains the contexts that were closed, inner-most first.
    /// ```
    pub fn finalize(&mut self) -> Vec<StructuralContext> {
        let mut closed = Vec::new();
        while let Some(ctx) = self.stack.pop() {
            match &ctx {
                StructuralContext::OrderedList(_) | StructuralContext::UnorderedList => {
                    self.list_depth = self.list_depth.saturating_sub(1);
                }
                StructuralContext::Blockquote => {
                    self.blockquote_depth = self.blockquote_depth.saturating_sub(1);
                }
                StructuralContext::CodeBlock(_) => {
                    self.in_preformatted = false;
                }
                _ => {}
            }
            closed.push(ctx);
        }
        self.ordered_list_counters.clear();
        closed
    }

    /// Number of contexts currently on the state stack.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// // Create a machine with a sufficiently large memory budget (example only).
    /// let budget = crate::MemoryBudget { state_stack: 1024 };
    /// let sm = crate::streaming::state_machine::StructuralStateMachine::new(&budget);
    /// assert_eq!(sm.depth(), 0);
    /// ```
    pub fn depth(&self) -> usize {
        self.stack.len()
    }

    /// Estimated bytes consumed by the state stack (for working set tracking).
    pub fn stack_bytes_estimate(&self) -> usize {
        // Each StructuralContext is roughly 64 bytes.
        self.stack.len().saturating_mul(64)
    }
}

/// Determine whether a `StructuralContext` corresponds to the given HTML closing tag name.
///
/// The comparison is name-based (e.g., `Heading(1)` ↔ `"h1"`, `Paragraph` ↔ `"p"`, `OrderedList(_)` ↔ `"ol"`, etc.).
///
/// # Parameters
///
/// - `ctx`: the structural context to compare.
/// - `tag`: the lowercase HTML tag name to match against.
///
/// # Returns
///
/// `true` if the context corresponds to the provided tag name, `false` otherwise.
///
/// # Examples
///
/// ```ignore
/// let ctx = StructuralContext::Paragraph;
/// assert!(context_matches_tag(&ctx, "p"));
///
/// let h3 = StructuralContext::Heading(3);
/// assert!(context_matches_tag(&h3, "h3"));
///
/// let ol = StructuralContext::OrderedList(1);
/// assert!(context_matches_tag(&ol, "ol"));
///
/// assert!(!context_matches_tag(&h3, "h2"));
/// ```
fn context_matches_tag(ctx: &StructuralContext, tag: &str) -> bool {
    matches!(
        (ctx, tag),
        (StructuralContext::Heading(1), "h1")
            | (StructuralContext::Heading(2), "h2")
            | (StructuralContext::Heading(3), "h3")
            | (StructuralContext::Heading(4), "h4")
            | (StructuralContext::Heading(5), "h5")
            | (StructuralContext::Heading(6), "h6")
            | (StructuralContext::Paragraph, "p")
            | (StructuralContext::OrderedList(_), "ol")
            | (StructuralContext::UnorderedList, "ul")
            | (StructuralContext::ListItem, "li")
            | (StructuralContext::CodeBlock(_), "pre")
            | (StructuralContext::InlineCode, "code")
            | (StructuralContext::Blockquote, "blockquote")
            | (StructuralContext::Link(_), "a")
            | (StructuralContext::Bold, "strong" | "b")
            | (StructuralContext::Italic, "em" | "i")
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Create a `StructuralStateMachine` initialized with the default memory budget.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let sm = default_sm();
    /// assert_eq!(sm.depth(), 0);
    /// ```
    fn default_sm() -> StructuralStateMachine {
        StructuralStateMachine::new(&MemoryBudget::default())
    }

    /// Create a `StreamEvent::StartTag` with the given tag name, no attributes, and `self_closing` set to `false`.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let ev = start_tag("p");
    /// match ev {
    ///     StreamEvent::StartTag { name, attrs, self_closing } => {
    ///         assert_eq!(name, "p");
    ///         assert!(attrs.is_empty());
    ///         assert!(!self_closing);
    ///     }
    ///     _ => panic!("expected StartTag"),
    /// }
    /// ```
    fn start_tag(name: &str) -> StreamEvent {
        StreamEvent::StartTag {
            name: name.to_string(),
            attrs: vec![],
            self_closing: false,
        }
    }

    /// Create a `StreamEvent::StartTag` for `name` with the provided attributes.
    ///
    /// `attrs` is a list of `(key, value)` attribute pairs which will be converted into owned `String`s.
    /// The returned event has `self_closing` set to `false`.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let ev = start_tag_with_attrs("a", vec![("href", "https://example.com")]);
    /// if let StreamEvent::StartTag { name, attrs, self_closing } = ev {
    ///     assert_eq!(name, "a");
    ///     assert_eq!(attrs, vec![("href".to_string(), "https://example.com".to_string())]);
    ///     assert!(!self_closing);
    /// } else {
    ///     panic!("expected StartTag");
    /// }
    /// ```
    fn start_tag_with_attrs(name: &str, attrs: Vec<(&str, &str)>) -> StreamEvent {
        StreamEvent::StartTag {
            name: name.to_string(),
            attrs: attrs
                .into_iter()
                .map(|(k, v)| (k.to_string(), v.to_string()))
                .collect(),
            self_closing: false,
        }
    }

    /// Create a `StreamEvent::EndTag` for the given tag name.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let ev = end_tag("p");
    /// match ev {
    ///     StreamEvent::EndTag { name } => assert_eq!(name, "p"),
    ///     _ => panic!("unexpected event"),
    /// }
    /// ```
    fn end_tag(name: &str) -> StreamEvent {
        StreamEvent::EndTag {
            name: name.to_string(),
        }
    }

    /// Create a `StreamEvent::Text` containing the given string.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let ev = text("hello");
    /// assert_eq!(ev, StreamEvent::Text("hello".to_string()));
    /// ```
    fn text(s: &str) -> StreamEvent {
        StreamEvent::Text(s.to_string())
    }

    /// Verifies that an `h1` start tag enters a `Heading(1)` context and that the corresponding end tag exits it and requests a block separator.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let mut sm = default_sm();
    /// let action = sm.process_event(&start_tag("h1")).unwrap();
    /// assert_eq!(action, StateMachineAction::Enter(StructuralContext::Heading(1)));
    /// let action = sm.process_event(&end_tag("h1")).unwrap();
    /// assert_eq!(action, StateMachineAction::Exit(StructuralContext::Heading(1)));
    /// assert!(sm.needs_block_separator);
    /// ```
    #[test]
    fn test_heading_context() {
        let mut sm = default_sm();
        let action = sm.process_event(&start_tag("h1")).unwrap();
        assert_eq!(
            action,
            StateMachineAction::Enter(StructuralContext::Heading(1))
        );
        let action = sm.process_event(&end_tag("h1")).unwrap();
        assert_eq!(
            action,
            StateMachineAction::Exit(StructuralContext::Heading(1))
        );
        // needs_block_separator is deprecated/dead on the state machine;
        // the emitter manages its own copy independently.
    }

    #[test]
    fn test_nested_list_depth() {
        let mut sm = default_sm();
        sm.process_event(&start_tag("ul")).unwrap();
        assert_eq!(sm.list_depth, 1);
        sm.process_event(&start_tag("li")).unwrap();
        sm.process_event(&start_tag("ul")).unwrap();
        assert_eq!(sm.list_depth, 2);
        sm.process_event(&end_tag("ul")).unwrap();
        assert_eq!(sm.list_depth, 1);
        sm.process_event(&end_tag("li")).unwrap();
        sm.process_event(&end_tag("ul")).unwrap();
        assert_eq!(sm.list_depth, 0);
    }

    #[test]
    fn test_unmatched_list_end_tag_does_not_mutate_state() {
        let mut sm = default_sm();

        sm.process_event(&start_tag("ol")).unwrap();
        assert_eq!(sm.list_depth, 1);
        assert_eq!(sm.next_ordered_item_number(), 1);

        let action = sm.process_event(&end_tag("ul")).unwrap();
        assert_eq!(action, StateMachineAction::None);
        assert_eq!(sm.list_depth, 1);
        assert_eq!(sm.next_ordered_item_number(), 2);
    }

    #[test]
    fn test_blockquote_depth() {
        let mut sm = default_sm();
        sm.process_event(&start_tag("blockquote")).unwrap();
        assert_eq!(sm.blockquote_depth, 1);
        sm.process_event(&start_tag("blockquote")).unwrap();
        assert_eq!(sm.blockquote_depth, 2);
        sm.process_event(&end_tag("blockquote")).unwrap();
        assert_eq!(sm.blockquote_depth, 1);
    }

    /// Verifies that a `pre` element containing a `code` element with a `language-*` class
    /// records the language on the `CodeBlock` context and marks the state machine as preformatted.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let mut sm = default_sm();
    /// sm.process_event(&start_tag("pre")).unwrap();
    /// sm.process_event(&start_tag_with_attrs(
    ///     "code",
    ///     vec![("class", "language-rust")],
    /// )).unwrap();
    /// assert!(sm.in_preformatted);
    /// assert_eq!(
    ///     sm.current_context(),
    ///     Some(&StructuralContext::CodeBlock(Some("rust".to_string())))
    /// );
    /// ```
    #[test]
    fn test_code_block_with_language() {
        let mut sm = default_sm();
        sm.process_event(&start_tag("pre")).unwrap();
        sm.process_event(&start_tag_with_attrs(
            "code",
            vec![("class", "language-rust")],
        ))
        .unwrap();
        assert!(sm.in_preformatted);
        // The CodeBlock context should now have the language
        assert_eq!(
            sm.current_context(),
            Some(&StructuralContext::CodeBlock(Some("rust".to_string())))
        );
    }

    #[test]
    fn test_code_block_rejects_fence_corrupting_language() {
        for language in ["language-rust```", "language-rust\0malicious"] {
            let mut sm = default_sm();
            sm.process_event(&start_tag("pre")).unwrap();
            sm.process_event(&start_tag_with_attrs("code", vec![("class", language)]))
                .unwrap();

            assert_eq!(
                sm.current_context(),
                Some(&StructuralContext::CodeBlock(None))
            );
        }
    }

    #[test]
    fn test_code_block_accepts_safe_punctuation_in_language() {
        let mut sm = default_sm();
        sm.process_event(&start_tag("pre")).unwrap();
        sm.process_event(&start_tag_with_attrs(
            "code",
            vec![("class", "language-c++")],
        ))
        .unwrap();

        assert_eq!(
            sm.current_context(),
            Some(&StructuralContext::CodeBlock(Some("c++".to_string())))
        );
    }

    #[test]
    fn test_code_block_skips_unsafe_language_before_safe_language() {
        let mut sm = default_sm();
        sm.process_event(&start_tag("pre")).unwrap();
        sm.process_event(&start_tag_with_attrs(
            "code",
            vec![("class", "language-bad``` language-rust")],
        ))
        .unwrap();

        assert_eq!(
            sm.current_context(),
            Some(&StructuralContext::CodeBlock(Some("rust".to_string())))
        );
    }

    #[test]
    fn test_table_triggers_fallback() {
        let mut sm = default_sm();
        let action = sm.process_event(&start_tag("table")).unwrap();
        assert_eq!(
            action,
            StateMachineAction::FallbackRequired("table".to_string())
        );
    }

    #[test]
    fn test_svg_triggers_fallback() {
        let mut sm = default_sm();
        let action = sm.process_event(&start_tag("svg")).unwrap();
        assert_eq!(
            action,
            StateMachineAction::FallbackRequired("svg".to_string())
        );
    }

    #[test]
    fn test_math_triggers_fallback() {
        let mut sm = default_sm();
        let action = sm.process_event(&start_tag("math")).unwrap();
        assert_eq!(
            action,
            StateMachineAction::FallbackRequired("math".to_string())
        );
    }

    #[test]
    fn test_form_triggers_fallback() {
        // Form elements are stripped by the sanitizer before reaching
        // the state machine in the production pipeline. This test verifies
        // the state machine treats unknown tags as pass-through.
        let mut sm = default_sm();
        let action = sm.process_event(&start_tag("form")).unwrap();
        assert_eq!(action, StateMachineAction::None);
    }

    #[test]
    fn test_iframe_triggers_fallback() {
        // Iframe elements are stripped by the sanitizer before reaching
        // the state machine in the production pipeline. This test verifies
        // the state machine treats unknown tags as pass-through.
        let mut sm = default_sm();
        let action = sm.process_event(&start_tag("iframe")).unwrap();
        assert_eq!(action, StateMachineAction::None);
    }

    #[test]
    fn test_canvas_triggers_fallback() {
        // Canvas elements are caught by the pre-sanitization fallback check
        // in the converter. The state machine also handles them as a
        // defense-in-depth measure.
        let mut sm = default_sm();
        let action = sm.process_event(&start_tag("canvas")).unwrap();
        assert_eq!(
            action,
            StateMachineAction::FallbackRequired("canvas".to_string())
        );
    }

    #[test]
    fn test_video_and_audio_with_src_emit_image_context() {
        let mut sm = default_sm();

        let video = sm
            .process_event(&start_tag_with_attrs(
                "video",
                vec![("src", "https://example.com/video.mp4")],
            ))
            .unwrap();
        assert_eq!(
            video,
            StateMachineAction::Enter(StructuralContext::Image {
                src: "https://example.com/video.mp4".to_string(),
                alt: "video".to_string(),
            })
        );

        let audio = sm
            .process_event(&start_tag_with_attrs(
                "audio",
                vec![("src", "https://example.com/audio.mp3")],
            ))
            .unwrap();
        assert_eq!(
            audio,
            StateMachineAction::Enter(StructuralContext::Image {
                src: "https://example.com/audio.mp3".to_string(),
                alt: "audio".to_string(),
            })
        );
    }

    #[test]
    fn test_media_void_tags_extract_src_or_href() {
        let mut sm = default_sm();

        let source = sm
            .process_event(&start_tag_with_attrs(
                "source",
                vec![("src", "https://example.com/v.webm")],
            ))
            .unwrap();
        assert_eq!(
            source,
            StateMachineAction::Enter(StructuralContext::Image {
                src: "https://example.com/v.webm".to_string(),
                alt: "source".to_string(),
            })
        );

        let area = sm
            .process_event(&start_tag_with_attrs(
                "area",
                vec![("href", "https://example.com/map")],
            ))
            .unwrap();
        assert_eq!(
            area,
            StateMachineAction::Enter(StructuralContext::Image {
                src: "https://example.com/map".to_string(),
                alt: "area".to_string(),
            })
        );
    }

    #[test]
    fn test_video_without_inline_src_is_noop() {
        let mut sm = default_sm();
        let action = sm
            .process_event(&start_tag_with_attrs("video", vec![("controls", "true")]))
            .unwrap();
        assert_eq!(action, StateMachineAction::None);
    }

    #[test]
    fn test_stack_depth_exceeded() {
        let budget = MemoryBudget {
            // 16 * 64 = 1024 bytes → max depth 16.
            state_stack: 1024,
            ..MemoryBudget::default()
        };
        let mut sm = StructuralStateMachine::new(&budget);
        // Fill the stack to the limit with alternating bold/italic
        for _ in 0..8 {
            sm.process_event(&start_tag("strong")).unwrap();
            sm.process_event(&start_tag("em")).unwrap();
        }
        assert_eq!(sm.depth(), 16);
        // Next push should exceed the limit
        let err = sm.process_event(&start_tag("p")).unwrap_err();
        assert_eq!(err.code(), 6); // BudgetExceeded
    }

    #[test]
    fn test_state_stack_budget_respected_without_flooring() {
        let budget = MemoryBudget {
            state_stack: 64,
            ..MemoryBudget::default()
        };
        let mut sm = StructuralStateMachine::new(&budget);

        sm.process_event(&start_tag("strong")).unwrap();
        let err = sm.process_event(&start_tag("em")).unwrap_err();
        assert_eq!(err.code(), 6);
    }

    #[test]
    fn test_finalize_closes_unclosed() {
        let mut sm = default_sm();
        sm.process_event(&start_tag("p")).unwrap();
        sm.process_event(&start_tag("strong")).unwrap();
        let closed = sm.finalize();
        assert_eq!(closed.len(), 2);
        assert_eq!(sm.depth(), 0);
    }

    #[test]
    fn test_text_passthrough() {
        let mut sm = default_sm();
        let action = sm.process_event(&text("hello")).unwrap();
        assert_eq!(action, StateMachineAction::Text("hello".to_string()));
    }

    #[test]
    fn test_head_tracking() {
        let mut sm = default_sm();
        sm.process_event(&start_tag("head")).unwrap();
        assert!(sm.in_head);
        sm.process_event(&end_tag("head")).unwrap();
        assert!(!sm.in_head);
    }

    #[test]
    fn test_ordered_list_counter() {
        let mut sm = default_sm();
        sm.process_event(&start_tag("ol")).unwrap();
        assert_eq!(sm.next_ordered_item_number(), 1);
        assert_eq!(sm.next_ordered_item_number(), 2);
        assert_eq!(sm.next_ordered_item_number(), 3);
    }

    /// Verifies that an `ol` element with a `start` attribute initializes the ordered-list counter.
    ///
    /// # Examples
    ///
    /// ```ignore
    /// let mut sm = default_sm();
    /// sm.process_event(&start_tag_with_attrs("ol", vec![("start", "5")])).unwrap();
    /// assert_eq!(sm.next_ordered_item_number(), 5);
    /// assert_eq!(sm.next_ordered_item_number(), 6);
    /// ```
    #[test]
    fn test_ordered_list_custom_start() {
        let mut sm = default_sm();
        sm.process_event(&start_tag_with_attrs("ol", vec![("start", "5")]))
            .unwrap();
        assert_eq!(sm.next_ordered_item_number(), 5);
        assert_eq!(sm.next_ordered_item_number(), 6);
    }

    /// Regression: closing a tag that is not at the stack top must
    /// implicitly close all intervening contexts and emit ExitMany.
    #[test]
    fn test_misnested_ol_not_at_top() {
        let mut sm = default_sm();
        // <ol><li><p>text</p></li></ol> — p and li are above ol
        sm.process_event(&start_tag("ol")).unwrap();
        sm.process_event(&start_tag("li")).unwrap();
        sm.process_event(&start_tag("p")).unwrap();
        sm.process_event(&text("text")).unwrap();

        // Close </p> — matches top, single exit
        let action = sm.process_event(&end_tag("p")).unwrap();
        assert!(matches!(
            action,
            StateMachineAction::Exit(StructuralContext::Paragraph)
        ));
        assert_eq!(sm.depth(), 2); // ol, li still open

        // Close </li> — matches top, single exit
        let action = sm.process_event(&end_tag("li")).unwrap();
        assert!(matches!(
            action,
            StateMachineAction::Exit(StructuralContext::ListItem)
        ));
        assert_eq!(sm.depth(), 1); // ol still open

        // Close </ol> — matches the only remaining context
        let action = sm.process_event(&end_tag("ol")).unwrap();
        assert!(matches!(
            action,
            StateMachineAction::Exit(StructuralContext::OrderedList(_))
        ));
        assert_eq!(sm.depth(), 0);
        assert_eq!(sm.list_depth, 0);
    }

    /// Regression: misnested HTML where `</ol>` closes an ordered list
    /// that has other elements above it on the stack.  The state machine
    /// must emit ExitMany and correctly update list_depth and counter state.
    #[test]
    fn test_misnested_ol_with_intervening_elements() {
        let mut sm = default_sm();
        // Misnested: <ol><li><strong>bold</ol>
        // </ol> must close strong, li, and ol (3 contexts)
        sm.process_event(&start_tag("ol")).unwrap();
        sm.process_event(&start_tag("li")).unwrap();
        sm.process_event(&start_tag("strong")).unwrap();
        sm.process_event(&text("bold")).unwrap();
        let action = sm.process_event(&end_tag("ol")).unwrap();
        match action {
            StateMachineAction::ExitMany(contexts) => {
                assert_eq!(contexts.len(), 3);
                assert!(matches!(contexts[0], StructuralContext::Bold));
                assert!(matches!(contexts[1], StructuralContext::ListItem));
                assert!(matches!(contexts[2], StructuralContext::OrderedList(_)));
            }
            _ => panic!("expected ExitMany, got {:?}", action),
        }
        assert_eq!(sm.depth(), 0);
        assert_eq!(sm.list_depth, 0);
        assert!(sm.ordered_list_counters.is_empty());
    }

    /// Regression: misnested HTML where `</blockquote>` closes an unordered
    /// list that has a blockquote above it.  list_depth and blockquote_depth
    /// must both be decremented correctly.
    #[test]
    fn test_misnested_ul_with_blockquote() {
        let mut sm = default_sm();
        // Misnested: <blockquote><ul><li>item</blockquote>
        // </blockquote> closes li, ul, blockquote (3 contexts)
        sm.process_event(&start_tag("blockquote")).unwrap();
        sm.process_event(&start_tag("ul")).unwrap();
        sm.process_event(&start_tag("li")).unwrap();
        sm.process_event(&text("item")).unwrap();
        let action = sm.process_event(&end_tag("blockquote")).unwrap();
        match action {
            StateMachineAction::ExitMany(contexts) => {
                assert_eq!(contexts.len(), 3);
                assert!(matches!(contexts[0], StructuralContext::ListItem));
                assert!(matches!(contexts[1], StructuralContext::UnorderedList));
                assert!(matches!(contexts[2], StructuralContext::Blockquote));
            }
            _ => panic!("expected ExitMany, got {:?}", action),
        }
        assert_eq!(sm.depth(), 0);
        assert_eq!(sm.list_depth, 0);
        assert_eq!(sm.blockquote_depth, 0);
    }

    /// Regression: misnested HTML where `</ul>` closes an unordered list
    /// that has a preformatted code block above it.  Note: `<code>` inside
    /// `<pre>` does NOT push a separate context, so the stack has 2 items
    /// (ul + CodeBlock), not 3.
    #[test]
    fn test_misnested_ul_with_preformatted() {
        let mut sm = default_sm();
        // Misnested: <ul><pre><code>text</ul>
        // code inside pre does NOT push a separate context
        sm.process_event(&start_tag("ul")).unwrap();
        sm.process_event(&start_tag("pre")).unwrap();
        sm.process_event(&start_tag("code")).unwrap();
        sm.process_event(&text("text")).unwrap();
        // </ul> closes CodeBlock (pre), ul (2 contexts)
        let action = sm.process_event(&end_tag("ul")).unwrap();
        match action {
            StateMachineAction::ExitMany(contexts) => {
                assert_eq!(contexts.len(), 2);
                assert!(matches!(contexts[0], StructuralContext::CodeBlock(_)));
                assert!(matches!(contexts[1], StructuralContext::UnorderedList));
            }
            _ => panic!("expected ExitMany, got {:?}", action),
        }
        assert_eq!(sm.depth(), 0);
        assert_eq!(sm.list_depth, 0);
        assert!(!sm.in_preformatted);
    }

    /// Well-nested HTML must still produce a single Exit, not ExitMany.
    #[test]
    fn test_well_nested_still_single_exit() {
        let mut sm = default_sm();
        sm.process_event(&start_tag("ol")).unwrap();
        sm.process_event(&start_tag("li")).unwrap();
        sm.process_event(&text("item")).unwrap();

        // </li> matches top
        let action = sm.process_event(&end_tag("li")).unwrap();
        assert!(matches!(
            action,
            StateMachineAction::Exit(StructuralContext::ListItem)
        ));

        // </ol> matches top
        let action = sm.process_event(&end_tag("ol")).unwrap();
        assert!(matches!(
            action,
            StateMachineAction::Exit(StructuralContext::OrderedList(_))
        ));
    }

    // --- Misnested ordered-list counter regression tests (P1) ---

    /// `</blockquote>` closing over `<ol><li>` must drain the OrderedList
    /// and pop its counter so `ordered_list_counters` is empty afterwards.
    #[test]
    fn test_misnested_ordered_list_drained_by_blockquote_clears_counter() {
        let mut sm = default_sm();
        // Build: <blockquote><ol><li>x</blockquote>
        sm.process_event(&start_tag("blockquote")).unwrap();
        sm.process_event(&start_tag("ol")).unwrap();
        sm.process_event(&start_tag("li")).unwrap();
        sm.process_event(&text("x")).unwrap();

        assert_eq!(sm.ordered_list_counters.len(), 1);
        assert_eq!(sm.list_depth, 1);
        assert_eq!(sm.blockquote_depth, 1);

        // </blockquote> drains li, ol, blockquote (3 contexts)
        let action = sm.process_event(&end_tag("blockquote")).unwrap();
        match action {
            StateMachineAction::ExitMany(contexts) => {
                assert_eq!(contexts.len(), 3);
                assert!(matches!(contexts[0], StructuralContext::ListItem));
                assert!(matches!(contexts[1], StructuralContext::OrderedList(_)));
                assert!(matches!(contexts[2], StructuralContext::Blockquote));
            }
            _ => panic!(
                "expected ExitMany for misnested blockquote, got {:?}",
                action
            ),
        }
        assert_eq!(sm.depth(), 0);
        assert_eq!(sm.list_depth, 0);
        assert_eq!(sm.blockquote_depth, 0);
        assert!(
            sm.ordered_list_counters.is_empty(),
            "ordered_list_counters must be empty after blockquote drains ol"
        );
    }

    /// `</ul>` closing over `<ol><li>` must drain the OrderedList
    /// and pop its counter so `ordered_list_counters` is empty afterwards.
    #[test]
    fn test_misnested_ordered_list_drained_by_ul_clears_counter() {
        let mut sm = default_sm();
        // Build: <ul><ol><li>x</ul>
        sm.process_event(&start_tag("ul")).unwrap();
        sm.process_event(&start_tag("ol")).unwrap();
        sm.process_event(&start_tag("li")).unwrap();
        sm.process_event(&text("x")).unwrap();

        assert_eq!(sm.ordered_list_counters.len(), 1);
        assert_eq!(sm.list_depth, 2);

        // </ul> drains li, ol, ul (3 contexts)
        let action = sm.process_event(&end_tag("ul")).unwrap();
        match action {
            StateMachineAction::ExitMany(contexts) => {
                assert_eq!(contexts.len(), 3);
                assert!(matches!(contexts[0], StructuralContext::ListItem));
                assert!(matches!(contexts[1], StructuralContext::OrderedList(_)));
                assert!(matches!(contexts[2], StructuralContext::UnorderedList));
            }
            _ => panic!("expected ExitMany for misnested ul, got {:?}", action),
        }
        assert_eq!(sm.depth(), 0);
        assert_eq!(sm.list_depth, 0);
        assert!(
            sm.ordered_list_counters.is_empty(),
            "ordered_list_counters must be empty after ul drains ol"
        );
    }
}
