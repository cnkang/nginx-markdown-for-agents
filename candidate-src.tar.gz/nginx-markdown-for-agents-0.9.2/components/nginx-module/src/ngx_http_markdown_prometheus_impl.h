#ifndef NGX_HTTP_MARKDOWN_PROMETHEUS_IMPL_H
#define NGX_HTTP_MARKDOWN_PROMETHEUS_IMPL_H

/*
 * Prometheus text exposition format renderer.
 *
 * WARNING: This header is an implementation detail of the main
 * translation unit (ngx_http_markdown_filter_module.c).  It must
 * NOT be included from any other .c file or used as a standalone
 * compilation unit.
 *
 * Renders a metrics snapshot as Prometheus text exposition format
 * (content type: text/plain; version=0.0.4; charset=utf-8).
 * Aggregate-series label values are compile-time constants.
 * Per-path series include a runtime "path" label; the path value
 * is escaped for Prometheus label syntax (backslash, double-quote,
 * newlines, control characters).
 */

/* C99 declaration visibility for standalone static analysis of this impl header. */
u_char *ngx_slprintf(u_char *buf, u_char *last,
    const char *fmt, ...);

/*
 * Per-path RB-tree walk removed from production builds in 0.9.2
 * (unbounded cardinality risk). Retained under debug guard only.
 * Unit test stubs define this to 0 before including this header.
 */
#ifndef NGX_HTTP_MARKDOWN_PER_PATH_WALK_ENABLED
#ifdef MARKDOWN_METRICS_PER_PATH_DEBUG
#define NGX_HTTP_MARKDOWN_PER_PATH_WALK_ENABLED  1
#else
#define NGX_HTTP_MARKDOWN_PER_PATH_WALK_ENABLED  0
#endif
#endif

#if NGX_HTTP_MARKDOWN_PER_PATH_WALK_ENABLED
#define NGX_HTTP_MARKDOWN_PROM_PATH_HEADER                              \
    "# HELP nginx_markdown_path_conversions_total "                    \
    "Per-path conversion count.\n"                                     \
    "# TYPE nginx_markdown_path_conversions_total counter\n"           \
    "# HELP nginx_markdown_path_conversion_time_ms_total "             \
    "Per-path cumulative conversion time in ms.\n"                     \
    "# TYPE nginx_markdown_path_conversion_time_ms_total counter\n"

#define NGX_HTTP_MARKDOWN_PROM_PATH_CONVERSIONS_PREFIX                  \
    "nginx_markdown_path_conversions_total{path=\""

#define NGX_HTTP_MARKDOWN_PROM_PATH_TIME_PREFIX                         \
    "nginx_markdown_path_conversion_time_ms_total{path=\""

#define NGX_HTTP_MARKDOWN_PROM_PATH_VALUE_PREFIX  "\"} "

typedef struct {
    u_char             *pos;
    u_char             *end;
    size_t              tail_reserve;
    ngx_atomic_uint_t   omitted_conversions;
    ngx_atomic_uint_t   omitted_time_ms;
    ngx_uint_t          omitted_nodes;
    ngx_uint_t          failed;
} ngx_http_markdown_prometheus_path_render_ctx_t;
#endif

/*
 * Forward declaration: in-order RB-tree walk helper for per-path
 * Prometheus output.  Defined after the main write function.
 * Only available when NGX_HTTP_MARKDOWN_PER_PATH_WALK_ENABLED is 1.
 */
#if NGX_HTTP_MARKDOWN_PER_PATH_WALK_ENABLED
static ngx_int_t
ngx_http_markdown_prometheus_path_tail_reserve(size_t *reserve);

static ngx_atomic_uint_t
ngx_http_markdown_prometheus_saturating_add(
    ngx_atomic_uint_t left,
    ngx_atomic_uint_t right);

static ngx_int_t
ngx_http_markdown_prometheus_path_pair_size(
    const u_char *path,
    size_t path_len,
    ngx_atomic_uint_t conversions,
    ngx_atomic_uint_t conversion_time_ms,
    size_t *needed);

static ngx_int_t
ngx_http_markdown_prometheus_write_path_pair(
    ngx_http_markdown_prometheus_path_render_ctx_t *render,
    const u_char *path,
    size_t path_len,
    ngx_atomic_uint_t conversions,
    ngx_atomic_uint_t conversion_time_ms,
    size_t needed);

static u_char *
ngx_http_markdown_prometheus_write_other_path(
    u_char *p,
    const u_char *end,
    ngx_http_markdown_prometheus_path_render_ctx_t *render,
    ngx_atomic_uint_t unretained_conversions,
    ngx_atomic_uint_t unretained_time_ms);

static u_char *
ngx_http_markdown_metrics_write_prometheus_paths(
    u_char *p,
    u_char *end,
    const ngx_http_markdown_metrics_snapshot_t *snapshot);

static void
ngx_http_markdown_prometheus_walk_path_tree(
    ngx_rbtree_node_t *node,
    ngx_rbtree_node_t *sentinel,
    ngx_http_markdown_prometheus_path_render_ctx_t *render);
#endif


static u_char *
ngx_http_markdown_metrics_write_prometheus_perf(
    u_char *p,
    u_char *end,
    const ngx_http_markdown_metrics_perf_snapshot_t *perf)
{
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_inflight_current "
        "Number of markdown conversions currently in-flight "
        "in this worker.\n"
        "# TYPE nginx_markdown_inflight_current gauge\n"
        "nginx_markdown_inflight_current %uA\n\n",
        perf->inflight.current);
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_inflight_high_watermark "
        "Peak number of concurrent in-flight conversions "
        "observed in this worker.\n"
        "# TYPE nginx_markdown_inflight_high_watermark gauge\n"
        "nginx_markdown_inflight_high_watermark %uA\n\n",
        perf->inflight.high_watermark);
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_overload_total "
        "Total requests rejected because the per-worker "
        "inflight limit was reached.\n"
        "# TYPE nginx_markdown_overload_total counter\n"
        "nginx_markdown_overload_total %uA\n\n",
        perf->inflight.overload_total);
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_backpressure_total "
        "Body-filter output returned NGX_AGAIN (backpressure events).\n"
        "# TYPE nginx_markdown_backpressure_total counter\n"
        "nginx_markdown_backpressure_total %uA\n\n",
        perf->backpressure_total);
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_backpressure_resume_total "
        "Pending drain completed with NGX_OK (backpressure resumes).\n"
        "# TYPE nginx_markdown_backpressure_resume_total counter\n"
        "nginx_markdown_backpressure_resume_total %uA\n\n",
        perf->backpressure_resume_total);
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_pending_output_high_watermark_bytes "
        "Peak pending output bytes observed (CAS gauge).\n"
        "# TYPE nginx_markdown_pending_output_high_watermark_bytes gauge\n"
        "nginx_markdown_pending_output_high_watermark_bytes %uA\n\n",
        perf->pending_output_high_watermark_bytes);
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_decompression_streaming_total "
        "Decompression operations routed to streaming path.\n"
        "# TYPE nginx_markdown_decompression_streaming_total counter\n"
        "nginx_markdown_decompression_streaming_total %uA\n\n",
        perf->decompression_streaming_total);
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_decompression_fullbuffer_total "
        "Decompression operations routed to full-buffer path.\n"
        "# TYPE nginx_markdown_decompression_fullbuffer_total counter\n"
        "nginx_markdown_decompression_fullbuffer_total %uA\n\n",
        perf->decompression_fullbuffer_total);
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_perf_decompression_budget_exceeded_total "
        "Decompression budget exceeded triggering fail-open "
        "(perf counter).\n"
        "# TYPE nginx_markdown_perf_decompression_budget_exceeded_total "
        "counter\n"
        "nginx_markdown_perf_decompression_budget_exceeded_total %uA\n\n",
        perf->decompression_budget_exceeded_total);
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_zero_copy_output_total "
        "Output chains delivered via zero-copy on NGX_OK.\n"
        "# TYPE nginx_markdown_zero_copy_output_total counter\n"
        "nginx_markdown_zero_copy_output_total %uA\n\n",
        perf->zero_copy_output_total);
    return ngx_slprintf(p, end,
        "# HELP nginx_markdown_copied_output_total "
        "Output chains delivered via buffer copy on NGX_OK.\n"
        "# TYPE nginx_markdown_copied_output_total counter\n"
        "nginx_markdown_copied_output_total %uA\n\n",
        perf->copied_output_total);
}


/*
 * Render the core (non-streaming) metrics families as Prometheus text.
 *
 * Writes HELP, TYPE, and metric lines for all module counters
 * into the buffer between p and end.  Returns a pointer past
 * the last byte written.
 *
 * Parameters:
 *   p        - Start of writable buffer region
 *   end      - One past the end of the buffer
 *   snapshot - Collected metrics snapshot
 *
 * Returns:
 *   Pointer past the last byte written
 */
static u_char *
ngx_http_markdown_metrics_write_prometheus_base(
    u_char *p,
    u_char *end,
    const ngx_http_markdown_metrics_snapshot_t *snapshot)
{
    ngx_atomic_uint_t  not_eligible;

    not_eligible = snapshot->skips.method
        + snapshot->skips.status
        + snapshot->skips.content_type
        + snapshot->skips.size
        + snapshot->skips.streaming
        + snapshot->skips.auth
        + snapshot->skips.range
        + snapshot->skips.compression_passthrough;

    /* requests_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_requests_total "
        "Total requests entering the module decision chain.\n"
        "# TYPE nginx_markdown_requests_total counter\n"
        "nginx_markdown_requests_total %uA\n"
        "\n",
        snapshot->requests_entered);

    /* conversions_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_conversions_total "
        "Successful HTML-to-Markdown conversions.\n"
        "# TYPE nginx_markdown_conversions_total counter\n"
        "nginx_markdown_conversions_total %uA\n"
        "\n",
        snapshot->conversions_succeeded);

    /* passthrough_total (derived: skips + fail-open) */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_passthrough_total "
        "Requests not converted "
        "(skipped or failed-open).\n"
        "# TYPE nginx_markdown_passthrough_total "
        "counter\n"
        "nginx_markdown_passthrough_total %uA\n"
        "\n",
        snapshot->conversions_bypassed
            + snapshot->results.failopen_count);

    /* skips_total{reason=...} — lowercase snake_case per schema v1 */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_skips_total "
        "Requests skipped by reason.\n"
        "# TYPE nginx_markdown_skips_total counter\n"
        "nginx_markdown_skips_total"
        "{reason=\"not_eligible\"} %uA\n"
        "nginx_markdown_skips_total"
        "{reason=\"skipped_accept\"} %uA\n"
        "nginx_markdown_skips_total"
        "{reason=\"skipped_no_accept\"} %uA\n"
        "nginx_markdown_skips_total"
        "{reason=\"skipped_conditional\"} %uA\n"
        "nginx_markdown_skips_total"
        "{reason=\"disabled\"} %uA\n"
        "\n",
        not_eligible,
        snapshot->skips.accept,
        snapshot->skips.no_accept,
        snapshot->skips.conditional,
        snapshot->skips.config);

    /* failures_total{reason=...} — bounded failure categories. */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_failures_total "
        "Conversion failures by reason.\n"
        "# TYPE nginx_markdown_failures_total counter\n"
        "nginx_markdown_failures_total"
        "{reason=\"conversion_error\"} %uA\n"
        "nginx_markdown_failures_total"
        "{reason=\"resource_limit\"} %uA\n"
        "nginx_markdown_failures_total"
        "{reason=\"system_error\"} %uA\n"
        "\n",
        snapshot->failures_conversion,
        snapshot->failures_resource_limit,
        snapshot->failures_system);

    /* failopen_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_failopen_total "
        "Conversions failed with original HTML served "
        "(fail-open).\n"
        "# TYPE nginx_markdown_failopen_total counter\n"
        "nginx_markdown_failopen_total %uA\n"
        "\n",
        snapshot->results.failopen_count);

    /* large_response_path_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_large_response_path_total "
        "Requests routed to incremental processing path.\n"
        "# TYPE nginx_markdown_large_response_path_total "
        "counter\n"
        "nginx_markdown_large_response_path_total %uA\n"
        "\n",
        snapshot->path_hits.incremental);

    return p;
}

#ifdef MARKDOWN_STREAMING_ENABLED
static u_char *
ngx_http_markdown_metrics_write_prometheus_streaming(
    u_char *p,
    u_char *end,
    const ngx_http_markdown_metrics_snapshot_t *snapshot)
{
    /* streaming_path_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_streaming_path_total "
        "Requests routed to streaming path.\n"
        "# TYPE nginx_markdown_streaming_path_total "
        "counter\n"
        "nginx_markdown_streaming_path_total %uA\n"
        "\n",
        snapshot->path_hits.streaming);

    /* streaming_total{result=...} (mutually exclusive outcomes) */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_streaming_total "
        "Streaming conversion outcomes.\n"
        "# TYPE nginx_markdown_streaming_total counter\n"
        "nginx_markdown_streaming_total"
        "{result=\"success\"} %uA\n"
        "nginx_markdown_streaming_total"
        "{result=\"failed\"} %uA\n"
        "nginx_markdown_streaming_total"
        "{result=\"fallback\"} %uA\n"
        "\n",
        snapshot->streaming.succeeded_total,
        snapshot->streaming.failed_total,
        snapshot->streaming.fallback_total);

    return p;
}

static u_char *
ngx_http_markdown_metrics_write_prometheus_streaming_failures(
    u_char *p,
    u_char *end,
    const ngx_http_markdown_metrics_snapshot_t *snapshot)
{

    /* streaming_failures_total{stage=...} */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_streaming_failures_total "
        "Detailed streaming failures by stage.\n"
        "# TYPE nginx_markdown_streaming_failures_total counter\n"
        "nginx_markdown_streaming_failures_total"
        "{stage=\"precommit_failopen\"} %uA\n"
        "nginx_markdown_streaming_failures_total"
        "{stage=\"precommit_reject\"} %uA\n"
        "nginx_markdown_streaming_failures_total"
        "{stage=\"postcommit_error\"} %uA\n"
        "\n",
        snapshot->streaming.precommit_failopen_total,
        snapshot->streaming.precommit_reject_total,
        snapshot->streaming.postcommit_error_total);

    /* streaming_budget_exceeded_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_streaming_budget_exceeded_total "
        "Streaming memory budget exceeded count.\n"
        "# TYPE "
        "nginx_markdown_streaming_budget_exceeded_total "
        "counter\n"
        "nginx_markdown_streaming_budget_exceeded_total"
        " %uA\n"
        "\n",
        snapshot->streaming.budget_exceeded_total);

    /* streaming_shadow metrics removed in 0.9.2 (production builds) */
#ifdef MARKDOWN_STREAMING_SHADOW_DEBUG
    /* streaming_shadow_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_streaming_shadow_total "
        "Shadow mode comparison runs.\n"
        "# TYPE "
        "nginx_markdown_streaming_shadow_total counter\n"
        "nginx_markdown_streaming_shadow_total %uA\n"
        "\n",
        snapshot->streaming.shadow_total);

    /* streaming_shadow_diff_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_streaming_shadow_diff_total "
        "Shadow mode output differences detected.\n"
        "# TYPE "
        "nginx_markdown_streaming_shadow_diff_total "
        "counter\n"
        "nginx_markdown_streaming_shadow_diff_total"
        " %uA\n"
        "\n",
        snapshot->streaming.shadow_diff_total);
#endif /* MARKDOWN_STREAMING_SHADOW_DEBUG */

    /* streaming_ttfb_seconds (gauge) */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_streaming_ttfb_seconds "
        "Last streaming request time-to-first-byte "
        "in seconds (millisecond resolution).\n"
        "# TYPE "
        "nginx_markdown_streaming_ttfb_seconds gauge\n"
        "nginx_markdown_streaming_ttfb_seconds "
        "%uA.%03uA\n"
        "\n",
        snapshot->streaming.last_ttfb_ms / 1000,
        snapshot->streaming.last_ttfb_ms % 1000);

    /* streaming_peak_memory_bytes (gauge) */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_streaming_peak_memory_bytes "
        "Last streaming conversion peak working-set estimate; "
        "not process RSS.\n"
        "# TYPE "
        "nginx_markdown_streaming_peak_memory_bytes gauge\n"
        "nginx_markdown_streaming_peak_memory_bytes "
        "%uA\n"
        "\n",
        snapshot->streaming.last_peak_memory_bytes);

    /* streaming_engine_choice_total{engine=...} */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_streaming_engine_choice_total "
        "Engine choice decisions for "
        "streaming-eligible requests.\n"
        "# TYPE "
        "nginx_markdown_streaming_engine_choice_total "
        "counter\n"
        "nginx_markdown_streaming_engine_choice_total"
        "{engine=\"streaming\"} %uA\n"
        "nginx_markdown_streaming_engine_choice_total"
        "{engine=\"full_buffer\"} %uA\n"
        "nginx_markdown_streaming_engine_choice_total"
        "{engine=\"passthrough\"} %uA\n"
        "nginx_markdown_streaming_engine_choice_total"
        "{engine=\"not_eligible\"} %uA\n"
        "\n",
        snapshot->streaming.engine_choice.streaming,
        snapshot->streaming.engine_choice.full_buffer,
        snapshot->streaming.engine_choice.passthrough,
        snapshot->streaming.engine_choice.not_eligible);

    /* Streaming fallback events by phase and action */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_streaming_fallback_total "
        "Pre-commit fallback events.\n"
        "# TYPE "
        "nginx_markdown_streaming_fallback_total "
        "counter\n"
        "nginx_markdown_streaming_fallback_total"
        "{phase=\"precommit\",action=\"pass\"} %uA\n"
        "nginx_markdown_streaming_fallback_total"
        "{phase=\"precommit\",action=\"reject\"} %uA\n"
        "\n",
        snapshot->streaming.streaming_fallback_precommit_pass,
        snapshot->streaming.streaming_fallback_precommit_reject);

    /* Streaming failure events by phase and action */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_streaming_failure_total "
        "Post-commit failure events.\n"
        "# TYPE "
        "nginx_markdown_streaming_failure_total "
        "counter\n"
        "nginx_markdown_streaming_failure_total"
        "{phase=\"postcommit\",action=\"abort\"} %uA\n"
        "nginx_markdown_streaming_failure_total"
        "{phase=\"postcommit\",action=\"safe_finish\"}"
        " %uA\n"
        "\n",
        snapshot->streaming.streaming_failure_postcommit_abort,
        snapshot->streaming.streaming_failure_postcommit_safe_finish);

    /* streaming_candidate_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_streaming_candidate_total "
        "Total requests evaluated as "
        "streaming candidates.\n"
        "# TYPE "
        "nginx_markdown_streaming_candidate_total "
        "counter\n"
        "nginx_markdown_streaming_candidate_total %uA\n"
        "\n",
        snapshot->streaming.selection.candidate_total);

    /* true_streaming_selected_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_true_streaming_selected_total "
        "Requests that completed streaming "
        "engine selection.\n"
        "# TYPE "
        "nginx_markdown_true_streaming_selected_total "
        "counter\n"
        "nginx_markdown_true_streaming_selected_total"
        " %uA\n"
        "\n",
        snapshot->streaming.selection.true_streaming_selected_total);

    return p;
}

static u_char *
ngx_http_markdown_metrics_write_prometheus_streaming_outputs(
    u_char *p,
    u_char *end,
    const ngx_http_markdown_metrics_snapshot_t *snapshot)
{

    /* streaming_output_bytes_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_streaming_output_bytes_total "
        "Total Markdown bytes emitted via streaming.\n"
        "# TYPE "
        "nginx_markdown_streaming_output_bytes_total "
        "counter\n"
        "nginx_markdown_streaming_output_bytes_total"
        " %uA\n"
        "\n",
        snapshot->streaming.selection.output_bytes_total);

    /* excluded_content_type_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_excluded_content_type_total "
        "Requests excluded due to content type.\n"
        "# TYPE "
        "nginx_markdown_excluded_content_type_total "
        "counter\n"
        "nginx_markdown_excluded_content_type_total"
        " %uA\n"
        "\n",
        snapshot->streaming.selection.excluded_content_type_total);
    return p;
}
#endif /* MARKDOWN_STREAMING_ENABLED */

static u_char *
ngx_http_markdown_metrics_write_prometheus_totals(
    u_char *p,
    u_char *end,
    const ngx_http_markdown_metrics_snapshot_t *snapshot)
{
    /* input_bytes_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_input_bytes_total "
        "Cumulative HTML input bytes from successful "
        "conversions.\n"
        "# TYPE nginx_markdown_input_bytes_total counter\n"
        "nginx_markdown_input_bytes_total %uA\n"
        "\n",
        snapshot->input_bytes);

    /* output_bytes_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_output_bytes_total "
        "Cumulative Markdown output bytes from successful "
        "conversions.\n"
        "# TYPE nginx_markdown_output_bytes_total counter\n"
        "nginx_markdown_output_bytes_total %uA\n"
        "\n",
        snapshot->output_bytes);

    /* estimated_token_savings_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_estimated_token_savings_total"
        " Estimated cumulative token savings "
        "(requires markdown_token_estimate on).\n"
        "# TYPE "
        "nginx_markdown_estimated_token_savings_total "
        "counter\n"
        "nginx_markdown_estimated_token_savings_total"
        " %uA\n"
        "\n",
        snapshot->results.estimated_token_savings);

    /* decompressions_total{format=...} */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_decompressions_total "
        "Decompression operations by format.\n"
        "# TYPE nginx_markdown_decompressions_total "
        "counter\n"
        "nginx_markdown_decompressions_total"
        "{format=\"gzip\"} %uA\n"
        "nginx_markdown_decompressions_total"
        "{format=\"deflate\"} %uA\n"
        "nginx_markdown_decompressions_total"
        "{format=\"brotli\"} %uA\n"
        "\n",
        snapshot->decompressions.gzip,
        snapshot->decompressions.deflate,
        snapshot->decompressions.brotli);

    /* decompression_failures_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_decompression_failures_total "
        "Failed decompression attempts.\n"
        "# TYPE "
        "nginx_markdown_decompression_failures_total "
        "counter\n"
        "nginx_markdown_decompression_failures_total"
        " %uA\n"
        "\n",
        snapshot->decompressions.failed);

    /* decompression_budget_exceeded_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_decompression_budget_exceeded_total "
        "Decompression operations that exceeded the configured budget.\n"
        "# TYPE "
        "nginx_markdown_decompression_budget_exceeded_total "
        "counter\n"
        "nginx_markdown_decompression_budget_exceeded_total"
        " %uA\n"
        "\n",
        snapshot->decompressions.budget_exceeded_total);

    /* decompression_format_error_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_decompression_format_error_total "
        "Decompression operations that failed due to "
        "invalid format.\n"
        "# TYPE "
        "nginx_markdown_decompression_format_error_total "
        "counter\n"
        "nginx_markdown_decompression_format_error_total"
        " %uA\n"
        "\n",
        snapshot->decompressions.format_error_total);

    /* decompression_truncated_input_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_decompression_truncated_input_total "
        "Decompression operations that failed due to "
        "truncated input.\n"
        "# TYPE "
        "nginx_markdown_decompression_truncated_input_total "
        "counter\n"
        "nginx_markdown_decompression_truncated_input_total"
        " %uA\n"
        "\n",
        snapshot->decompressions.truncated_input_total);

    /* decompression_io_error_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_decompression_io_error_total "
        "Decompression I/O errors.\n"
        "# TYPE "
        "nginx_markdown_decompression_io_error_total "
        "counter\n"
        "nginx_markdown_decompression_io_error_total"
        " %uA\n"
        "\n",
        snapshot->decompressions.io_error_total);

    /* replay_buffer_errors_total */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_replay_buffer_errors_total "
        "Replay buffer init or append failures.\n"
        "# TYPE "
        "nginx_markdown_replay_buffer_errors_total "
        "counter\n"
        "nginx_markdown_replay_buffer_errors_total"
        " %uA\n"
        "\n",
        snapshot->results.replay_buffer_errors_total);

    /* parse_timeouts_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_parse_timeouts_total "
        "HTML parsing operations that exceeded the configured deadline.\n"
        "# TYPE nginx_markdown_parse_timeouts_total counter\n"
        "nginx_markdown_parse_timeouts_total %uA\n"
        "\n",
        snapshot->results.parse_interrupts.parse_timeouts_total);

    /* parse_budget_exceeded_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_parse_budget_exceeded_total "
        "HTML parsing operations that exceeded the parser memory budget.\n"
        "# TYPE nginx_markdown_parse_budget_exceeded_total counter\n"
        "nginx_markdown_parse_budget_exceeded_total %uA\n"
        "\n",
        snapshot->results.parse_interrupts.parse_budget_exceeded_total);

    /* delivery_total (separate from decision_total) */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_delivery_total "
        "Successful response deliveries after downstream NGX_OK.\n"
        "# TYPE nginx_markdown_delivery_total counter\n"
        "nginx_markdown_delivery_total %uA\n"
        "\n",
        snapshot->results.delivery_count);

    /* decision_total (includes skips and fail-opens) */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_decision_total "
        "Decision engine evaluations (includes skips and fail-opens).\n"
        "# TYPE nginx_markdown_decision_total counter\n"
        "nginx_markdown_decision_total %uA\n"
        "\n",
        snapshot->results.decision_count);

    return p;
}

static u_char *
ngx_http_markdown_metrics_write_prometheus_tail(
    u_char *p,
    u_char *end,
    const ngx_http_markdown_metrics_snapshot_t *snapshot)
{

    /*
     * conversion_latency_bucket_total{le=...}
     *
     * Emitted as cumulative buckets: each le value includes
     * all observations at or below that threshold.
     * le="+Inf" equals the sum of all four discrete counters.
     */
    p = ngx_slprintf(p, end,
        "# HELP "
        "nginx_markdown_conversion_latency_bucket_total "
        "Cumulative conversion count per latency boundary.\n"
        "# TYPE "
        "nginx_markdown_conversion_latency_bucket_total counter\n"
        "nginx_markdown_conversion_latency_bucket_total"
        "{le=\"0.01\"} %uA\n"
        "nginx_markdown_conversion_latency_bucket_total"
        "{le=\"0.1\"} %uA\n"
        "nginx_markdown_conversion_latency_bucket_total"
        "{le=\"1.0\"} %uA\n"
        "nginx_markdown_conversion_latency_bucket_total"
        "{le=\"+Inf\"} %uA\n",
        snapshot->conversion_latency.le_10ms,
        snapshot->conversion_latency.le_10ms
            + snapshot->conversion_latency.le_100ms,
        snapshot->conversion_latency.le_10ms
            + snapshot->conversion_latency.le_100ms
            + snapshot->conversion_latency.le_1000ms,
        snapshot->conversion_latency.le_10ms
            + snapshot->conversion_latency.le_100ms
            + snapshot->conversion_latency.le_1000ms
            + snapshot->conversion_latency.gt_1000ms);

    /* per_path metrics removed from production in 0.9.2 */
#if NGX_HTTP_MARKDOWN_PER_PATH_WALK_ENABLED
    /* per_path_entries */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_per_path_entries "
        "Number of distinct URI paths tracked in per-path metrics.\n"
        "# TYPE nginx_markdown_per_path_entries gauge\n"
        "nginx_markdown_per_path_entries %uA\n"
        "\n",
        snapshot->per_path.path_entries);

    /* per_path_conversions_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_per_path_conversions_total "
        "Total successful conversions recorded in per-path metrics.\n"
        "# TYPE nginx_markdown_per_path_conversions_total counter\n"
        "nginx_markdown_per_path_conversions_total %uA\n"
        "\n",
        snapshot->per_path.path_conversions);

    /* per_path_conversion_time_ms_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_per_path_conversion_time_ms_total "
        "Cumulative conversion time (ms) recorded in per-path metrics.\n"
        "# TYPE nginx_markdown_per_path_conversion_time_ms_total counter\n"
        "nginx_markdown_per_path_conversion_time_ms_total %uA\n"
        "\n",
        snapshot->per_path.path_conversion_time_sum_ms);

    /* per_path_overflow_total */
    p = ngx_slprintf(p, end,
        "# HELP nginx_markdown_per_path_overflow_total "
        "Conversions not retained as individual paths because a per-path "
        "retention limit was reached (cardinality or path length).\n"
        "# TYPE nginx_markdown_per_path_overflow_total counter\n"
        "nginx_markdown_per_path_overflow_total %uA\n"
        "\n",
        snapshot->per_path.overflow_count);
#endif /* NGX_HTTP_MARKDOWN_PER_PATH_WALK_ENABLED */

    return p;
}

/*
 * Render the complete metrics snapshot, including feature-gated streaming,
 * performance, and bounded per-path families.  A NULL return means the
 * caller's response buffer was exhausted or the bounded path renderer failed.
 */
static u_char *
ngx_http_markdown_metrics_write_prometheus(
    u_char *p,
    u_char *end,
    const ngx_http_markdown_metrics_snapshot_t *snapshot)
{
    p = ngx_http_markdown_metrics_write_prometheus_base(p, end, snapshot);
#ifdef MARKDOWN_STREAMING_ENABLED
    p = ngx_http_markdown_metrics_write_prometheus_streaming(
        p, end, snapshot);
    p = ngx_http_markdown_metrics_write_prometheus_streaming_failures(
        p, end, snapshot);
    p = ngx_http_markdown_metrics_write_prometheus_streaming_outputs(
        p, end, snapshot);
#endif
    p = ngx_http_markdown_metrics_write_prometheus_totals(
        p, end, snapshot);
    p = ngx_http_markdown_metrics_write_prometheus_tail(
        p, end, snapshot);
    p = ngx_http_markdown_metrics_write_prometheus_perf(
        p, end, &snapshot->perf);

#if NGX_HTTP_MARKDOWN_PER_PATH_WALK_ENABLED
    p = ngx_http_markdown_metrics_write_prometheus_paths(
        p, end, snapshot);
    if (p == NULL) {
        return NULL;
    }
#endif

    return (p == end) ? NULL : p;
}


#if NGX_HTTP_MARKDOWN_PER_PATH_WALK_ENABLED
/*
 * Append bounded optional path-labelled series to a Prometheus response.
 *
 * The shared-memory RB-tree is read while holding its slab mutex.  The
 * renderer reserves room for the aggregated __other__ pair before emitting
 * individual paths, so cardinality detail cannot exhaust the response buffer.
 * Entries that cannot fit are accumulated into that pair; a write-size
 * mismatch is treated as an error rather than emitting partial series.
 *
 * Parameters:
 *   p        - start of the remaining writable output buffer
 *   end      - one byte beyond the writable output buffer
 *   snapshot - immutable aggregate metrics snapshot
 *
 * Returns:
 *   Updated write position, the unchanged position when paths cannot be
 *   emitted safely, or NULL when an internal rendering invariant fails.
 */
static u_char *
ngx_http_markdown_metrics_write_prometheus_paths(
    u_char *p,
    u_char *end,
    const ngx_http_markdown_metrics_snapshot_t *snapshot)
{
    ngx_shm_zone_t                       *zone;
    ngx_slab_pool_t                      *shpool;
    ngx_http_markdown_metrics_t          *live_metrics;
    ngx_http_markdown_prometheus_path_render_ctx_t render;
    size_t                                header_size;
    size_t                                remaining;
    size_t                                tail_reserve;
    const u_char                         *header_start;
    ngx_uint_t                            have_retained_paths;

    /*
     * Emit only bounded path detail while preserving the aggregated totals.
     * The reserved tail guarantees that omitted entries remain observable
     * through the __other__ series instead of producing partial exposition.
     */
    if (p == NULL || end == NULL || snapshot == NULL) {
        return NULL;
    }

    have_retained_paths = snapshot->per_path.path_entries > 0
        && ngx_http_markdown_metrics_shm_zone != NULL
        && ngx_http_markdown_metrics_shm_zone->data != NULL;
    if (!have_retained_paths
        && snapshot->per_path.unretained_conversions == 0)
    {
        return p;
    }

    if (p > end) {
        return NULL;
    }
    if (p >= end) {
        return p;
    }

    if (ngx_http_markdown_prometheus_path_tail_reserve(&tail_reserve)
        != NGX_OK)
    {
        return NULL;
    }

    if (p > end) {
        return NULL;
    }
    header_size = sizeof(NGX_HTTP_MARKDOWN_PROM_PATH_HEADER) - 1;
    /* CWE-190:guarded */
    remaining = (size_t) (end - p);
    if (header_size > remaining
        || tail_reserve > remaining - header_size)
    {
        return p;
    }

    header_start = p;
    p = ngx_slprintf(p, end, NGX_HTTP_MARKDOWN_PROM_PATH_HEADER);
    /* CWE-190:guarded */
    if (p < header_start || p > end
        || (size_t) (p - header_start) != header_size)
    {
        return NULL;
    }

    render.pos = p;
    render.end = end;
    render.tail_reserve = tail_reserve;
    render.omitted_conversions = 0;
    render.omitted_time_ms = 0;
    render.omitted_nodes = 0;
    render.failed = 0;

    if (have_retained_paths) {
        zone = ngx_http_markdown_metrics_shm_zone;
        live_metrics = (ngx_http_markdown_metrics_t *) zone->data;
        shpool = (ngx_slab_pool_t *) zone->shm.addr;

        ngx_shmtx_lock(&shpool->mutex);
        ngx_http_markdown_prometheus_walk_path_tree(
            live_metrics->per_path.path_tree.root,
            &live_metrics->per_path.sentinel, &render);
        ngx_shmtx_unlock(&shpool->mutex);
    }

    if (render.failed) {
        return NULL;
    }

    p = render.pos;
    if (snapshot->per_path.unretained_conversions > 0
        || render.omitted_nodes > 0)
    {
        p = ngx_http_markdown_prometheus_write_other_path(
            p, end, &render, snapshot->per_path.unretained_conversions,
            snapshot->per_path.unretained_conversion_time_sum_ms);
        if (p == NULL) {
            return NULL;
        }
    }

    *p++ = '\n';
    return p;
}


static u_char *
ngx_http_markdown_prometheus_write_other_path(
    u_char *p,
    const u_char *end,
    ngx_http_markdown_prometheus_path_render_ctx_t *render,
    ngx_atomic_uint_t unretained_conversions,
    ngx_atomic_uint_t unretained_time_ms)
{
    static const u_char      other_path[] = "__other__";
    ngx_atomic_uint_t        other_conversions;
    size_t                   needed;
    size_t                   remaining;

    if (p == NULL || end == NULL || render == NULL || p > end) {
        return NULL;
    }

    other_conversions = ngx_http_markdown_prometheus_saturating_add(
        unretained_conversions, render->omitted_conversions);
    if (ngx_http_markdown_prometheus_path_pair_size(
            other_path, sizeof(other_path) - 1, other_conversions,
            ngx_http_markdown_prometheus_saturating_add(
                unretained_time_ms, render->omitted_time_ms), &needed) != NGX_OK)
    {
        return NULL;
    }

    if (p > end) {
        return NULL;
    }
    /* CWE-190:guarded */
    remaining = (size_t) (end - p);
    if (remaining < 1 || needed > remaining - 1) {
        return NULL;
    }

    render->pos = p;
    render->tail_reserve = 1;
    if (ngx_http_markdown_prometheus_write_path_pair(
        render, other_path, sizeof(other_path) - 1,
            other_conversions,
            ngx_http_markdown_prometheus_saturating_add(
                unretained_time_ms, render->omitted_time_ms), needed) != NGX_OK)
    {
        return NULL;
    }

    return render->pos;
}


/*
 * Write a two-character escape sequence (backslash + second char)
 * into the destination buffer for Prometheus label syntax.
 *
 * Returns the updated write position, or last if the buffer
 * cannot accommodate two more bytes.
 */
static u_char *
ngx_http_markdown_escape_prom_two_char(u_char *dst, u_char *last,
                                       u_char second)
{
    if (dst + 2 > last) {
        return last;
    }

    *dst++ = '\\';
    *dst++ = second;

    return dst;
}


/*
 * Escape a byte string for use as a Prometheus label value.
 *
 * Prometheus label values require escaping: \ -> \\, " -> \", newline -> \n.
 * Carriage return and tab are also escaped for safety.
 *
 * Parameters:
 *   dst  - destination buffer start
 *   last - one past end of destination buffer
 *   src  - source bytes
 *   len  - source length
 *
 * Returns:
 *   Updated write position (clamped to last on overflow).
 */
static u_char *
ngx_http_markdown_escape_prometheus_label(u_char *dst, u_char *last,
                                          const u_char *src, size_t len)
{
    size_t   i;
    u_char   ch;

    i = 0;
    while (i < len && dst < last) {
        ch = src[i];
        i++;

        switch (ch) {
        case '\\':
            dst = ngx_http_markdown_escape_prom_two_char(dst, last, '\\');
            break;
        case '"':
            dst = ngx_http_markdown_escape_prom_two_char(dst, last, '"');
            break;
        case '\n':
            dst = ngx_http_markdown_escape_prom_two_char(dst, last, 'n');
            break;
        case '\r':
            dst = ngx_http_markdown_escape_prom_two_char(dst, last, 'r');
            break;
        case '\t':
            dst = ngx_http_markdown_escape_prom_two_char(dst, last, 't');
            break;
        default:
            if (ch >= 0x20) {
                *dst++ = ch;
                break;
            }

            /* Other control characters: emit as \uXXXX */
            if (dst + 6 > last) {
                return last;
            }
            dst = ngx_snprintf(dst, 6, "\\u%04X", (unsigned) ch);
            break;
        }
    }

    return dst;
}


static ngx_int_t
ngx_http_markdown_prometheus_checked_size_add(size_t *total, size_t value)
{
    if (*total > (size_t) -1 - value) {
        return NGX_ERROR;
    }

    *total += value;
    return NGX_OK;
}


static ngx_int_t
ngx_http_markdown_prometheus_escaped_label_size(
    const u_char *src,
    size_t len,
    size_t *escaped_size)
{
    size_t  increment;
    size_t  total;
    u_char  ch;

    if (escaped_size == NULL || (src == NULL && len > 0)) {
        return NGX_ERROR;
    }

    total = 0;
    for (size_t i = 0; i < len; i++) {
        ch = src[i];

        switch (ch) {
        case '\\':
        case '"':
        case '\n':
        case '\r':
        case '\t':
            increment = 2;
            break;
        default:
            increment = (ch < 0x20) ? 6 : 1;
            break;
        }

        if (ngx_http_markdown_prometheus_checked_size_add(
                &total, increment)
            != NGX_OK)
        {
            return NGX_ERROR;
        }
    }

    *escaped_size = total;
    return NGX_OK;
}


static size_t
ngx_http_markdown_prometheus_uint_digits(ngx_atomic_uint_t value)
{
    size_t  digits;

    digits = 1;
    while (value >= 10) {
        value /= 10;
        digits++;
    }

    return digits;
}


static ngx_int_t
ngx_http_markdown_prometheus_path_pair_size(
    const u_char *path,
    size_t path_len,
    ngx_atomic_uint_t conversions,
    ngx_atomic_uint_t conversion_time_ms,
    size_t *needed)
{
    size_t  escaped_size;
    size_t  total;

    if (needed == NULL
        || ngx_http_markdown_prometheus_escaped_label_size(
               path, path_len, &escaped_size)
           != NGX_OK)
    {
        return NGX_ERROR;
    }

    total = sizeof(NGX_HTTP_MARKDOWN_PROM_PATH_CONVERSIONS_PREFIX) - 1
        + sizeof(NGX_HTTP_MARKDOWN_PROM_PATH_TIME_PREFIX) - 1
        + 2 * (sizeof(NGX_HTTP_MARKDOWN_PROM_PATH_VALUE_PREFIX) - 1)
        + 2;

    if (ngx_http_markdown_prometheus_checked_size_add(
            &total, escaped_size)
        != NGX_OK)
    {
        return NGX_ERROR;
    }

    if (ngx_http_markdown_prometheus_checked_size_add(
            &total, escaped_size)
        != NGX_OK
        || ngx_http_markdown_prometheus_checked_size_add(
               &total,
               ngx_http_markdown_prometheus_uint_digits(conversions))
           != NGX_OK
        || ngx_http_markdown_prometheus_checked_size_add(
               &total,
               ngx_http_markdown_prometheus_uint_digits(
                   conversion_time_ms))
           != NGX_OK)
    {
        return NGX_ERROR;
    }

    *needed = total;
    return NGX_OK;
}


static ngx_atomic_uint_t
ngx_http_markdown_prometheus_saturating_add(
    ngx_atomic_uint_t left,
    ngx_atomic_uint_t right)
{
    ngx_atomic_uint_t  maximum;

    maximum = (ngx_atomic_uint_t) -1;
    if (left > maximum - right) {
        return maximum;
    }

    return left + right;
}


static ngx_int_t
ngx_http_markdown_prometheus_path_tail_reserve(size_t *reserve)
{
    static const u_char  other_path[] = "__other__";
    size_t               pair_size;

    if (reserve == NULL
        || ngx_http_markdown_prometheus_path_pair_size(
               other_path, sizeof(other_path) - 1,
               (ngx_atomic_uint_t) -1, (ngx_atomic_uint_t) -1,
               &pair_size)
           != NGX_OK
        || pair_size == (size_t) -1)
    {
        return NGX_ERROR;
    }

    *reserve = pair_size + 1;
    return NGX_OK;
}


static ngx_int_t
ngx_http_markdown_prometheus_write_path_pair(
    ngx_http_markdown_prometheus_path_render_ctx_t *render,
    const u_char *path,
    size_t path_len,
    ngx_atomic_uint_t conversions,
    ngx_atomic_uint_t conversion_time_ms,
    size_t needed)
{
    size_t   remaining;
    const u_char  *start;

    if (render == NULL || render->pos == NULL || render->end == NULL
        || render->pos > render->end)
    {
        if (render != NULL) {
            render->failed = 1;
        }
        return NGX_ERROR;
    }

    remaining = (size_t) (render->end - render->pos);
    if (render->tail_reserve > remaining
        || needed > remaining - render->tail_reserve)
    {
        return NGX_DECLINED;
    }

    start = render->pos;
    render->pos = ngx_slprintf(render->pos, render->end,
        NGX_HTTP_MARKDOWN_PROM_PATH_CONVERSIONS_PREFIX);
    render->pos = ngx_http_markdown_escape_prometheus_label(
        render->pos, render->end, path, path_len);
    render->pos = ngx_slprintf(render->pos, render->end,
        NGX_HTTP_MARKDOWN_PROM_PATH_VALUE_PREFIX "%uA\n",
        conversions);
    render->pos = ngx_slprintf(render->pos, render->end,
        NGX_HTTP_MARKDOWN_PROM_PATH_TIME_PREFIX);
    render->pos = ngx_http_markdown_escape_prometheus_label(
        render->pos, render->end, path, path_len);
    render->pos = ngx_slprintf(render->pos, render->end,
        NGX_HTTP_MARKDOWN_PROM_PATH_VALUE_PREFIX "%uA\n",
        conversion_time_ms);

    if ((size_t) (render->pos - start) != needed) {
        render->failed = 1;
        return NGX_ERROR;
    }

    return NGX_OK;
}


static void
ngx_http_markdown_prometheus_accumulate_omitted_path(
    ngx_http_markdown_prometheus_path_render_ctx_t *render,
    ngx_atomic_uint_t conversions,
    ngx_atomic_uint_t conversion_time_ms)
{
    render->omitted_conversions =
        ngx_http_markdown_prometheus_saturating_add(
            render->omitted_conversions, conversions);
    render->omitted_time_ms =
        ngx_http_markdown_prometheus_saturating_add(
            render->omitted_time_ms, conversion_time_ms);

    if (render->omitted_nodes != (ngx_uint_t) -1) {
        render->omitted_nodes++;
    }
}


/*
 * Recursive in-order walk of the per-path RB-tree for Prometheus output.
 *
 * Emits two metric lines per node:
 *   nginx_markdown_path_conversions_total{path="..."} <val>
 *   nginx_markdown_path_conversion_time_ms_total{path="..."} <val>
 *
 * Parameters:
 *   node     - current RB-tree node (or sentinel to terminate)
 *   sentinel - tree sentinel node
 *   render   - output cursor, reserved tail budget, and omission aggregate
 */
static void
ngx_http_markdown_prometheus_walk_path_tree(
    ngx_rbtree_node_t *node,
    ngx_rbtree_node_t *sentinel,
    ngx_http_markdown_prometheus_path_render_ctx_t *render)
{
    const ngx_http_markdown_path_metric_node_t  *pnode;
    ngx_atomic_uint_t                            conversions;
    ngx_atomic_uint_t                            conversion_time_ms;
    size_t                                       needed;
    ngx_int_t                                    rc;

    if (render == NULL) {
        return;
    }

    if (node == NULL || sentinel == NULL) {
        render->failed = 1;
        return;
    }

    if (node == sentinel || render->failed) {
        return;
    }

    ngx_http_markdown_prometheus_walk_path_tree(
        node->left, sentinel, render);
    if (render->failed) {
        return;
    }

    pnode = (const ngx_http_markdown_path_metric_node_t *) node;
    conversions = pnode->conversions;
    conversion_time_ms = pnode->conversion_time_sum_ms;

    rc = ngx_http_markdown_prometheus_path_pair_size(
        pnode->path, pnode->path_len, conversions,
        conversion_time_ms, &needed);
    if (rc != NGX_OK) {
        render->failed = 1;
        return;
    }

    rc = ngx_http_markdown_prometheus_write_path_pair(
        render, pnode->path, pnode->path_len,
        conversions, conversion_time_ms, needed);
    if (rc == NGX_DECLINED) {
        ngx_http_markdown_prometheus_accumulate_omitted_path(
            render, conversions, conversion_time_ms);
    } else if (rc != NGX_OK) {
        return;
    }

    ngx_http_markdown_prometheus_walk_path_tree(
        node->right, sentinel, render);
}
#endif /* NGX_HTTP_MARKDOWN_PER_PATH_WALK_ENABLED */

#endif /* NGX_HTTP_MARKDOWN_PROMETHEUS_IMPL_H */
