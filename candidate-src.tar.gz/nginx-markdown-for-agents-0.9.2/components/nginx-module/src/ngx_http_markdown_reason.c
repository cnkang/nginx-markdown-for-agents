/*
 * NGINX Markdown Filter Module - Reason Code Lookup (via Rust FFI)
 *
 * This file provides accessor functions that map C-side eligibility enums
 * and error categories to reason code strings.  All strings are sourced
 * from the Rust ReasonCode enum via FFI — there are no C-side string
 * literals for reason codes.
 *
 * The Rust enum in components/rust-converter/src/decision/reason_code.rs
 * is the SINGLE SOURCE OF TRUTH for all reason code strings.
 *
 * Requirements: FR-01.1, FR-01.2, FR-01.3, FR-01.4, FR-01.5,
 *               FR-13.3, FR-13.4
 */

#include "ngx_http_markdown_filter_module.h"


/*
 * Forward-declare the FFI wrapper so this translation unit does not
 * need to include the full markdown_converter.h header.
 */
ngx_int_t ngx_http_markdown_get_reason_code_str(uint32_t code,
    ngx_str_t *out_str);


/*
 * Reason code discriminant constants matching the Rust ReasonCode enum.
 *
 * These MUST stay in sync with ReasonCode in
 * components/rust-converter/src/decision/reason_code.rs.
 * See that file for the full variant list and string representations.
 */
#define REASON_CONVERTED                 0
#define REASON_SKIPPED_ACCEPT            1
#define REASON_SKIPPED_NO_ACCEPT         2
#define REASON_SKIPPED_CONDITIONAL       3
#define REASON_DECOMPRESSION_ERROR       4
#define REASON_DECOMPRESSION_BUDGET_EXCEEDED  5
#define REASON_DECOMPRESSION_FORMAT_ERROR     6
#define REASON_DECOMPRESSION_TRUNCATED_INPUT  7
#define REASON_DECOMPRESSION_IO_ERROR         8
#define REASON_TIMEOUT                   9
#define REASON_BUDGET_EXCEEDED          10
#define REASON_REPLAY_ERROR             11
#define REASON_SKIPPED_ACCEPT_REJECT    12
#define REASON_FFI_PANIC                13
#define REASON_NOT_ELIGIBLE             14
#define REASON_DISABLED                 15
#define REASON_FAILED_OPEN              16
#define REASON_FAILED_CLOSED            17
#define REASON_CONVERSION_ERROR         18
#define REASON_MEMORY_BUDGET_EXCEEDED   19
#define REASON_OVERLOAD                 20
#define REASON_INVALID_DYNCONF          21
#define REASON_DEGRADED_SNAPSHOT        22
#define REASON_HEADER_PLAN_APPLY_ERR    23
#define REASON_STREAMING_MID_FLIGHT_ERR 24
#define REASON_BYPASS_NO_TRANSFORM      25
#define REASON_ENCODING_HEADER_INVALID  26


/*
 * Static ngx_str_t storage for each accessor return value.
 *
 * Because the accessor functions return `const ngx_str_t *`, we need
 * stable storage.  These are populated lazily on first call; the
 * underlying string data points to static Rust memory (process-lifetime).
 */
static ngx_str_t  reason_str_converted;
static ngx_str_t  reason_str_skipped_accept;
static ngx_str_t  reason_str_skipped_no_accept;
static ngx_str_t  reason_str_skipped_conditional;
static ngx_str_t  reason_str_decompression_error;
static ngx_str_t  reason_str_decompression_budget_exceeded;
static ngx_str_t  reason_str_decompression_format_error;
static ngx_str_t  reason_str_decompression_truncated_input;
static ngx_str_t  reason_str_decompression_io_error;
static ngx_str_t  reason_str_timeout;
static ngx_str_t  reason_str_budget_exceeded;
static ngx_str_t  reason_str_replay_error;
static ngx_str_t  reason_str_skipped_accept_reject;
static ngx_str_t  reason_str_not_eligible;
static ngx_str_t  reason_str_disabled;
static ngx_str_t  reason_str_failed_open;
static ngx_str_t  reason_str_failed_closed;
static ngx_str_t  reason_str_conversion_error;
static ngx_str_t  reason_str_memory_budget_exceeded;
static ngx_str_t  reason_str_overload;
static ngx_str_t  reason_str_invalid_dynconf;
static ngx_str_t  reason_str_degraded_snapshot;
static ngx_str_t  reason_str_header_plan_apply_err;
static ngx_str_t  reason_str_streaming_mid_flight_err;
static ngx_str_t  reason_str_ffi_panic;
static ngx_str_t  reason_str_bypass_no_transform;
static ngx_str_t  reason_str_encoding_header_invalid;

static ngx_flag_t reason_strs_initialized = 0;


/*
 * Initialize all static reason string storage from Rust FFI.
 *
 * Called once on first use.  After this, all reason_str_* variables
 * contain valid ngx_str_t values pointing to Rust static memory.
 */
static void
ngx_http_markdown_reason_init_strs(void)
{
    if (reason_strs_initialized) {
        return;
    }

    ngx_http_markdown_get_reason_code_str(REASON_CONVERTED,
        &reason_str_converted);
    ngx_http_markdown_get_reason_code_str(REASON_SKIPPED_ACCEPT,
        &reason_str_skipped_accept);
    ngx_http_markdown_get_reason_code_str(REASON_SKIPPED_NO_ACCEPT,
        &reason_str_skipped_no_accept);
    ngx_http_markdown_get_reason_code_str(REASON_SKIPPED_CONDITIONAL,
        &reason_str_skipped_conditional);
    ngx_http_markdown_get_reason_code_str(REASON_DECOMPRESSION_ERROR,
        &reason_str_decompression_error);
    ngx_http_markdown_get_reason_code_str(REASON_DECOMPRESSION_BUDGET_EXCEEDED,
        &reason_str_decompression_budget_exceeded);
    ngx_http_markdown_get_reason_code_str(REASON_DECOMPRESSION_FORMAT_ERROR,
        &reason_str_decompression_format_error);
    ngx_http_markdown_get_reason_code_str(REASON_DECOMPRESSION_TRUNCATED_INPUT,
        &reason_str_decompression_truncated_input);
    ngx_http_markdown_get_reason_code_str(REASON_DECOMPRESSION_IO_ERROR,
        &reason_str_decompression_io_error);
    ngx_http_markdown_get_reason_code_str(REASON_TIMEOUT,
        &reason_str_timeout);
    ngx_http_markdown_get_reason_code_str(REASON_BUDGET_EXCEEDED,
        &reason_str_budget_exceeded);
    ngx_http_markdown_get_reason_code_str(REASON_REPLAY_ERROR,
        &reason_str_replay_error);
    ngx_http_markdown_get_reason_code_str(REASON_SKIPPED_ACCEPT_REJECT,
        &reason_str_skipped_accept_reject);
    ngx_http_markdown_get_reason_code_str(REASON_NOT_ELIGIBLE,
        &reason_str_not_eligible);
    ngx_http_markdown_get_reason_code_str(REASON_DISABLED,
        &reason_str_disabled);
    ngx_http_markdown_get_reason_code_str(REASON_FAILED_OPEN,
        &reason_str_failed_open);
    ngx_http_markdown_get_reason_code_str(REASON_FAILED_CLOSED,
        &reason_str_failed_closed);
    ngx_http_markdown_get_reason_code_str(REASON_CONVERSION_ERROR,
        &reason_str_conversion_error);
    ngx_http_markdown_get_reason_code_str(REASON_MEMORY_BUDGET_EXCEEDED,
        &reason_str_memory_budget_exceeded);
    ngx_http_markdown_get_reason_code_str(REASON_OVERLOAD,
        &reason_str_overload);
    ngx_http_markdown_get_reason_code_str(REASON_INVALID_DYNCONF,
        &reason_str_invalid_dynconf);
    ngx_http_markdown_get_reason_code_str(REASON_DEGRADED_SNAPSHOT,
        &reason_str_degraded_snapshot);
    ngx_http_markdown_get_reason_code_str(REASON_HEADER_PLAN_APPLY_ERR,
        &reason_str_header_plan_apply_err);
    ngx_http_markdown_get_reason_code_str(REASON_STREAMING_MID_FLIGHT_ERR,
        &reason_str_streaming_mid_flight_err);
    ngx_http_markdown_get_reason_code_str(REASON_FFI_PANIC,
        &reason_str_ffi_panic);
    ngx_http_markdown_get_reason_code_str(REASON_BYPASS_NO_TRANSFORM,
        &reason_str_bypass_no_transform);
    ngx_http_markdown_get_reason_code_str(REASON_ENCODING_HEADER_INVALID,
        &reason_str_encoding_header_invalid);

    reason_strs_initialized = 1;
}


/*
 * Map eligibility enum to reason code string (via Rust FFI).
 *
 * All INELIGIBLE_* variants now map to "not_eligible" (discriminant 14)
 * except INELIGIBLE_CONFIG which maps to "disabled" (discriminant 15).
 *
 * For NGX_HTTP_MARKDOWN_ELIGIBLE the caller should use one of the
 * outcome-specific helpers (converted, failed_open, failed_closed)
 * instead; this function returns "ffi_panic" as a fallback.
 *
 * Parameters:
 *   eligibility - eligibility enum value
 *   log         - NGINX log for warning on unknown values (may be NULL)
 *
 * Returns:
 *   Pointer to static ngx_str_t with the reason code string
 */
const ngx_str_t *
ngx_http_markdown_reason_from_eligibility(
    ngx_http_markdown_eligibility_t eligibility, ngx_log_t *log)
{
    ngx_http_markdown_reason_init_strs();

    switch (eligibility) {

    case NGX_HTTP_MARKDOWN_INELIGIBLE_CONFIG:
        return &reason_str_disabled;

    case NGX_HTTP_MARKDOWN_INELIGIBLE_METHOD:
    case NGX_HTTP_MARKDOWN_INELIGIBLE_STATUS:
    case NGX_HTTP_MARKDOWN_INELIGIBLE_CONTENT_TYPE:
    case NGX_HTTP_MARKDOWN_INELIGIBLE_SIZE:
    case NGX_HTTP_MARKDOWN_INELIGIBLE_STREAMING:
    case NGX_HTTP_MARKDOWN_INELIGIBLE_AUTH:
    case NGX_HTTP_MARKDOWN_INELIGIBLE_RANGE:
        return &reason_str_not_eligible;

    case NGX_HTTP_MARKDOWN_ELIGIBLE:
        if (log != NULL) {
            ngx_log_error(NGX_LOG_ERR, log, 0,
                          "markdown: NGX_HTTP_MARKDOWN_ELIGIBLE "
                          "passed to mapper, callers must pick "
                          "explicit outcome reason "
                          "(converted/failed)");
        }
        break;

    default:
        if (log != NULL) {
            ngx_log_error(NGX_LOG_WARN, log, 0,
                          "markdown: unknown eligibility "
                          "value %d, returning ffi_panic",
                          (int) eligibility);
        }
        break;
    }

    return &reason_str_ffi_panic;
}


/*
 * Map error category enum to failure reason code string (via Rust FFI).
 *
 * LEGACY FUNCTION: This maps the coarse three-category enum to reason
 * codes.  For fine-grained error classification (InvalidDynconf,
 * DegradedSnapshot, HeaderPlanApplyError, etc.), callers should classify raw
 * converter codes with `markdown_classify_error_code()` and log the canonical
 * reason selected by the owning runtime path.
 *
 * The ERROR_SYSTEM → ffi_panic mapping is a simplification: not all
 * system-category errors are FFI panics, but this coarse enum does not
 * distinguish them.  New code paths should use the Rust FFI error
 * classification and canonical reason accessors instead of this function.
 *
 * Parameters:
 *   category - error category enum value
 *   log      - NGINX log for warning on unknown values (may be NULL)
 *
 * Returns:
 *   Pointer to static ngx_str_t with the reason code string
 */
const ngx_str_t *
ngx_http_markdown_reason_from_error_category(
    ngx_http_markdown_error_category_t category, ngx_log_t *log)
{
    ngx_http_markdown_reason_init_strs();

    switch (category) {

    case NGX_HTTP_MARKDOWN_ERROR_CONVERSION:
        return &reason_str_conversion_error;

    case NGX_HTTP_MARKDOWN_ERROR_RESOURCE_LIMIT:
        return &reason_str_memory_budget_exceeded;

    case NGX_HTTP_MARKDOWN_ERROR_SYSTEM:
        return &reason_str_ffi_panic;

    default:
        if (log != NULL) {
            ngx_log_error(NGX_LOG_WARN, log, 0,
                          "markdown: unknown error "
                          "category %d, returning ffi_panic",
                          (int) category);
        }
        return &reason_str_ffi_panic;
    }
}


/*
 * Return the "converted" reason code.
 *
 * Returns:
 *   Pointer to static ngx_str_t "converted"
 */
const ngx_str_t *
ngx_http_markdown_reason_converted(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_converted;
}


/*
 * Return the "failed_open" reason code.
 *
 * Returns:
 *   Pointer to static ngx_str_t "failed_open"
 */
const ngx_str_t *
ngx_http_markdown_reason_failed_open(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_failed_open;
}


/*
 * Return the "failed_closed" reason code.
 *
 * Returns:
 *   Pointer to static ngx_str_t "failed_closed"
 */
const ngx_str_t *
ngx_http_markdown_reason_failed_closed(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_failed_closed;
}


/*
 * Return the "skipped_accept" reason code.
 *
 * Accept-based skip is not part of the eligibility enum because
 * Accept negotiation happens after the eligibility check.
 *
 * Returns:
 *   Pointer to static ngx_str_t "skipped_accept"
 */
const ngx_str_t *
ngx_http_markdown_reason_skip_accept(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_skipped_accept;
}


/*
 * Return the "skipped_no_accept" reason code.
 *
 * Used when no Accept header is present in the request.
 *
 * Returns:
 *   Pointer to static ngx_str_t "skipped_no_accept"
 */
const ngx_str_t *
ngx_http_markdown_reason_skip_no_accept(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_skipped_no_accept;
}


/*
 * Return the "skipped_accept_reject" reason code.
 *
 * Used when the client explicitly rejects text/markdown (q=0).
 *
 * Returns:
 *   Pointer to static ngx_str_t "skipped_accept_reject"
 */
const ngx_str_t *
ngx_http_markdown_reason_skip_accept_reject(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_skipped_accept_reject;
}


/*
 * Return the "skipped_conditional" reason code.
 *
 * Used when a conditional request matches (304 Not Modified).
 *
 * Returns:
 *   Pointer to static ngx_str_t "skipped_conditional"
 */
const ngx_str_t *
ngx_http_markdown_reason_skip_conditional(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_skipped_conditional;
}

/*
 * Return the reason string for a decompression failure.
 *
 * Returns:
 *   Pointer to static ngx_str_t "decompression_error"
 */
const ngx_str_t *
ngx_http_markdown_reason_decompression_error(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_decompression_error;
}

/*
 * Return the reason string for an exhausted decompression budget.
 *
 * Returns:
 *   Pointer to static ngx_str_t "decompression_budget_exceeded"
 */
const ngx_str_t *
ngx_http_markdown_reason_decompression_budget_exceeded(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_decompression_budget_exceeded;
}

/*
 * Return the reason string for an unsupported decompression format.
 *
 * Returns:
 *   Pointer to static ngx_str_t "decompression_format_error"
 */
const ngx_str_t *
ngx_http_markdown_reason_decompression_format_error(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_decompression_format_error;
}

/*
 * Return the reason string for truncated decompression input.
 *
 * Returns:
 *   Pointer to static ngx_str_t "decompression_truncated_input"
 */
const ngx_str_t *
ngx_http_markdown_reason_decompression_truncated_input(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_decompression_truncated_input;
}

/*
 * Return the reason string for decompression I/O failure.
 *
 * Returns:
 *   Pointer to static ngx_str_t "decompression_io_error"
 */
const ngx_str_t *
ngx_http_markdown_reason_decompression_io_error(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_decompression_io_error;
}

/*
 * Return the reason string for a request timeout.
 *
 * Returns:
 *   Pointer to static ngx_str_t "timeout"
 */
const ngx_str_t *
ngx_http_markdown_reason_timeout(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_timeout;
}

/*
 * Return the reason string for an exhausted processing budget.
 *
 * Returns:
 *   Pointer to static ngx_str_t "budget_exceeded"
 */
const ngx_str_t *
ngx_http_markdown_reason_budget_exceeded(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_budget_exceeded;
}

/*
 * Return the reason string for replay-buffer failure.
 *
 * Returns:
 *   Pointer to static ngx_str_t "replay_error"
 */
const ngx_str_t *
ngx_http_markdown_reason_replay_error(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_replay_error;
}


const ngx_str_t *
ngx_http_markdown_reason_overload(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_overload;
}

const ngx_str_t *
ngx_http_markdown_reason_invalid_dynconf(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_invalid_dynconf;
}

const ngx_str_t *
ngx_http_markdown_reason_degraded_snapshot(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_degraded_snapshot;
}

const ngx_str_t *
ngx_http_markdown_reason_header_plan_apply_err(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_header_plan_apply_err;
}

const ngx_str_t *
ngx_http_markdown_reason_streaming_mid_flight_err(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_streaming_mid_flight_err;
}


/*
 * Return the "bypass_no_transform" reason code.
 *
 * Used when Cache-Control: no-transform bypasses conversion entirely
 * (RFC 9111 §5.2.2.6).
 *
 * Returns:
 *   Pointer to static ngx_str_t "bypass_no_transform"
 */
const ngx_str_t *
ngx_http_markdown_reason_bypass_no_transform(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_bypass_no_transform;
}


/*
 * Return the "encoding_header_invalid" reason code.
 *
 * Used when the Content-Encoding chain grammar is malformed (empty/quoted
 * token, comma error, token parameter, control character, or overlong
 * token).  The reason is emitted during outer precommit routing with
 * stage=decompression and error_origin=format; no decoder is started and
 * no response header is mutated before the policy outcome is committed.
 */
const ngx_str_t *
ngx_http_markdown_reason_encoding_header_invalid(void)
{
    ngx_http_markdown_reason_init_strs();
    return &reason_str_encoding_header_invalid;
}


/*
 * Compressed responses can be skipped in both full-buffer and streaming
 * builds, so this reason must remain available without the streaming feature.
 */
static ngx_str_t ngx_http_markdown_reason_streaming_skip_compressed_str =
    ngx_string("STREAMING_SKIP_COMPRESSED");

const ngx_str_t *
ngx_http_markdown_reason_streaming_skip_compressed(void)
{
    return &ngx_http_markdown_reason_streaming_skip_compressed_str;
}


#ifdef MARKDOWN_STREAMING_ENABLED

/*
 * Streaming reason codes.
 *
 * These are C-only reason codes for the streaming path.  They do NOT
 * have a corresponding Rust ReasonCode variant yet (streaming codes
 * are local to the C streaming engine).  They retain their UPPERCASE
 * format as legacy constants until a future spec adds them to Rust.
 *
 * NAMING CONVENTION NOTE: These UPPERCASE codes differ from the
 * lowercase snake_case convention used by the Rust ReasonCode enum.
 * This is a known inconsistency.  It does not affect production
 * behavior because these codes are internal to the C streaming engine
 * and are not emitted through the Rust FFI reason-code accessor path.
 * In the 1.x release, when streaming reason codes are migrated to
 * Rust enum variants, they will be renamed to lowercase snake_case
 * (e.g. streaming_convert, streaming_fail_postcommit).  See
 * docs/harness/rules/observability-metrics.md for the full migration
 * plan.
 */

static ngx_str_t ngx_http_markdown_reason_engine_streaming_str =
    ngx_string("ENGINE_STREAMING");
static ngx_str_t ngx_http_markdown_reason_streaming_convert_str =
    ngx_string("STREAMING_CONVERT");
static ngx_str_t ngx_http_markdown_reason_streaming_fallback_str =
    ngx_string("STREAMING_FALLBACK_PREBUFFER");
static ngx_str_t ngx_http_markdown_reason_streaming_fail_postcommit_str =
    ngx_string("STREAMING_FAIL_POSTCOMMIT");
static ngx_str_t ngx_http_markdown_reason_streaming_skip_str =
    ngx_string("STREAMING_SKIP_UNSUPPORTED");
static ngx_str_t ngx_http_markdown_reason_streaming_budget_str =
    ngx_string("STREAMING_BUDGET_EXCEEDED");
static ngx_str_t ngx_http_markdown_reason_streaming_precommit_failopen_str =
    ngx_string("STREAMING_PRECOMMIT_FAILOPEN");
static ngx_str_t ngx_http_markdown_reason_streaming_precommit_reject_str =
    ngx_string("STREAMING_PRECOMMIT_REJECT");
#ifdef MARKDOWN_STREAMING_SHADOW_DEBUG
static ngx_str_t ngx_http_markdown_reason_streaming_shadow_str =
    ngx_string("STREAMING_SHADOW");
#endif

/* Auto-mode engine selection reason codes */
static ngx_str_t ngx_http_markdown_reason_eligible_streaming_auto_str =
    ngx_string("ELIGIBLE_STREAMING_AUTO");
static ngx_str_t ngx_http_markdown_reason_eligible_fullbuffer_auto_str =
    ngx_string("ELIGIBLE_FULLBUFFER_AUTO");


const ngx_str_t *
ngx_http_markdown_reason_engine_streaming(void)
{
    return &ngx_http_markdown_reason_engine_streaming_str;
}

const ngx_str_t *
ngx_http_markdown_reason_streaming_convert(void)
{
    return &ngx_http_markdown_reason_streaming_convert_str;
}

const ngx_str_t *
ngx_http_markdown_reason_streaming_fallback(void)
{
    return &ngx_http_markdown_reason_streaming_fallback_str;
}

const ngx_str_t *
ngx_http_markdown_reason_streaming_fail_postcommit(void)
{
    return &ngx_http_markdown_reason_streaming_fail_postcommit_str;
}

const ngx_str_t *
ngx_http_markdown_reason_streaming_skip_unsupported(void)
{
    return &ngx_http_markdown_reason_streaming_skip_str;
}

const ngx_str_t *
ngx_http_markdown_reason_streaming_budget_exceeded(void)
{
    return &ngx_http_markdown_reason_streaming_budget_str;
}

const ngx_str_t *
ngx_http_markdown_reason_streaming_precommit_failopen(void)
{
    return &ngx_http_markdown_reason_streaming_precommit_failopen_str;
}

const ngx_str_t *
ngx_http_markdown_reason_streaming_precommit_reject(void)
{
    return &ngx_http_markdown_reason_streaming_precommit_reject_str;
}

#ifdef MARKDOWN_STREAMING_SHADOW_DEBUG
const ngx_str_t *
ngx_http_markdown_reason_streaming_shadow(void)
{
    return &ngx_http_markdown_reason_streaming_shadow_str;
}
#endif

const ngx_str_t *
ngx_http_markdown_reason_eligible_streaming_auto(void)
{
    return &ngx_http_markdown_reason_eligible_streaming_auto_str;
}

const ngx_str_t *
ngx_http_markdown_reason_eligible_fullbuffer_auto(void)
{
    return &ngx_http_markdown_reason_eligible_fullbuffer_auto_str;
}

#endif /* MARKDOWN_STREAMING_ENABLED */
