/*
 * NGINX Markdown Filter Module - Authentication Detection and Cache Control
 *
 * This file implements authentication detection and cache control modifications
 * for authenticated content to ensure secure caching behavior.
 *
 * Requirements: FR-08.1, FR-08.2, FR-08.3, FR-08.5, FR-08.6
 * Task: 17.5 Implement authenticated content cache control
 *
 * Security Rationale:
 * 
 * Authenticated and personalized content must not be cached publicly to prevent
 * exposure of sensitive information. This module detects authenticated requests
 * through:
 * 1. Authorization header (HTTP Basic, Bearer tokens, etc.)
 * 2. Authentication cookies (session IDs, auth tokens)
 *
 * When authenticated content is converted to Markdown, the Cache-Control header
 * is modified to ensure private caching only:
 * - If no Cache-Control: Add "Cache-Control: private"
 * - If Cache-Control allows public caching: Upgrade to "private"
 * - If Cache-Control is "no-store" or "private, no-store": Preserve (never downgrade)
 *
 * This prevents:
 * - Public CDN caching of personalized content
 * - Shared cache exposure of authenticated data
 * - Cross-user information leakage
 */

#include "ngx_http_markdown_filter_module.h"

static u_char ngx_http_markdown_hdr_cache_control[] = "Cache-Control";
static u_char ngx_http_markdown_cc_private[] = "private";
static u_char ngx_http_markdown_cc_public[] = "public";
static u_char ngx_http_markdown_cc_no_store[] = "no-store";
static u_char ngx_http_markdown_cc_suffix_private[] = ", private";
static u_char ngx_http_markdown_cc_conservative[] = "private, no-store";

static ngx_str_t  ngx_http_markdown_no_store_directive =
    { sizeof(ngx_http_markdown_cc_no_store) - 1, ngx_http_markdown_cc_no_store };
static ngx_str_t  ngx_http_markdown_private_directive =
    { sizeof(ngx_http_markdown_cc_private) - 1, ngx_http_markdown_cc_private };
static ngx_str_t  ngx_http_markdown_public_directive =
    { sizeof(ngx_http_markdown_cc_public) - 1, ngx_http_markdown_cc_public };

typedef struct {
    ngx_table_elt_t  *first_entry;
    ngx_flag_t        has_no_store;
    ngx_flag_t        has_private;
    ngx_flag_t        any_public;
    ngx_flag_t        malformed;
} ngx_http_markdown_cc_scan_t;

typedef struct {
    const u_char  *raw_start;
    const u_char  *raw_end;
    const u_char  *name_start;
    const u_char  *name_end;
    ngx_flag_t     has_value;
} ngx_http_markdown_cc_directive_t;

static ngx_int_t ngx_http_markdown_cookie_matches_pattern(
    const ngx_str_t *cookie_name,
    const ngx_str_t *pattern);
static ngx_flag_t ngx_http_markdown_is_cache_control_token_char(u_char ch);
static void ngx_http_markdown_skip_cache_control_ows(
    const u_char **cursor, const u_char *end);
static ngx_int_t ngx_http_markdown_parse_cache_control_quoted_value(
    const u_char **cursor, const u_char *end);
static ngx_int_t ngx_http_markdown_parse_cache_control_token_value(
    const u_char **cursor, const u_char *end);
static void ngx_http_markdown_skip_cache_control_separators(
    const u_char **cursor, const u_char *end);
static void ngx_http_markdown_trim_cache_control_token(
    const u_char **token_start, const u_char **token_end);
static ngx_int_t ngx_http_markdown_next_cache_control_directive(
    const u_char **cursor, const u_char *end,
    ngx_http_markdown_cc_directive_t *directive);
static ngx_int_t ngx_http_markdown_next_cache_control_token(
    const u_char **cursor, const u_char *end,
    const u_char **token_start, const u_char **token_end);
static ngx_flag_t ngx_http_markdown_cache_control_token_is_public(
    const u_char *token_start, const u_char *token_end);
static ngx_flag_t ngx_http_markdown_token_equals_ignore_case(
    const u_char *left, const u_char *right, size_t len);
static ngx_flag_t ngx_http_markdown_is_cache_control_header(
    const ngx_table_elt_t *header);
static void ngx_http_markdown_scan_cache_control_headers(
    ngx_list_t *headers, ngx_http_markdown_cc_scan_t *scan);
static ngx_int_t ngx_http_markdown_rewrite_public_entries(
    ngx_http_request_t *r, ngx_list_t *headers);
static ngx_int_t ngx_http_markdown_ensure_private_on_entry(
    ngx_http_request_t *r, ngx_table_elt_t *entry);
static ngx_int_t ngx_http_markdown_replace_malformed_cache_control(
    ngx_http_request_t *r, ngx_list_t *headers,
    ngx_table_elt_t *first_entry);

/*
 * Insert a new "Cache-Control: private" header when none exists.
 *
 * Allocates a new header entry in the response's outgoing headers list
 * and sets it to "Cache-Control: private".
 *
 * Parameters:
 *   r - the HTTP request to modify
 *
 * Returns:
 *   NGX_OK    - header added successfully
 *   NGX_ERROR - allocation failed
 */
static ngx_int_t
ngx_http_markdown_add_private_cache_control_header(ngx_http_request_t *r)
{
    ngx_table_elt_t  *h;

    h = ngx_list_push(&r->headers_out.headers);
    if (h == NULL) {
        return NGX_ERROR;
    }

    h->hash = 1;
    h->key.data = ngx_http_markdown_hdr_cache_control;
    h->key.len = sizeof(ngx_http_markdown_hdr_cache_control) - 1;
    h->value.data = ngx_http_markdown_cc_private;
    h->value.len = sizeof(ngx_http_markdown_cc_private) - 1;

    ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0,
                  "markdown: added Cache-Control: private for authenticated content");

    return NGX_OK;
}

/*
 * Append ", private" to an existing Cache-Control header value.
 *
 * Allocates a new buffer in the request pool, copies the existing value
 * plus the ", private" suffix, and updates the header's value pointer
 * and length. The old value is not freed (it remains in the pool).
 *
 * Parameters:
 *   r             - the HTTP request (pool used for allocation)
 *   cache_control - the Cache-Control header entry to modify
 *
 * Returns:
 *   NGX_OK    - directive appended successfully
 *   NGX_ERROR - allocation failed or length overflow
 */
static ngx_int_t
ngx_http_markdown_append_private_directive(ngx_http_request_t *r,
                                           ngx_table_elt_t *cache_control)
{
    u_char  *new_value;
    size_t   new_len;

    if (cache_control->value.len == 0) {
        cache_control->value.data = ngx_http_markdown_cc_private;
        cache_control->value.len = sizeof(ngx_http_markdown_cc_private) - 1;
        return NGX_OK;
    }

    if (cache_control->value.len > ((size_t) -1) - (sizeof(ngx_http_markdown_cc_suffix_private) - 1)) {
        return NGX_ERROR;
    }

    new_len = cache_control->value.len + sizeof(ngx_http_markdown_cc_suffix_private) - 1;
    new_value = ngx_pnalloc(r->pool, new_len);
    if (new_value == NULL) {
        return NGX_ERROR;
    }

    ngx_memcpy(new_value, cache_control->value.data, cache_control->value.len);
    ngx_memcpy(new_value + cache_control->value.len,
               ngx_http_markdown_cc_suffix_private,
               sizeof(ngx_http_markdown_cc_suffix_private) - 1);

    cache_control->value.data = new_value;
    cache_control->value.len = new_len;

    ngx_log_debug1(NGX_LOG_DEBUG_HTTP, r->connection->log, 0,
                  "markdown: added private to Cache-Control: \"%V\"",
                  &cache_control->value);

    return NGX_OK;
}

/*
 * Remove "public" token from Cache-Control and append "private".
 *
 * Rebuilds the Cache-Control value by tokenizing it, skipping any
 * "public" token, copying all other tokens, and appending "private".
 * Allocates a new buffer up to 2x original length + suffix length.
 *
 * Parameters:
 *   r             - the HTTP request (pool used for allocation, logging)
 *   cache_control - the Cache-Control header entry to modify
 *
 * Returns:
 *   NGX_OK    - Cache-Control rebuilt successfully
 *   NGX_ERROR - allocation failed
 */
static ngx_int_t
ngx_http_markdown_strip_public_and_append_private(ngx_http_request_t *r,
                                                  ngx_table_elt_t *cache_control)
{
    u_char         *new_value;
    size_t          new_len;
    const u_char   *p;
    const u_char   *end;
    const u_char   *token_start = NULL;
    const u_char   *token_end = NULL;
    u_char         *dst;
    ngx_flag_t      wrote_token;
    ngx_int_t       rc;

    if (cache_control->value.len > (((size_t) -1) - (sizeof(ngx_http_markdown_cc_suffix_private) - 1)) / 2) {
        return NGX_ERROR;
    }

    new_len = (cache_control->value.len * 2) + (sizeof(ngx_http_markdown_cc_suffix_private) - 1);
    new_value = ngx_pnalloc(r->pool, new_len);
    if (new_value == NULL) {
        return NGX_ERROR;
    }

    p = (const u_char *) cache_control->value.data;
    end = p + cache_control->value.len;
    dst = new_value;
    wrote_token = 0;

    for (/* void */; /* void */; /* void */) {
        rc = ngx_http_markdown_next_cache_control_token(
            &p, end, &token_start, &token_end);
        if (rc == NGX_DECLINED) {
            break;
        }
        if (rc == NGX_ERROR) {
            return NGX_ERROR;
        }

        if (ngx_http_markdown_cache_control_token_is_public(
                token_start, token_end))
        {
            continue;
        }

        if (token_end <= token_start) {
            continue;
        }

        if (wrote_token) {
            *dst++ = ',';
            *dst++ = ' ';
        }
        dst = ngx_cpymem(dst, token_start,
                         (size_t) (token_end - token_start));
        wrote_token = 1;
    }

    if (wrote_token) {
        *dst++ = ',';
        *dst++ = ' ';
    }
    dst = ngx_cpymem(dst,
                     ngx_http_markdown_cc_private,
                     sizeof(ngx_http_markdown_cc_private) - 1);

    cache_control->value.data = new_value;
    cache_control->value.len = (size_t) (dst - new_value);

    ngx_log_debug1(NGX_LOG_DEBUG_HTTP, r->connection->log, 0,
                  "markdown: upgraded Cache-Control from public to private: \"%V\"",
                  &cache_control->value);

    return NGX_OK;
}

/*
 * Test whether a byte is valid in an HTTP token.
 *
 * Cache-Control directive names and unquoted values use the RFC HTTP token
 * grammar. Rejecting separators and non-ASCII bytes keeps malformed input
 * out of the policy decision instead of interpreting a convenient prefix.
 */
static ngx_flag_t
ngx_http_markdown_is_cache_control_token_char(u_char ch)
{
    static u_char  token_punctuation[] = "!#$%&'*+-.^_`|~";

    if ((ch >= '0' && ch <= '9')
        || (ch >= 'A' && ch <= 'Z')
        || (ch >= 'a' && ch <= 'z'))
    {
        return 1;
    }

    for (size_t i = 0; i < sizeof(token_punctuation) - 1; i++) {
        if (ch == token_punctuation[i]) {
            return 1;
        }
    }

    return 0;
}

/* Advance a bounded cursor past Cache-Control optional whitespace. */
static void
ngx_http_markdown_skip_cache_control_ows(const u_char **cursor,
                                         const u_char *end)
{
    while (*cursor < end && (**cursor == ' ' || **cursor == '\t')) {
        (*cursor)++;
    }
}

/*
 * Parse one quoted-string value, including RFC quoted-pair escapes.
 */
static ngx_int_t
ngx_http_markdown_parse_cache_control_quoted_value(
    const u_char **cursor, const u_char *end)
{
    const u_char  *p;
    u_char         ch;

    p = *cursor;
    if (p >= end || *p != '"') {
        return NGX_ERROR;
    }

    p++;
    while (p < end) {
        ch = *p++;
        if (ch == '"') {
            *cursor = p;
            return NGX_OK;
        }
        if (ch == '\\') {
            if (p >= end) {
                return NGX_ERROR;
            }
            ch = *p++;
        }
        if (ch != '\t' && (ch < 0x20 || ch == 0x7f)) {
            return NGX_ERROR;
        }
    }

    return NGX_ERROR;
}

/* Parse one non-empty unquoted HTTP token value. */
static ngx_int_t
ngx_http_markdown_parse_cache_control_token_value(
    const u_char **cursor, const u_char *end)
{
    const u_char  *start;

    start = *cursor;
    while (*cursor < end
           && ngx_http_markdown_is_cache_control_token_char(**cursor))
    {
        (*cursor)++;
    }

    return (*cursor == start) ? NGX_ERROR : NGX_OK;
}

/*
 * Skip Cache-Control separator characters (space, tab, comma).
 *
 * Advances *cursor past any whitespace or comma characters in the
 * Cache-Control header value, stopping at the first non-separator
 * byte or when *cursor reaches end.
 *
 * Parameters:
 *   cursor - pointer to current parse position; advanced in-place
 *   end    - pointer one past the last byte of the header value
 */
static void
ngx_http_markdown_skip_cache_control_separators(const u_char **cursor,
                                                const u_char *end)
{
    while (*cursor < end
           && (**cursor == ' ' || **cursor == '\t' || **cursor == ','))
    {
        (*cursor)++;
    }
}

/*
 * Trim leading and trailing whitespace from a Cache-Control token.
 *
 * Adjusts *token_start forward past leading spaces/tabs and
 * *token_end backward past trailing spaces/tabs, so that
 * [*token_start, *token_end) contains the trimmed token.
 *
 * Parameters:
 *   token_start - pointer to start of token; advanced in-place
 *   token_end   - pointer to end of token; retreated in-place
 */
static void
ngx_http_markdown_trim_cache_control_token(const u_char **token_start,
                                           const u_char **token_end)
{
    while (*token_start < *token_end
           && (**token_start == ' ' || **token_start == '\t'))
    {
        (*token_start)++;
    }

    while (*token_end > *token_start
           && ((*(*token_end - 1) == ' ')
               || (*(*token_end - 1) == '\t')))
    {
        (*token_end)--;
    }
}

/*
 * Parse one Cache-Control directive without splitting quoted values.
 *
 * The parser validates the directive name and optional token/quoted-string
 * value. Commas inside a quoted value are data, not list delimiters.
 * Backslash-escaped quoted bytes are consumed as one unit. Malformed input
 * returns NGX_ERROR so authenticated responses can fail closed.
 *
 * Parameters:
 *   cursor    - pointer to current parse position; advanced in-place
 *   end       - pointer one past the last byte of the header value
 *   directive - parsed raw/name bounds and value-presence flag
 *
 * Returns:
 *   NGX_OK       - a complete directive was parsed
 *   NGX_DECLINED - no more tokens (cursor reached end)
 *   NGX_ERROR    - malformed directive syntax
 */
static ngx_int_t
ngx_http_markdown_next_cache_control_directive(
    const u_char **cursor, const u_char *end,
    ngx_http_markdown_cc_directive_t *directive)
{
    const u_char  *p;
    ngx_int_t       rc;

    if (cursor == NULL || *cursor == NULL || end == NULL
        || directive == NULL || *cursor > end)
    {
        return NGX_ERROR;
    }

    ngx_http_markdown_skip_cache_control_separators(cursor, end);
    if (*cursor >= end) {
        return NGX_DECLINED;
    }

    p = *cursor;
    directive->raw_start = p;
    directive->name_start = p;
    directive->has_value = 0;

    while (p < end && ngx_http_markdown_is_cache_control_token_char(*p)) {
        p++;
    }
    if (p == directive->name_start) {
        return NGX_ERROR;
    }
    directive->name_end = p;

    ngx_http_markdown_skip_cache_control_ows(&p, end);

    if (p < end && *p == '=') {
        directive->has_value = 1;
        p++;
        ngx_http_markdown_skip_cache_control_ows(&p, end);
        if (p >= end) {
            return NGX_ERROR;
        }

        if (*p == '"') {
            rc = ngx_http_markdown_parse_cache_control_quoted_value(
                &p, end);
        } else {
            rc = ngx_http_markdown_parse_cache_control_token_value(
                &p, end);
        }
        if (rc != NGX_OK) {
            return rc;
        }

        ngx_http_markdown_skip_cache_control_ows(&p, end);
    }

    if (p < end && *p != ',') {
        return NGX_ERROR;
    }

    directive->raw_end = p;
    ngx_http_markdown_trim_cache_control_token(
        &directive->raw_start, &directive->raw_end);

    if (p < end) {
        p++;
    }
    *cursor = p;

    return NGX_OK;
}

/*
 * Compatibility wrapper returning the complete raw directive bounds.
 *
 * Existing rewrite code and focused tests use this interface. The bounds now
 * come from the quote-aware parser above, so callers cannot split a quoted
 * field-name list at an internal comma.
 */
static ngx_int_t
ngx_http_markdown_next_cache_control_token(const u_char **cursor,
                                           const u_char *end,
                                           const u_char **token_start,
                                           const u_char **token_end)
{
    ngx_http_markdown_cc_directive_t  directive;
    ngx_int_t                         rc;

    rc = ngx_http_markdown_next_cache_control_directive(
        cursor, end, &directive);
    if (rc != NGX_OK) {
        return rc;
    }

    *token_start = directive.raw_start;
    *token_end = directive.raw_end;
    return NGX_OK;
}

/*
 * Case-insensitive byte comparison of two memory regions.
 *
 * Compares len bytes from left and right after lowercasing each byte
 * via ngx_tolower. Both regions must contain at least len bytes.
 *
 * Parameters:
 *   left  - start of first memory region
 *   right - start of second memory region
 *   len   - number of bytes to compare
 *
 * Returns:
 *   1 - regions are equal (case-insensitive)
 *   0 - regions differ
 */
static ngx_flag_t
ngx_http_markdown_token_equals_ignore_case(const u_char *left,
                                           const u_char *right,
                                           size_t len)
{
    for (size_t i = 0; i < len; i++) {
        if (ngx_tolower(left[i]) != ngx_tolower(right[i])) {
            return 0;
        }
    }

    return 1;
}

/*
 * Check whether a Cache-Control token equals "public" (case-insensitive).
 *
 * Compares the token bounded by [token_start, token_end) against the
 * literal string "public" using case-insensitive comparison.
 *
 * Parameters:
 *   token_start - start of the token to compare
 *   token_end   - end of the token to compare
 *
 * Returns:
 *   1 - token equals "public"
 *   0 - token does not equal "public"
 */
static ngx_flag_t
ngx_http_markdown_cache_control_token_is_public(const u_char *token_start,
                                                const u_char *token_end)
{
    if ((size_t) (token_end - token_start)
        != sizeof(ngx_http_markdown_cc_public) - 1)
    {
        return 0;
    }

    return ngx_http_markdown_token_equals_ignore_case(
        token_start, ngx_http_markdown_cc_public,
        sizeof(ngx_http_markdown_cc_public) - 1);
}

/*
 * Return configured auth-cookie patterns, falling back to built-in defaults.
 *
 * If the module configuration provides custom auth_cookies patterns, those
 * are returned. Otherwise, the built-in default patterns are used:
 * "session*", "auth*", "PHPSESSID", "wordpress_logged_in_*".
 *
 * Parameters:
 *   conf          - module configuration (may be NULL)
 *   patterns      - set to point to the patterns array
 *   pattern_count - set to the number of patterns
 */
static void
ngx_http_markdown_get_auth_patterns(const ngx_http_markdown_conf_t *conf,
                                    ngx_str_t **patterns,
                                    ngx_uint_t *pattern_count)
{
    static ngx_str_t default_patterns[] = {
        ngx_string("session*"),
        ngx_string("auth*"),
        ngx_string("PHPSESSID"),
        ngx_string("wordpress_logged_in_*"),
        ngx_null_string
    };

    if (conf != NULL && conf->policy.auth_cookies != NULL && conf->policy.auth_cookies->nelts > 0) {
        *patterns = conf->policy.auth_cookies->elts;
        *pattern_count = conf->policy.auth_cookies->nelts;
        return;
    }

    *patterns = default_patterns;
    *pattern_count = (sizeof(default_patterns)
                      / sizeof(default_patterns[0])) - 1;
}

/*
 * Advance cursor past optional whitespace in a Cookie header value.
 *
 * Parameters:
 *   cursor - pointer to current parse position; advanced in-place
 *   end    - pointer one past the last byte of the Cookie header value
 */
static void
ngx_http_markdown_skip_cookie_whitespace(u_char **cursor, const u_char *end)
{
    while (*cursor < end && (**cursor == ' ' || **cursor == '\t')) {
        (*cursor)++;
    }
}

/*
 * Skip past the cookie value and its trailing semicolon delimiter.
 *
 * Advances *cursor past all bytes until a semicolon is found (or end
 * of input), then advances past the semicolon itself if present.
 *
 * Parameters:
 *   cursor - pointer to current parse position; advanced in-place
 *   end    - pointer one past the last byte of the Cookie header value
 */
static void
ngx_http_markdown_skip_cookie_value(u_char **cursor, const u_char *end)
{
    while (*cursor < end && **cursor != ';') {
        (*cursor)++;
    }
    if (*cursor < end && **cursor == ';') {
        (*cursor)++;
    }
}

/*
 * Extract the next cookie name from the cursor position, trimming whitespace.
 *
 * Skips leading whitespace, reads the cookie name (up to '=' or ';'),
 * trims whitespace from the name, then skips the cookie value and
 * delimiter. The cursor is left positioned at the start of the next
 * cookie (or at end).
 *
 * Parameters:
 *   cursor       - pointer to current parse position; advanced in-place
 *   end          - pointer one past the last byte of the Cookie header value
 *   cookie_name  - set to the trimmed cookie name on success
 *
 * Returns:
 *   NGX_OK       - cookie name extracted successfully
 *   NGX_DECLINED - no more cookies (cursor reached end)
 */
static ngx_int_t
ngx_http_markdown_read_cookie_name(u_char **cursor, const u_char *end,
                                   ngx_str_t *cookie_name)
{
    u_char  *name_start;
    const u_char  *name_end;

    ngx_http_markdown_skip_cookie_whitespace(cursor, end);
    if (*cursor >= end) {
        return NGX_DECLINED;
    }

    name_start = *cursor;
    while (*cursor < end && **cursor != '=' && **cursor != ';') {
        (*cursor)++;
    }
    name_end = *cursor;

    while (name_start < name_end && (*name_start == ' ' || *name_start == '\t')) {
        name_start++;
    }
    while (name_end > name_start && (*(name_end - 1) == ' ' || *(name_end - 1) == '\t')) {
        name_end--;
    }

    cookie_name->data = name_start;
    cookie_name->len = (size_t) (name_end - name_start);

    ngx_http_markdown_skip_cookie_value(cursor, end);
    return NGX_OK;
}

/*
 * Test a cookie name against all configured auth patterns, returning the first match.
 *
 * Iterates all auth-cookie patterns and checks if cookie_name matches
 * any of them via ngx_http_markdown_cookie_matches_pattern. Returns
 * on the first match, optionally setting matched_pattern to the
 * matching pattern for diagnostics.
 *
 * Parameters:
 *   cookie_name     - the cookie name to test
 *   patterns        - array of auth-cookie patterns
 *   pattern_count   - number of patterns in the array
 *   matched_pattern - if non-NULL, set to the matching pattern on match
 *
 * Returns:
 *   1 - cookie name matches at least one pattern
 *   0 - cookie name matches no patterns
 */
static ngx_int_t
ngx_http_markdown_cookie_matches_any_pattern(const ngx_str_t *cookie_name,
                                             ngx_str_t *patterns,
                                             ngx_uint_t pattern_count,
                                             ngx_str_t **matched_pattern)
{
    for (ngx_uint_t j = 0; j < pattern_count; j++) {
        if (ngx_http_markdown_cookie_matches_pattern(cookie_name, &patterns[j])) {
            if (matched_pattern != NULL) {
                *matched_pattern = &patterns[j];
            }
            return 1;
        }
    }

    return 0;
}

/*
 * Check if request has Authorization header
 *
 * Detects HTTP authentication via Authorization header (Basic, Bearer, etc.).
 * The presence of this header indicates the request is authenticated.
 *
 * Requirements: FR-08.1
 *
 * @param r  The request structure
 * @return   1 if Authorization header present, 0 otherwise
 */
static ngx_int_t
ngx_http_markdown_has_authorization_header(const ngx_http_request_t *r)
{
    if (r == NULL || r->headers_in.authorization == NULL
        || r->headers_in.authorization->hash == 0)
    {
        return 0;
    }

    ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0,
                  "markdown: detected Authorization header");

    return 1;
}

/*
 * Check if cookie name matches a pattern
 *
 * Supports three matching modes:
 * 1. Exact match: "session" matches "session" only
 * 2. Prefix match with wildcard: "session*" matches "session", "session_id", etc.
 * 3. Suffix match with wildcard: "*_logged_in" matches "wordpress_logged_in", etc.
 *
 * @param cookie_name  The cookie name to check
 * @param pattern      The pattern to match against
 * @return             1 if matches, 0 otherwise
 */
static ngx_int_t
ngx_http_markdown_cookie_matches_pattern(const ngx_str_t *cookie_name,
    const ngx_str_t *pattern)
{
    size_t         pattern_len;
    size_t         cookie_len;
    const u_char  *pattern_data;
    const u_char  *cookie_data;

    if (cookie_name == NULL || pattern == NULL ||
        cookie_name->len == 0 || pattern->len == 0)
    {
        return 0;
    }

    pattern_data = pattern->data;
    pattern_len = pattern->len;
    cookie_data = cookie_name->data;
    cookie_len = cookie_name->len;

    /* Check for wildcard patterns */
    if (pattern_data[pattern_len - 1] == '*') {
        size_t prefix_len;

        prefix_len = pattern_len - 1;
        if (cookie_len < prefix_len) {
            return 0;
        }

        return ngx_strncmp(cookie_data, pattern_data, prefix_len) == 0;
    }

    if (pattern_data[0] == '*') {
        size_t suffix_len;

        suffix_len = pattern_len - 1;
        if (cookie_len < suffix_len) {
            return 0;
        }

        return ngx_strncmp(cookie_data + (cookie_len - suffix_len),
                           pattern_data + 1, suffix_len) == 0;
    }

    if (cookie_len != pattern_len) {
        return 0;
    }

    return ngx_strncmp(cookie_data, pattern_data, pattern_len) == 0;
}

/*
 * Check if request has authentication cookies
 *
 * Parses the Cookie header and checks if any cookie names match the
 * configured authentication cookie patterns.
 *
 * Default patterns (if none configured):
 * - session*
 * - auth*
 * - PHPSESSID
 * - wordpress_logged_in_*
 *
 * Requirements: FR-08.2, FR-08.5
 *
 * @param r     The request structure
 * @param conf  Module configuration with auth_cookies patterns
 * @return      1 if authentication cookie found, 0 otherwise
 */
static ngx_int_t
ngx_http_markdown_has_auth_cookies(const ngx_http_request_t *r,
                                   const ngx_http_markdown_conf_t *conf)
{
    ngx_table_elt_t  *cookie_header;
    ngx_str_t        *patterns;
    ngx_uint_t        pattern_count;
    ngx_str_t        *matched_pattern;
    ngx_str_t         cookie_name;

    if (r == NULL) {
        return 0;
    }

    /* Get Cookie header chain (NGINX may link multiple Cookie headers via ->next) */
    cookie_header = r->headers_in.cookie;
    if (cookie_header == NULL) {
        return 0;
    }

    ngx_http_markdown_get_auth_patterns(conf, &patterns, &pattern_count);

    for (; cookie_header != NULL; cookie_header = cookie_header->next) {
        u_char        *p;
        const u_char  *end;

        p = cookie_header->value.data;
        end = p + cookie_header->value.len;

        while (p < end) {
            if (ngx_http_markdown_read_cookie_name(&p, end, &cookie_name) != NGX_OK) {
                continue;
            }

            if (cookie_name.len == 0) {
                continue;
            }

            if (ngx_http_markdown_cookie_matches_any_pattern(&cookie_name,
                                                             patterns,
                                                             pattern_count,
                                                             &matched_pattern))
            {
                ngx_log_debug2(NGX_LOG_DEBUG_HTTP, r->connection->log, 0,
                              "markdown: detected auth cookie \"%V\" "
                              "matching pattern \"%V\"",
                              &cookie_name, matched_pattern);
                return 1;
            }
        }
    }

    return 0;
}

/*
 * Check if request is authenticated
 *
 * A request is considered authenticated if it has:
 * 1. Authorization header, OR
 * 2. Authentication cookies matching configured patterns
 *
 * Requirements: FR-08.1, FR-08.2
 *
 * @param r     The request structure
 * @param conf  Module configuration
 * @return      1 if authenticated, 0 otherwise
 */
ngx_int_t
ngx_http_markdown_is_authenticated(const ngx_http_request_t *r,
                                   const ngx_http_markdown_conf_t *conf)
{
    if (r == NULL) {
        return 0;
    }

    /* Check Authorization header */
    if (ngx_http_markdown_has_authorization_header(r)) {
        return 1;
    }

    /* Check authentication cookies */
    if (ngx_http_markdown_has_auth_cookies(r, conf)) {
        return 1;
    }

    return 0;
}

/*
 * Parse Cache-Control header value
 *
 * Checks if Cache-Control header contains specific directives.
 *
 * @param value      Cache-Control header value
 * @param directive  Directive to search for (e.g., "public", "private", "no-store")
 * @return           1 if directive found, 0 otherwise
 */
static ngx_int_t
ngx_http_markdown_cache_control_has_directive(const ngx_str_t *value,
    const ngx_str_t *directive)
{
    const u_char                       *p;
    const u_char                       *end;
    const u_char                       *name_start;
    const u_char                       *name_end;
    ngx_http_markdown_cc_directive_t    parsed;
    ngx_int_t                           rc;

    if (value == NULL || value->len == 0 || value->data == NULL
        || directive == NULL || directive->len == 0
        || directive->data == NULL)
    {
        return 0;
    }

    p = value->data;
    end = p + value->len;

    for (/* void */; /* void */; /* void */) {
        rc = ngx_http_markdown_next_cache_control_directive(
            &p, end, &parsed);
        if (rc != NGX_OK) {
            return 0;
        }

        if (parsed.name_start == NULL || parsed.name_end == NULL
            || parsed.name_end < parsed.name_start)
        {
            return 0;
        }

        name_start = parsed.name_start;
        name_end = parsed.name_end;
        /* CWE-190:guarded */
        if (!parsed.has_value
            && (size_t) (name_end - name_start)
               == directive->len
            && ngx_http_markdown_token_equals_ignore_case(
                   name_start, directive->data, directive->len))
        {
            return 1;
        }
    }
}

/*
 * Test whether a header entry is a Cache-Control header.
 *
 * Compares key length and data against the canonical Cache-Control
 * header name using case-insensitive comparison.
 *
 * Parameters:
 *   header - the header entry to test
 *
 * Returns:
 *   1 - header is Cache-Control
 *   0 - header is not Cache-Control
 */
static ngx_flag_t
ngx_http_markdown_is_cache_control_header(const ngx_table_elt_t *header)
{
    if (header->hash == 0
        || header->key.len != sizeof(ngx_http_markdown_hdr_cache_control) - 1)
    {
        return 0;
    }

    return ngx_strncasecmp(header->key.data,
                           ngx_http_markdown_hdr_cache_control,
                           sizeof(ngx_http_markdown_hdr_cache_control) - 1) == 0;
}

/*
 * Callback signature for ngx_http_markdown_for_each_cache_control_header.
 *
 * Called once per Cache-Control entry found while walking the NGINX
 * header list.  The opaque `ctx` pointer is forwarded unchanged from
 * the iterator call site.  Returning NGX_OK continues iteration;
 * returning any other value stops iteration and is returned to the
 * caller as the iterator result.
 */
typedef ngx_int_t (*ngx_http_markdown_cc_visitor_t)(
    ngx_http_request_t *r, ngx_table_elt_t *entry, void *ctx);


/*
 * Walk every Cache-Control entry in `headers` and invoke `visitor`
 * for each one.
 *
 * Centralizes the ngx_list_part_t chain walk (Rule 28) + the
 * is_cache_control_header() filter so the scan and rewrite paths
 * cannot drift apart on traversal semantics.
 *
 * Parameters:
 *   r       - HTTP request (forwarded to the visitor)
 *   headers - the outgoing headers list to walk
 *   visitor - per-entry callback
 *   ctx     - opaque pointer forwarded to the visitor
 *
 * Returns:
 *   NGX_OK if every visitor returned NGX_OK, otherwise the first
 *   non-NGX_OK value returned by the visitor (iteration stops on the
 *   first non-OK return).
 */
static ngx_int_t
ngx_http_markdown_for_each_cache_control_header(ngx_http_request_t *r,
    ngx_list_t *headers, ngx_http_markdown_cc_visitor_t visitor, void *ctx)
{
    ngx_list_part_t  *part;
    ngx_table_elt_t  *elts;
    ngx_int_t         rc;

    part = &headers->part;
    for (/* void */; part != NULL; part = part->next) {
        elts = part->elts;
        for (size_t i = 0; i < part->nelts; i++) {
            if (!ngx_http_markdown_is_cache_control_header(&elts[i])) {
                continue;
            }

            rc = visitor(r, &elts[i], ctx);
            if (rc != NGX_OK) {
                return rc;
            }
        }
    }

    return NGX_OK;
}


static ngx_uint_t
ngx_http_markdown_cc_directive_matches(
    const ngx_http_markdown_cc_directive_t *directive,
    const ngx_str_t *expected)
{
    return (size_t) (directive->name_end - directive->name_start)
           == expected->len
           && ngx_http_markdown_token_equals_ignore_case(
                  directive->name_start, expected->data, expected->len);
}


static void
ngx_http_markdown_apply_cc_directive(ngx_http_markdown_cc_scan_t *scan,
    const ngx_http_markdown_cc_directive_t *directive)
{
    if (ngx_http_markdown_cc_directive_matches(
            directive, &ngx_http_markdown_no_store_directive))
    {
        if (directive->has_value) {
            scan->malformed = 1;
        } else {
            scan->has_no_store = 1;
        }
        return;
    }

    if (ngx_http_markdown_cc_directive_matches(
            directive, &ngx_http_markdown_private_directive))
    {
        if (!directive->has_value) {
            scan->has_private = 1;
        }
        return;
    }

    if (ngx_http_markdown_cc_directive_matches(
            directive, &ngx_http_markdown_public_directive))
    {
        if (directive->has_value) {
            scan->malformed = 1;
        } else {
            scan->any_public = 1;
        }
    }
}


/* Collect no-store / private / public directives from one header entry. */
static void
ngx_http_markdown_scan_cc_header(ngx_table_elt_t *entry,
    ngx_http_markdown_cc_scan_t *scan)
{
    const u_char                       *p;
    const u_char                       *end;
    ngx_http_markdown_cc_directive_t    directive;
    ngx_int_t                           rc;

    if (scan->first_entry == NULL) {
        scan->first_entry = entry;
    }

    if (entry->value.len == 0) {
        return;
    }
    if (entry->value.data == NULL) {
        scan->malformed = 1;
        return;
    }

    p = entry->value.data;
    end = p + entry->value.len;

    for (/* void */; /* void */; /* void */) {
        rc = ngx_http_markdown_next_cache_control_directive(
            &p, end, &directive);
        if (rc == NGX_DECLINED) {
            return;
        }
        if (rc == NGX_ERROR) {
            scan->malformed = 1;
            return;
        }
        ngx_http_markdown_apply_cc_directive(scan, &directive);
    }
}


/*
 * Scan all Cache-Control headers and collect directive flags.
 *
 * Iterates the NGINX header linked list, identifies Cache-Control
 * entries, and records whether any contain no-store, private, or
 * public directives.  Also saves a pointer to the first Cache-Control
 * entry found.
 *
 * Parameters:
 *   headers - the outgoing headers list to scan
 *   scan    - result struct populated with flags and first entry
 */
static void
ngx_http_markdown_scan_cache_control_headers(ngx_list_t *headers,
                                             ngx_http_markdown_cc_scan_t *scan)
{
    ngx_list_part_t  *part;
    ngx_table_elt_t  *elts;

    scan->first_entry = NULL;
    scan->has_no_store = 0;
    scan->has_private = 0;
    scan->any_public = 0;
    scan->malformed = 0;

    part = &headers->part;
    for (/* void */; part != NULL; part = part->next) {
        elts = part->elts;
        for (size_t i = 0; i < part->nelts; i++) {
            if (ngx_http_markdown_is_cache_control_header(&elts[i])) {
                ngx_http_markdown_scan_cc_header(&elts[i], scan);
            }
        }
    }
}

/*
 * Ensure a single Cache-Control entry has the private directive.
 *
 * If the entry contains "public", strips it and appends "private".
 * Otherwise, if it lacks "private", appends ", private".
 * Entries that already contain "private" are left unchanged.
 *
 * Parameters:
 *   r     - the HTTP request (pool used for allocation, logging)
 *   entry - the Cache-Control header entry to modify
 *
 * Returns:
 *   NGX_OK    - entry updated or already correct
 *   NGX_ERROR - allocation failed
 */
static ngx_int_t
ngx_http_markdown_ensure_private_on_entry(ngx_http_request_t *r,
                                          ngx_table_elt_t *entry)
{
    ngx_int_t  rc;

    if (ngx_http_markdown_cache_control_has_directive(
            &entry->value, &ngx_http_markdown_public_directive))
    {
        rc = ngx_http_markdown_strip_public_and_append_private(r, entry);
        return rc;
    }

    if (ngx_http_markdown_cache_control_has_directive(
            &entry->value, &ngx_http_markdown_private_directive))
    {
        return NGX_OK;
    }

    rc = ngx_http_markdown_append_private_directive(r, entry);
    return rc;
}

/*
 * Rewrite all Cache-Control entries that contain "public" to use "private".
 *
 * Iterates the NGINX header linked list.  For each Cache-Control entry
 * that contains "public", strips it and appends "private".  For entries
 * that lack both "public" and "private", appends ", private".
 *
 * Parameters:
 *   r       - the HTTP request (pool used for allocation, logging)
 *   headers - the outgoing headers list to rewrite
 *
 * Returns:
 *   NGX_OK    - all entries updated successfully
 *   NGX_ERROR - allocation failed on any entry
 */
/*
 * Trampoline that adapts the 2-arg ensure_private_on_entry to the
 * 3-arg ngx_http_markdown_cc_visitor_t signature (ctx is unused).
 */
static ngx_int_t
ngx_http_markdown_ensure_private_visitor(ngx_http_request_t *r,
    ngx_table_elt_t *entry, void *ctx)
{
    (void) ctx;
    return ngx_http_markdown_ensure_private_on_entry(r, entry);
}


/*
 * Rewrite all Cache-Control entries that contain "public" to use "private".
 *
 * Iterates the NGINX header linked list.  For each Cache-Control entry
 * that contains "public", strips it and appends "private".  For entries
 * that lack both "public" and "private", appends ", private".
 *
 * Parameters:
 *   r       - the HTTP request (pool used for allocation, logging)
 *   headers - the outgoing headers list to rewrite
 *
 * Returns:
 *   NGX_OK    - all entries updated successfully
 *   NGX_ERROR - allocation failed on any entry
 */
static ngx_int_t
ngx_http_markdown_rewrite_public_entries(ngx_http_request_t *r,
                                         ngx_list_t *headers)
{
    return ngx_http_markdown_for_each_cache_control_header(r, headers,
        ngx_http_markdown_ensure_private_visitor, NULL);
}

/*
 * Replace malformed Cache-Control state with one conservative policy.
 *
 * The validation pass completes before this function is called. Applying the
 * static value cannot fail, so the multi-header update is atomic with respect
 * to allocation failure: the first active entry becomes "private, no-store"
 * and later active Cache-Control entries are invalidated.
 */
static ngx_int_t
ngx_http_markdown_replace_malformed_cc_visitor(
    ngx_http_request_t *r, /* NOSONAR: r type dictated by ngx_http_markdown_cc_visitor_t callback typedef (Rule 24) */
    ngx_table_elt_t *entry, void *ctx)
{
    const ngx_table_elt_t  *first_entry;

    (void) r;
    first_entry = ctx;

    if (entry == first_entry) {
        entry->value.data = ngx_http_markdown_cc_conservative;
        entry->value.len =
            sizeof(ngx_http_markdown_cc_conservative) - 1;
        return NGX_OK;
    }

    entry->hash = 0;
    return NGX_OK;
}

/*
 * Fail closed when Cache-Control cannot be parsed unambiguously.
 */
static ngx_int_t
ngx_http_markdown_replace_malformed_cache_control(
    ngx_http_request_t *r, ngx_list_t *headers,
    ngx_table_elt_t *first_entry)
{
    ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0,
                  "markdown: replacing malformed Cache-Control "
                  "with private, no-store");

    return ngx_http_markdown_for_each_cache_control_header(
        r, headers, ngx_http_markdown_replace_malformed_cc_visitor,
        first_entry);
}

/*
 * Modify Cache-Control header for authenticated content
 *
 * Applies the following rules to ensure secure caching:
 * 1. If no Cache-Control: Add "Cache-Control: private"
 * 2. If Cache-Control allows public caching: Upgrade to "private"
 * 3. If Cache-Control is "no-store" or "private, no-store": Preserve as-is
 *
 * CRITICAL: Never downgrade "no-store" to "private" - this would weaken
 * security by allowing caching of content that should not be cached at all.
 *
 * Requirements: FR-08.3
 *
 * @param r  The request structure
 * @return   NGX_OK on success, NGX_ERROR on failure
 */
ngx_int_t
ngx_http_markdown_modify_cache_control_for_auth(ngx_http_request_t *r)
{
    ngx_http_markdown_cc_scan_t  scan;

    if (r == NULL) {
        return NGX_ERROR;
    }

    if (r->headers_out.headers.part.nelts == 0) {
        return ngx_http_markdown_add_private_cache_control_header(r);
    }

    ngx_http_markdown_scan_cache_control_headers(
        &r->headers_out.headers, &scan);

    if (scan.first_entry == NULL) {
        return ngx_http_markdown_add_private_cache_control_header(r);
    }

    if (scan.malformed) {
        return ngx_http_markdown_replace_malformed_cache_control(
            r, &r->headers_out.headers, scan.first_entry);
    }

    /*
     * If any Cache-Control header contains "public", strip public from
     * ALL such entries and append private.  This covers:
     *   - First header has "public"
     *   - First header has "private" but a later header has "public"
     *   - Multiple headers each have "public"
     * In all cases, each entry with public is rewritten.
     */
    if (scan.any_public) {
        if (scan.has_no_store) {
            ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0,
                          "markdown: normalizing public Cache-Control "
                          "while preserving no-store");
        }
        return ngx_http_markdown_rewrite_public_entries(
                   r, &r->headers_out.headers);
    }

    /*
     * Rule 3: Preserve "no-store" - NEVER downgrade.
     * If any Cache-Control header contains "no-store" and none contains
     * "public", leave all unchanged.
     */
    if (scan.has_no_store) {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0,
                      "markdown: preserving Cache-Control with no-store");
        return NGX_OK;
    }

    if (scan.has_private) {
        ngx_log_debug1(NGX_LOG_DEBUG_HTTP, r->connection->log, 0,
                      "markdown: Cache-Control already has private: \"%V\"",
                      &scan.first_entry->value);
        return NGX_OK;
    }

    return ngx_http_markdown_append_private_directive(r, scan.first_entry);
}
