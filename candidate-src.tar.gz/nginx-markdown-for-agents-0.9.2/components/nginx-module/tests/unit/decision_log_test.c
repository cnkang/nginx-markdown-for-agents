/*
 * Test: decision_log
 *
 * Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6
 *
 * NOTE: This test redefines its own copies of the module enums and
 * helper functions rather than including the real header.  This means
 * it cannot catch issues like typedef ordering or constant drift.
 * For compile-time verification that the real header types are
 * consistent, see header_compile_test.c.  For full integration
 * coverage, use the e2e and integration test suites.
 */

#include "../include/test_common.h"

/*
 * Minimal ngx_str_t definition matching NGINX's { len, data } layout.
 */

typedef unsigned char u_char;

typedef struct {
    size_t     len;
    u_char    *data;
} ngx_str_t;

#define ngx_string(str) { sizeof(str) - 1, (u_char *) str }
#define ngx_null_string { 0, NULL }
#define ngx_strncmp(s1, s2, n) strncmp((const char *) (s1), \
    (const char *) (s2), n)

/*
 * Module verbosity constants — mirrors the header definitions.
 */
#define NGX_HTTP_MARKDOWN_LOG_ERROR  0
#define NGX_HTTP_MARKDOWN_LOG_WARN   1
#define NGX_HTTP_MARKDOWN_LOG_INFO   2
#define NGX_HTTP_MARKDOWN_LOG_DEBUG  3

/*
 * NGINX log level constants (subset used by decision log).
 */
#define NGX_LOG_WARN   5
#define NGX_LOG_INFO   7

typedef int ngx_int_t;
typedef unsigned int ngx_uint_t;


/* Function prototypes */

static ngx_int_t is_failure_outcome(const ngx_str_t *reason_code);
static ngx_uint_t expected_log_level(const ngx_str_t *reason_code);
static ngx_int_t should_emit(ngx_uint_t verbosity,
    const ngx_str_t *reason_code);
static void test_failure_outcome_classification(void);
static void test_non_failure_outcome_classification(void);
static void test_log_level_selection(void);
static void test_verbosity_gating_info(void);
static void test_verbosity_gating_debug(void);
static void test_verbosity_gating_warn(void);
static void test_verbosity_gating_error(void);
static void test_null_inputs(void);
static void test_unknown_family_classification(void);


/*
 * Mirror of ngx_http_markdown_is_failure_outcome() from
 * ngx_http_markdown_decision_log_impl.h.
 *
 * Failure outcomes: reason codes starting with "ELIGIBLE_FAILED",
 * "FAIL_", "STREAMING_FAIL_", "STREAMING_PRECOMMIT_", or
 * "STREAMING_BUDGET_", or "STREAMING_FALLBACK_".
 */
static ngx_int_t
is_failure_outcome(const ngx_str_t *reason_code)
{
    if (reason_code == NULL || reason_code->len == 0) {
        return 0;
    }

    /* Schema v1 lowercase: "failed_" prefix (7 chars) */
    if (reason_code->len >= 7
        && ngx_strncmp(reason_code->data,
                       (u_char *) "failed_", 7) == 0)
    {
        return 1;
    }

    /*
     * Schema v1 lowercase error codes — use exact length matching to avoid
     * prefix false positives (e.g. a hypothetical "decompression_something"
     * that is not in the registry). The "failed_" prefix above is the only
     * exception because schema v1 may add new failed_* variants additively.
     */
    /* "decompression_error" etc. — exact match for each known code */
    if (reason_code->len == 19
        && ngx_strncmp(reason_code->data,
                       (u_char *) "decompression_error",
                       19) == 0)
    {
        return 1;
    }

    if (reason_code->len == 27
        && ngx_strncmp(reason_code->data,
                       (u_char *) "decompression_budget_exceeded",
                       27) == 0)
    {
        return 1;
    }

    if (reason_code->len == 25
        && ngx_strncmp(reason_code->data,
                       (u_char *) "decompression_format_error",
                       25) == 0)
    {
        return 1;
    }

    if (reason_code->len == 28
        && ngx_strncmp(reason_code->data,
                       (u_char *) "decompression_truncated_input",
                       28) == 0)
    {
        return 1;
    }

    if (reason_code->len == 23
        && ngx_strncmp(reason_code->data,
                       (u_char *) "decompression_io_error",
                       23) == 0)
    {
        return 1;
    }

    if (reason_code->len == 16
        && ngx_strncmp(reason_code->data,
                       (u_char *) "conversion_error", 16) == 0)
    {
        return 1;
    }

    if (reason_code->len == 22
        && ngx_strncmp(reason_code->data,
                       (u_char *) "memory_budget_exceeded",
                       22) == 0)
    {
        return 1;
    }

    if (reason_code->len == 9
        && ngx_strncmp(reason_code->data,
                       (u_char *) "ffi_panic", 9) == 0)
    {
        return 1;
    }

    if (reason_code->len == 7
        && ngx_strncmp(reason_code->data,
                       (u_char *) "timeout", 7) == 0)
    {
        return 1;
    }

    if (reason_code->len == 15
        && ngx_strncmp(reason_code->data,
                       (u_char *) "budget_exceeded", 15) == 0)
    {
        return 1;
    }

    if (reason_code->len == 12
        && ngx_strncmp(reason_code->data,
                       (u_char *) "replay_error", 12) == 0)
    {
        return 1;
    }

    if (reason_code->len == 8
        && ngx_strncmp(reason_code->data,
                       (u_char *) "overload", 8) == 0)
    {
        return 1;
    }

    if (reason_code->len == 15
        && ngx_strncmp(reason_code->data,
                       (u_char *) "invalid_dynconf", 15) == 0)
    {
        return 1;
    }

    if (reason_code->len == 17
        && ngx_strncmp(reason_code->data,
                       (u_char *) "degraded_snapshot", 17) == 0)
    {
        return 1;
    }

    if (reason_code->len == 23
        && ngx_strncmp(reason_code->data,
                       (u_char *) "header_plan_apply_error",
                       23) == 0)
    {
        return 1;
    }

    if (reason_code->len == 26
        && ngx_strncmp(reason_code->data,
                       (u_char *) "streaming_mid_flight_error",
                       26) == 0)
    {
        return 1;
    }

    /*
     * Legacy compatibility: "ELIGIBLE_FAILED" prefix (15 chars).
     * Legacy reason codes used uppercase prefixes; keep prefix semantics
     * for backward compatibility with pre-v1 decision logs.
     */
    if (reason_code->len >= 15
        && ngx_strncmp(reason_code->data,
                       (u_char *) "ELIGIBLE_FAILED", 15) == 0)
    {
        return 1;
    }

    /*
     * Legacy compatibility: "FAIL_" prefix (5 chars).
     * Keep prefix semantics for backward compatibility with pre-v1 logs.
     */
    if (reason_code->len >= 5
        && ngx_strncmp(reason_code->data,
                       (u_char *) "FAIL_", 5) == 0)
    {
        return 1;
    }

    /*
     * Streaming failure codes use the "STREAMING_" prefix
     * but not all STREAMING_* codes are failures.
     *
     * Failures:
     *   STREAMING_FAIL_POSTCOMMIT
     *   STREAMING_PRECOMMIT_FAILOPEN
     *   STREAMING_PRECOMMIT_REJECT
     *   STREAMING_BUDGET_EXCEEDED
     *   STREAMING_FALLBACK_PREBUFFER
     *
     * Non-failures (informational):
     *   STREAMING_CONVERT
     *   STREAMING_SHADOW
     *   STREAMING_SKIP_UNSUPPORTED
     */
    if (reason_code->len >= 10
        && ngx_strncmp(reason_code->data,
                       (u_char *) "STREAMING_", 10) == 0)
    {
        /* "STREAMING_FAIL_" (15 chars) */
        if (reason_code->len >= 15
            && ngx_strncmp(reason_code->data,
                           (u_char *) "STREAMING_FAIL_",
                           15) == 0)
        {
            return 1;
        }

        /* "STREAMING_PRECOMMIT_" (20 chars) */
        if (reason_code->len >= 20
            && ngx_strncmp(reason_code->data,
                           (u_char *) "STREAMING_PRECOMMIT_",
                           20) == 0)
        {
            return 1;
        }

        /* "STREAMING_BUDGET_" (17 chars) */
        if (reason_code->len >= 17
            && ngx_strncmp(reason_code->data,
                           (u_char *) "STREAMING_BUDGET_",
                           17) == 0)
        {
            return 1;
        }

        /* "STREAMING_FALLBACK_" (19 chars) */
        if (reason_code->len >= 19
            && ngx_strncmp(reason_code->data,
                           (u_char *) "STREAMING_FALLBACK_",
                           19) == 0)
        {
            return 1;
        }
    }

    return 0;
}


/*
 * Mirror of log level selection logic from
 * ngx_http_markdown_log_decision().
 *
 * NGX_LOG_WARN for failure outcomes, NGX_LOG_INFO otherwise.
 */
static ngx_uint_t
expected_log_level(const ngx_str_t *reason_code)
{
    return is_failure_outcome(reason_code) ? NGX_LOG_WARN
                                           : NGX_LOG_INFO;
}


/*
 * Mirror of verbosity gating logic from
 * ngx_http_markdown_log_decision().
 *
 * Returns:
 *   1 if a decision log entry should be emitted
 *   0 if suppressed by verbosity
 */
static ngx_int_t
should_emit(ngx_uint_t verbosity, const ngx_str_t *reason_code)
{
    if (verbosity <= NGX_HTTP_MARKDOWN_LOG_WARN
        && !is_failure_outcome(reason_code))
    {
        return 0;
    }

    return 1;
}


/* All 15 reason codes for iteration — schema v1 lowercase */

static ngx_str_t rc_skip_config = ngx_string("disabled");
static ngx_str_t rc_skip_method = ngx_string("not_eligible");
static ngx_str_t rc_skip_status = ngx_string("not_eligible");
static ngx_str_t rc_skip_content_type =
    ngx_string("not_eligible");
static ngx_str_t rc_skip_size = ngx_string("not_eligible");
static ngx_str_t rc_skip_streaming =
    ngx_string("not_eligible");
static ngx_str_t rc_skip_auth = ngx_string("not_eligible");
static ngx_str_t rc_skip_range = ngx_string("not_eligible");
static ngx_str_t rc_skip_accept = ngx_string("skipped_accept");
static ngx_str_t rc_converted =
    ngx_string("converted");
static ngx_str_t rc_failed_open =
    ngx_string("failed_open");
static ngx_str_t rc_failed_closed =
    ngx_string("failed_closed");
static ngx_str_t rc_fail_conversion =
    ngx_string("conversion_error");
static ngx_str_t rc_fail_resource =
    ngx_string("memory_budget_exceeded");
static ngx_str_t rc_fail_system = ngx_string("ffi_panic");

/* Streaming reason codes */
static ngx_str_t rc_engine_streaming =
    ngx_string("ENGINE_STREAMING");
static ngx_str_t rc_streaming_convert =
    ngx_string("STREAMING_CONVERT");
static ngx_str_t rc_streaming_shadow =
    ngx_string("STREAMING_SHADOW");
static ngx_str_t rc_streaming_fallback =
    ngx_string("STREAMING_FALLBACK_PREBUFFER");
static ngx_str_t rc_streaming_skip =
    ngx_string("STREAMING_SKIP_UNSUPPORTED");
static ngx_str_t rc_streaming_fail_postcommit =
    ngx_string("STREAMING_FAIL_POSTCOMMIT");
static ngx_str_t rc_streaming_precommit_failopen =
    ngx_string("STREAMING_PRECOMMIT_FAILOPEN");
static ngx_str_t rc_streaming_precommit_reject =
    ngx_string("STREAMING_PRECOMMIT_REJECT");
static ngx_str_t rc_streaming_budget_exceeded =
    ngx_string("STREAMING_BUDGET_EXCEEDED");


/*
 * Test: failure outcomes are correctly classified
 */
static void
test_failure_outcome_classification(void)
{
    TEST_SUBSECTION("Failure outcome classification");

    TEST_ASSERT(is_failure_outcome(&rc_failed_open) == 1,
                "ELIGIBLE_FAILED_OPEN is failure");
    TEST_ASSERT(is_failure_outcome(&rc_failed_closed) == 1,
                "ELIGIBLE_FAILED_CLOSED is failure");
    TEST_ASSERT(is_failure_outcome(&rc_fail_conversion) == 1,
                "FAIL_CONVERSION is failure");
    TEST_ASSERT(is_failure_outcome(&rc_fail_resource) == 1,
                "FAIL_RESOURCE_LIMIT is failure");
    TEST_ASSERT(is_failure_outcome(&rc_fail_system) == 1,
                "FAIL_SYSTEM is failure");

    /* Streaming failure codes */
    TEST_ASSERT(
        is_failure_outcome(&rc_streaming_fail_postcommit) == 1,
        "STREAMING_FAIL_POSTCOMMIT is failure");
    TEST_ASSERT(
        is_failure_outcome(&rc_streaming_precommit_failopen) == 1,
        "STREAMING_PRECOMMIT_FAILOPEN is failure");
    TEST_ASSERT(
        is_failure_outcome(&rc_streaming_precommit_reject) == 1,
        "STREAMING_PRECOMMIT_REJECT is failure");
    TEST_ASSERT(
        is_failure_outcome(&rc_streaming_budget_exceeded) == 1,
        "STREAMING_BUDGET_EXCEEDED is failure");
    TEST_ASSERT(
        is_failure_outcome(&rc_streaming_fallback) == 1,
        "STREAMING_FALLBACK_PREBUFFER is failure");

    TEST_PASS("All failure outcomes correctly classified");
}


/*
 * Test: non-failure outcomes are correctly classified
 */
static void
test_non_failure_outcome_classification(void)
{
    TEST_SUBSECTION("Non-failure outcome classification");

    TEST_ASSERT(is_failure_outcome(&rc_skip_config) == 0,
                "SKIP_CONFIG is not failure");
    TEST_ASSERT(is_failure_outcome(&rc_skip_method) == 0,
                "SKIP_METHOD is not failure");
    TEST_ASSERT(is_failure_outcome(&rc_skip_status) == 0,
                "SKIP_STATUS is not failure");
    TEST_ASSERT(is_failure_outcome(&rc_skip_content_type) == 0,
                "SKIP_CONTENT_TYPE is not failure");
    TEST_ASSERT(is_failure_outcome(&rc_skip_size) == 0,
                "SKIP_SIZE is not failure");
    TEST_ASSERT(is_failure_outcome(&rc_skip_streaming) == 0,
                "SKIP_STREAMING is not failure");
    TEST_ASSERT(is_failure_outcome(&rc_skip_auth) == 0,
                "SKIP_AUTH is not failure");
    TEST_ASSERT(is_failure_outcome(&rc_skip_range) == 0,
                "SKIP_RANGE is not failure");
    TEST_ASSERT(is_failure_outcome(&rc_skip_accept) == 0,
                "SKIP_ACCEPT is not failure");
    TEST_ASSERT(is_failure_outcome(&rc_converted) == 0,
                "ELIGIBLE_CONVERTED is not failure");

    /* Engine selection codes */
    TEST_ASSERT(is_failure_outcome(&rc_engine_streaming) == 0,
                "ENGINE_STREAMING is not failure");

    /* Streaming non-failure codes */
    TEST_ASSERT(
        is_failure_outcome(&rc_streaming_convert) == 0,
        "STREAMING_CONVERT is not failure");
    TEST_ASSERT(
        is_failure_outcome(&rc_streaming_shadow) == 0,
        "STREAMING_SHADOW is not failure");
    TEST_ASSERT(
        is_failure_outcome(&rc_streaming_skip) == 0,
        "STREAMING_SKIP_UNSUPPORTED is not failure");

    TEST_PASS("All non-failure outcomes correctly classified");
}


/*
 * Test: NGINX log level matches outcome type (FR-03.5)
 */
static void
test_log_level_selection(void)
{
    TEST_SUBSECTION("NGINX log level selection");

    /* Non-failure outcomes use NGX_LOG_INFO */
    TEST_ASSERT(expected_log_level(&rc_skip_config) == NGX_LOG_INFO,
                "SKIP_CONFIG -> NGX_LOG_INFO");
    TEST_ASSERT(expected_log_level(&rc_skip_method) == NGX_LOG_INFO,
                "SKIP_METHOD -> NGX_LOG_INFO");
    TEST_ASSERT(expected_log_level(&rc_converted) == NGX_LOG_INFO,
                "ELIGIBLE_CONVERTED -> NGX_LOG_INFO");

    /* Engine selection -> NGX_LOG_INFO */
    TEST_ASSERT(expected_log_level(&rc_engine_streaming) == NGX_LOG_INFO,
                "ENGINE_STREAMING -> NGX_LOG_INFO");

    /* Failure outcomes use NGX_LOG_WARN */
    TEST_ASSERT(expected_log_level(&rc_failed_open) == NGX_LOG_WARN,
                "ELIGIBLE_FAILED_OPEN -> NGX_LOG_WARN");
    TEST_ASSERT(expected_log_level(&rc_failed_closed) == NGX_LOG_WARN,
                "ELIGIBLE_FAILED_CLOSED -> NGX_LOG_WARN");
    TEST_ASSERT(expected_log_level(&rc_fail_conversion) == NGX_LOG_WARN,
                "FAIL_CONVERSION -> NGX_LOG_WARN");
    TEST_ASSERT(expected_log_level(&rc_fail_resource) == NGX_LOG_WARN,
                "FAIL_RESOURCE_LIMIT -> NGX_LOG_WARN");
    TEST_ASSERT(expected_log_level(&rc_fail_system) == NGX_LOG_WARN,
                "FAIL_SYSTEM -> NGX_LOG_WARN");

    /* Streaming non-failure -> NGX_LOG_INFO */
    TEST_ASSERT(
        expected_log_level(&rc_streaming_convert) == NGX_LOG_INFO,
        "STREAMING_CONVERT -> NGX_LOG_INFO");
    TEST_ASSERT(
        expected_log_level(&rc_streaming_shadow) == NGX_LOG_INFO,
        "STREAMING_SHADOW -> NGX_LOG_INFO");
    TEST_ASSERT(
        expected_log_level(&rc_streaming_skip) == NGX_LOG_INFO,
        "STREAMING_SKIP_UNSUPPORTED -> NGX_LOG_INFO");

    /* Streaming failure -> NGX_LOG_WARN */
    TEST_ASSERT(
        expected_log_level(&rc_streaming_fail_postcommit)
            == NGX_LOG_WARN,
        "STREAMING_FAIL_POSTCOMMIT -> NGX_LOG_WARN");
    TEST_ASSERT(
        expected_log_level(&rc_streaming_precommit_failopen)
            == NGX_LOG_WARN,
        "STREAMING_PRECOMMIT_FAILOPEN -> NGX_LOG_WARN");
    TEST_ASSERT(
        expected_log_level(&rc_streaming_precommit_reject)
            == NGX_LOG_WARN,
        "STREAMING_PRECOMMIT_REJECT -> NGX_LOG_WARN");
    TEST_ASSERT(
        expected_log_level(&rc_streaming_budget_exceeded)
            == NGX_LOG_WARN,
        "STREAMING_BUDGET_EXCEEDED -> NGX_LOG_WARN");
    TEST_ASSERT(
        expected_log_level(&rc_streaming_fallback)
            == NGX_LOG_WARN,
        "STREAMING_FALLBACK_PREBUFFER -> NGX_LOG_WARN");

    TEST_PASS("Log level selection correct for all outcomes");
}


/*
 * Test: info verbosity emits all outcomes (FR-03.4)
 */
static void
test_verbosity_gating_info(void)
{
    const ngx_str_t  *all_codes[] = {
        &rc_skip_config, &rc_skip_method, &rc_skip_status,
        &rc_skip_content_type, &rc_skip_size,
        &rc_skip_streaming, &rc_skip_auth, &rc_skip_range,
        &rc_skip_accept, &rc_converted, &rc_failed_open,
        &rc_failed_closed, &rc_fail_conversion,
        &rc_fail_resource, &rc_fail_system,
        &rc_engine_streaming,
        &rc_streaming_convert, &rc_streaming_shadow,
        &rc_streaming_fallback, &rc_streaming_skip,
        &rc_streaming_fail_postcommit,
        &rc_streaming_precommit_failopen,
        &rc_streaming_precommit_reject,
        &rc_streaming_budget_exceeded
    };
    TEST_SUBSECTION("Verbosity gating: info emits all");

    for (size_t i = 0; i < ARRAY_SIZE(all_codes); i++) {
        TEST_ASSERT(
            should_emit(NGX_HTTP_MARKDOWN_LOG_INFO,
                        all_codes[i]) == 1,
            "info verbosity should emit all outcomes");
    }

    TEST_PASS("info verbosity emits all outcomes");
}


/*
 * Test: debug verbosity emits all outcomes (FR-03.4)
 */
static void
test_verbosity_gating_debug(void)
{
    const ngx_str_t  *all_codes[] = {
        &rc_skip_config, &rc_skip_method, &rc_skip_status,
        &rc_skip_content_type, &rc_skip_size,
        &rc_skip_streaming, &rc_skip_auth, &rc_skip_range,
        &rc_skip_accept, &rc_converted, &rc_failed_open,
        &rc_failed_closed, &rc_fail_conversion,
        &rc_fail_resource, &rc_fail_system,
        &rc_engine_streaming,
        &rc_streaming_convert, &rc_streaming_shadow,
        &rc_streaming_fallback, &rc_streaming_skip,
        &rc_streaming_fail_postcommit,
        &rc_streaming_precommit_failopen,
        &rc_streaming_precommit_reject,
        &rc_streaming_budget_exceeded
    };
    TEST_SUBSECTION("Verbosity gating: debug emits all");

    for (size_t i = 0; i < ARRAY_SIZE(all_codes); i++) {
        TEST_ASSERT(
            should_emit(NGX_HTTP_MARKDOWN_LOG_DEBUG,
                        all_codes[i]) == 1,
            "debug verbosity should emit all outcomes");
    }

    TEST_PASS("debug verbosity emits all outcomes");
}


/*
 * Test: warn verbosity emits only failure outcomes (FR-03.4)
 */
static void
test_verbosity_gating_warn(void)
{
    TEST_SUBSECTION("Verbosity gating: warn emits failures only");

    /* Non-failure outcomes suppressed */
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_skip_config) == 0,
        "warn suppresses SKIP_CONFIG");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_skip_method) == 0,
        "warn suppresses SKIP_METHOD");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_converted) == 0,
        "warn suppresses ELIGIBLE_CONVERTED");

    /* Engine selection suppressed */
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_engine_streaming) == 0,
        "warn suppresses ENGINE_STREAMING");

    /* Streaming non-failure outcomes suppressed */
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_streaming_convert) == 0,
        "warn suppresses STREAMING_CONVERT");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_streaming_shadow) == 0,
        "warn suppresses STREAMING_SHADOW");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_streaming_skip) == 0,
        "warn suppresses STREAMING_SKIP_UNSUPPORTED");

    /* Failure outcomes emitted */
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_failed_open) == 1,
        "warn emits ELIGIBLE_FAILED_OPEN");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_failed_closed) == 1,
        "warn emits ELIGIBLE_FAILED_CLOSED");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_fail_conversion) == 1,
        "warn emits FAIL_CONVERSION");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_fail_resource) == 1,
        "warn emits FAIL_RESOURCE_LIMIT");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_fail_system) == 1,
        "warn emits FAIL_SYSTEM");

    /* Streaming failure outcomes emitted */
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_streaming_fail_postcommit) == 1,
        "warn emits STREAMING_FAIL_POSTCOMMIT");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_streaming_precommit_failopen) == 1,
        "warn emits STREAMING_PRECOMMIT_FAILOPEN");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_streaming_precommit_reject) == 1,
        "warn emits STREAMING_PRECOMMIT_REJECT");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_streaming_budget_exceeded) == 1,
        "warn emits STREAMING_BUDGET_EXCEEDED");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_WARN,
                    &rc_streaming_fallback) == 1,
        "warn emits STREAMING_FALLBACK_PREBUFFER");

    TEST_PASS("warn verbosity gates correctly");
}


/*
 * Test: error verbosity emits only failure outcomes (FR-03.4)
 */
static void
test_verbosity_gating_error(void)
{
    TEST_SUBSECTION("Verbosity gating: error emits failures only");

    /* Non-failure outcomes suppressed */
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_ERROR,
                    &rc_skip_config) == 0,
        "error suppresses SKIP_CONFIG");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_ERROR,
                    &rc_converted) == 0,
        "error suppresses ELIGIBLE_CONVERTED");

    /* Streaming non-failure outcomes suppressed */
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_ERROR,
                    &rc_streaming_convert) == 0,
        "error suppresses STREAMING_CONVERT");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_ERROR,
                    &rc_streaming_shadow) == 0,
        "error suppresses STREAMING_SHADOW");

    /* Failure outcomes emitted */
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_ERROR,
                    &rc_failed_open) == 1,
        "error emits ELIGIBLE_FAILED_OPEN");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_ERROR,
                    &rc_failed_closed) == 1,
        "error emits ELIGIBLE_FAILED_CLOSED");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_ERROR,
                    &rc_fail_system) == 1,
        "error emits FAIL_SYSTEM");

    /* Streaming failure outcomes emitted */
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_ERROR,
                    &rc_streaming_fail_postcommit) == 1,
        "error emits STREAMING_FAIL_POSTCOMMIT");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_ERROR,
                    &rc_streaming_budget_exceeded) == 1,
        "error emits STREAMING_BUDGET_EXCEEDED");
    TEST_ASSERT(
        should_emit(NGX_HTTP_MARKDOWN_LOG_ERROR,
                    &rc_streaming_fallback) == 1,
        "error emits STREAMING_FALLBACK_PREBUFFER");

    TEST_PASS("error verbosity gates correctly");
}


/*
 * Test: NULL inputs handled safely
 */
static void
test_null_inputs(void)
{
    ngx_str_t empty = ngx_null_string;
    ngx_str_t reason = ngx_string("disabled");

    TEST_SUBSECTION("NULL and empty input handling");

    TEST_ASSERT(is_failure_outcome(NULL) == 0,
                "NULL reason_code -> not failure");
    TEST_ASSERT(is_failure_outcome(&empty) == 0,
                "Empty reason_code -> not failure");

    TEST_ASSERT(should_emit(NGX_HTTP_MARKDOWN_LOG_INFO, NULL) == 1,
                "should_emit with NULL reason_code -> emit (safe default)");
    TEST_ASSERT(should_emit(NGX_HTTP_MARKDOWN_LOG_WARN, &reason) == 0,
                "should_emit warn verbosity + non-failure -> suppress");

    TEST_ASSERT(expected_log_level(NULL) == NGX_LOG_INFO,
                "expected_log_level NULL -> INFO (safe default)");

    TEST_PASS("NULL/empty inputs handled safely");
}


/*
 * Test: unknown family codes are classified as non-failure (Req 8.5)
 */
static void
test_unknown_family_classification(void)
{
    ngx_str_t unknown_info =
        ngx_string("FUTURE_INFORMATIONAL");
    ngx_str_t unknown_prefix =
        ngx_string("NEWNS_SOMETHING");
    ngx_str_t partial_match =
        ngx_string("STREAMING");
    /*
     * Prefix false-positive test: a hypothetical code that shares the
     * "decompression" prefix but has extra characters beyond the known
     * exact-length codes must NOT be classified as failure.
     */
    ngx_str_t decompression_prefix_extra =
        ngx_string("decompression_unknown_future");
    ngx_str_t conversion_prefix_extra =
        ngx_string("conversion_error_extra");

    TEST_SUBSECTION("Unknown family classification");

    TEST_ASSERT(is_failure_outcome(&unknown_info) == 0,
        "FUTURE_INFORMATIONAL -> non-failure (unknown family)");
    TEST_ASSERT(is_failure_outcome(&unknown_prefix) == 0,
        "NEWNS_SOMETHING -> non-failure (unknown family)");
    TEST_ASSERT(is_failure_outcome(&partial_match) == 0,
        "STREAMING (bare, no underscore suffix) -> non-failure");
    TEST_ASSERT(is_failure_outcome(&decompression_prefix_extra) == 0,
        "decompression_unknown_future -> non-failure (prefix + extra chars)");
    TEST_ASSERT(is_failure_outcome(&conversion_prefix_extra) == 0,
        "conversion_error_extra -> non-failure (prefix + extra chars)");

    TEST_PASS("Unknown family codes classified as non-failure");
}


int
main(void)
{
    printf("\n========================================\n");
    printf("decision_log Tests\n");
    printf("========================================\n");

    test_failure_outcome_classification();
    test_non_failure_outcome_classification();
    test_log_level_selection();
    test_verbosity_gating_info();
    test_verbosity_gating_debug();
    test_verbosity_gating_warn();
    test_verbosity_gating_error();
    test_null_inputs();
    test_unknown_family_classification();

    printf("\n========================================\n");
    printf("All tests passed!\n");
    printf("========================================\n\n");
    return 0;
}
