/*
 * Test: gzip_deflate_decompression
 *
 * Validates zlib-based gzip and deflate decompression: round-trip
 * correctness for both formats, corruption detection, output size
 * limit enforcement, and empty input validation.
 */

#include "test_common.h"
#include <zlib.h>

#define NGX_OK 0
#define NGX_ERROR -1

/*
 * Compression format enumeration.
 */
typedef enum {
    TYPE_GZIP = 1,
    TYPE_DEFLATE = 2
} compression_kind_t;

/*
 * Compress a payload using zlib deflate.
 *
 * Parameters:
 *   in      - input data
 *   in_len  - input length in bytes
 *   type    - compression format (TYPE_GZIP or TYPE_DEFLATE)
 *   out     - [out] allocated compressed buffer (caller must free)
 *   out_len - [out] compressed size in bytes
 *
 * Returns:
 *   NGX_OK on success, NGX_ERROR on failure.
 */
static int
compress_payload(const unsigned char *in, size_t in_len, compression_kind_t type,
                 unsigned char **out, size_t *out_len)
{
    z_stream s;
    int rc;
    int window_bits;
    size_t cap;
    unsigned char *in_copy;

    if (in == NULL || in_len == 0 || out == NULL || out_len == NULL) {
        return NGX_ERROR;
    }

    memset(&s, 0, sizeof(s));
    window_bits = (type == TYPE_GZIP) ? (MAX_WBITS + 16) : MAX_WBITS;
    rc = deflateInit2(&s, Z_DEFAULT_COMPRESSION, Z_DEFLATED, window_bits, 8, Z_DEFAULT_STRATEGY);
    if (rc != Z_OK) {
        return NGX_ERROR;
    }

    in_copy = (unsigned char *) malloc(in_len);
    if (in_copy == NULL) {
        deflateEnd(&s);
        return NGX_ERROR;
    }
    memcpy(in_copy, in, in_len);

    cap = in_len + (in_len / 8) + 64;
    *out = (unsigned char *) malloc(cap);
    if (*out == NULL) {
        free(in_copy);
        deflateEnd(&s);
        return NGX_ERROR;
    }

    s.next_in = in_copy;
    s.avail_in = (uInt) in_len;
    s.next_out = *out;
    s.avail_out = (uInt) cap;

    rc = deflate(&s, Z_FINISH);
    if (rc != Z_STREAM_END) {
        free(*out);
        free(in_copy);
        *out = NULL;
        deflateEnd(&s);
        return NGX_ERROR;
    }

    *out_len = s.total_out;
    free(in_copy);
    deflateEnd(&s);
    return NGX_OK;
}

/*
 * Decompress a payload using zlib inflate with size limit enforcement.
 *
 * Parameters:
 *   in       - compressed input data
 *   in_len   - compressed length in bytes
 *   type     - compression format (TYPE_GZIP or TYPE_DEFLATE)
 *   out      - [out] allocated decompressed buffer (caller must free)
 *   out_len  - [out] decompressed size in bytes
 *   max_size - maximum allowed decompressed size
 *
 * Returns:
 *   NGX_OK on success, NGX_ERROR on failure or size limit exceeded.
 */
static int
decompress_payload(const unsigned char *in, size_t in_len, compression_kind_t type,
                   unsigned char **out, size_t *out_len, size_t max_size)
{
    z_stream s;
    int rc;
    int window_bits;
    unsigned char *in_copy;

    if (in == NULL || in_len == 0 || out == NULL || out_len == NULL || max_size == 0) {
        return NGX_ERROR;
    }

    memset(&s, 0, sizeof(s));
    window_bits = (type == TYPE_GZIP) ? (MAX_WBITS + 16) : MAX_WBITS;
    rc = inflateInit2(&s, window_bits);
    if (rc != Z_OK) {
        return NGX_ERROR;
    }

    in_copy = (unsigned char *) malloc(in_len);
    if (in_copy == NULL) {
        inflateEnd(&s);
        return NGX_ERROR;
    }
    memcpy(in_copy, in, in_len);

    *out = (unsigned char *) malloc(max_size);
    if (*out == NULL) {
        free(in_copy);
        inflateEnd(&s);
        return NGX_ERROR;
    }

    s.next_in = in_copy;
    s.avail_in = (uInt) in_len;
    s.next_out = *out;
    s.avail_out = (uInt) max_size;

    rc = inflate(&s, Z_FINISH);
    if (rc != Z_STREAM_END || s.total_out > max_size) {
        free(*out);
        free(in_copy);
        *out = NULL;
        inflateEnd(&s);
        return NGX_ERROR;
    }

    *out_len = s.total_out;
    free(in_copy);
    inflateEnd(&s);
    return NGX_OK;
}

/*
 * Verify compress/decompress round-trip preserves original data.
 * Parameterized by compression type (gzip or deflate).
 *
 * Parameters:
 *   type  - compression format to test
 *   label - test section label
 *
 * Expected: decompressed output matches original input byte-for-byte.
 */
static void
test_valid_roundtrip(compression_kind_t type, const char *label)
{
    const char *text;
    size_t text_len;
    unsigned char *compressed;
    size_t compressed_len;
    unsigned char *decompressed;
    size_t decompressed_len;
    int rc;

    TEST_SUBSECTION(label);

    text = "Hello from nginx markdown module. This payload should round-trip correctly.";
    text_len = test_cstrnlen(text, 1024);
    compressed = NULL;
    decompressed = NULL;

    rc = compress_payload((const unsigned char *) text, text_len, type, &compressed, &compressed_len);
    TEST_ASSERT(rc == NGX_OK, "Compression should succeed");

    rc = decompress_payload(compressed, compressed_len, type, &decompressed, &decompressed_len, 4096);
    TEST_ASSERT(rc == NGX_OK, "Decompression should succeed");
    TEST_ASSERT(decompressed_len == text_len, "Decompressed length should match source");
    TEST_ASSERT(MEM_EQ(decompressed, text, decompressed_len), "Decompressed payload should match source");

    free(compressed);
    free(decompressed);
    TEST_PASS("Round-trip succeeded");
}

/*
 * Verify corrupted compressed data is detected and returns error.
 * Mutates a byte in the compressed payload and verifies decompression fails.
 *
 * Expected: decompression of corrupted data returns NGX_ERROR.
 */
static void
test_corrupted_data(void)
{
    const char *text;
    size_t text_len;
    unsigned char *compressed;
    size_t compressed_len;
    unsigned char *decompressed;
    size_t decompressed_len;
    int rc;

    TEST_SUBSECTION("Corrupted gzip data returns error");

    text = "Corruption test payload";
    text_len = test_cstrnlen(text, 256);
    compressed = NULL;
    decompressed = NULL;

    rc = compress_payload((const unsigned char *) text, text_len, TYPE_GZIP, &compressed, &compressed_len);
    TEST_ASSERT(rc == NGX_OK, "Compression should succeed");
    TEST_ASSERT(compressed_len > 8, "Compressed payload should be long enough to mutate");

    compressed[compressed_len / 2] ^= 0xFF;
    rc = decompress_payload(compressed, compressed_len, TYPE_GZIP, &decompressed, &decompressed_len, 4096);
    TEST_ASSERT(rc == NGX_ERROR, "Corrupted payload should fail decompression");

    free(compressed);
    TEST_PASS("Corrupted data detected");
}

/*
 * Verify output size limit enforcement: decompression fails when the
 * decompressed output would exceed the specified max_size.
 *
 * Expected: decompression returns NGX_ERROR when output exceeds 128 bytes.
 */
static void
test_size_limit_enforcement(void)
{
    char source[4096];
    unsigned char *compressed;
    size_t compressed_len;
    unsigned char *decompressed;
    size_t decompressed_len;
    int rc;

    TEST_SUBSECTION("Size limit enforcement");

    memset(source, 'A', sizeof(source));
    compressed = NULL;
    decompressed = NULL;

    rc = compress_payload((const unsigned char *) source, sizeof(source), TYPE_GZIP, &compressed, &compressed_len);
    TEST_ASSERT(rc == NGX_OK, "Compression should succeed");

    rc = decompress_payload(compressed, compressed_len, TYPE_GZIP, &decompressed, &decompressed_len, 128);
    TEST_ASSERT(rc == NGX_ERROR, "Decompression should fail when output exceeds size limit");

    free(compressed);
    TEST_PASS("Size limit enforcement works");
}

/*
 * Verify empty input validation: zero-length input returns error.
 *
 * Expected: decompression of empty input returns NGX_ERROR.
 */
static void
test_empty_input_validation(void)
{
    unsigned char *out;
    size_t out_len;
    int rc;

    TEST_SUBSECTION("Empty input validation");

    out = NULL;
    out_len = 0;
    rc = decompress_payload((const unsigned char *) "", 0, TYPE_GZIP, &out, &out_len, 256);
    TEST_ASSERT(rc == NGX_ERROR, "Empty input must return error");
    TEST_PASS("Empty input validation works");
}

int
main(void)
{
    printf("\n========================================\n");
    printf("gzip_deflate_decompression Tests\n");
    printf("========================================\n");

    test_valid_roundtrip(TYPE_GZIP, "Valid gzip round-trip");
    test_valid_roundtrip(TYPE_DEFLATE, "Valid deflate round-trip");
    test_corrupted_data();
    test_size_limit_enforcement();
    test_empty_input_validation();

    printf("\n========================================\n");
    printf("All tests passed!\n");
    printf("========================================\n\n");
    return 0;
}
