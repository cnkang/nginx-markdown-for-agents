/*
 * Test: config_handlers_impl
 */

#include "../include/test_common.h"

#include <ctype.h>
#include <stdarg.h>

#define MARKDOWN_STREAMING_ENABLED 1

#include "../../src/ngx_http_markdown_filter_module.h"

#ifndef NGX_OK
#define NGX_OK 0
#endif
#ifndef NGX_ERROR
#define NGX_ERROR -1
#endif
#ifndef NGX_CONF_OK
static char ngx_conf_ok[] = "OK";
#define NGX_CONF_OK ngx_conf_ok
#endif
#ifndef NGX_CONF_ERROR
static char ngx_conf_error[] = "ERROR";
#define NGX_CONF_ERROR ngx_conf_error
#endif

#ifndef NGX_CONF_UNSET
#define NGX_CONF_UNSET (-1)
#endif
#ifndef NGX_CONF_UNSET_UINT
#define NGX_CONF_UNSET_UINT ((ngx_uint_t) -1)
#endif
#ifndef NGX_CONF_UNSET_SIZE
#define NGX_CONF_UNSET_SIZE ((size_t) -1)
#endif
#ifndef NGX_CONF_UNSET_PTR
#define NGX_CONF_UNSET_PTR ((void *) -1)
#endif

#ifndef NGX_LOG_EMERG
#define NGX_LOG_EMERG 1
#endif
#ifndef NGX_LOG_DEBUG
#define NGX_LOG_DEBUG 2
#endif
#ifndef NGX_LOG_INFO
#define NGX_LOG_INFO 3
#endif

#ifndef NGX_MAX_SIZE_T_VALUE
#define NGX_MAX_SIZE_T_VALUE ((size_t) -1)
#endif

typedef intptr_t ngx_err_t;

struct ngx_pool_s {
    int dummy;
};

struct ngx_array_s {
    void       *elts;
    ngx_uint_t  nelts;
    size_t      size;
    ngx_uint_t  nalloc;
    ngx_pool_t *pool;
};

struct ngx_http_request_s {
    int dummy;
};

struct ngx_http_complex_value_s {
    ngx_str_t  value;
};

typedef struct {
    ngx_conf_t                 *cf;
    ngx_str_t                  *value;
    ngx_http_complex_value_t   *complex_value;
} ngx_http_compile_complex_value_t;

struct ngx_conf_s {
    ngx_pool_t  *pool;
    ngx_array_t *args;
    ngx_uint_t   cmd_type;
};

struct ngx_command_s {
    ngx_str_t  name;
    void      *post;
};

struct ngx_module_s {
    int dummy;
};

typedef struct {
    ngx_int_t (*handler)(ngx_http_request_t *r);
} ngx_http_core_loc_conf_t;

/*
 * Global module symbols required by the config implementation header.
 * These are referenced by the production code but never dereferenced
 * in the unit harness.
 */
ngx_module_t ngx_http_markdown_filter_module = { 1 };
ngx_module_t ngx_http_core_module = { 2 };

/*
 * Test-controlled state for stub return values.
 * g_clcf:          pointer returned by ngx_http_conf_get_module_loc_conf;
 *                  tests set it to control the core location configuration.
 * g_compile_complex_rc: return code for ngx_http_compile_complex_value;
 *                  tests set it to simulate compilation success or failure.
 */
static ngx_http_core_loc_conf_t *g_clcf;
static ngx_http_markdown_conf_t *g_module_loc_conf;
static ngx_int_t g_compile_complex_rc;

/*
 * Test instance of main configuration for
 * ngx_http_conf_get_module_main_conf stub.
 * Must be reset before each test that exercises
 * ngx_http_markdown_set_dynconf_path.
 */
static ngx_http_markdown_main_conf_t g_main_conf;
static ngx_uint_t g_diagnostics_recording_requested;

/*
 * No-op stub for the metrics content handler.
 *
 * Parameters:
 *   r  - HTTP request (unused in the unit harness).
 *
 * Return: NGX_OK unconditionally; the unit harness does not exercise
 *         HTTP request processing.
 *
 * Side effects: none.
 */
static ngx_int_t
ngx_http_markdown_metrics_handler(ngx_http_request_t *r)
{
    UNUSED(r);
    return NGX_OK;
}

static ngx_int_t
ngx_http_markdown_diagnostics_handler(ngx_http_request_t *r)
{
    UNUSED(r);
    return NGX_OK;
}

void
ngx_http_markdown_diagnostics_enable_recording(void)
{
    g_diagnostics_recording_requested = 1;
}

/*
 * Case-insensitive comparison of the first n bytes.
 *
 * Test-local reimplementation of the NGINX primitive because the
 * production symbol cannot be linked in the unit harness.
 *
 * Divergence risk: low — logic is a direct transliteration of
 * ngx_ascii_strncasecmp in src/core/ngx_string.c; any future
 * change to the production locale handling or byte folding would
 * require a corresponding update here.
 *
 * Parameters:
 *   s1 - first byte string.
 *   s2 - second byte string.
 *   n  - number of leading bytes to compare.
 *
 * Return: 0 if all n bytes match case-insensitively; otherwise the
 *         difference between the lowercased mismatching bytes
 *         (s1[i] - s2[i]).
 *
 * Side effects: none.
 */
static ngx_int_t
ngx_ascii_strncasecmp(const u_char *s1, const u_char *s2, size_t n)
{

    for (size_t i = 0; i < n; i++) {
        u_char c1;
        u_char c2;

        c1 = (u_char) tolower((unsigned char) s1[i]);
        c2 = (u_char) tolower((unsigned char) s2[i]);

        if (c1 != c2) {
            return (ngx_int_t) c1 - (ngx_int_t) c2;
        }
    }

    return 0;
}

/*
 * Length-bounded case-insensitive comparison delegating to
 * ngx_ascii_strncasecmp.
 *
 * Test-local reimplementation of the NGINX primitive because the
 * production symbol cannot be linked in the unit harness.
 *
 * Divergence risk: low — thin wrapper; any change to the
 * production delegation target would require an update here.
 *
 * Parameters:
 *   s1 - first byte string.
 *   s2 - second byte string.
 *   n  - maximum number of bytes to compare.
 *
 * Return: value from ngx_ascii_strncasecmp.
 *
 * Side effects: none.
 */
static ngx_int_t
ngx_strncasecmp(u_char *s1, u_char *s2, size_t n)
{
    return ngx_ascii_strncasecmp(s1, s2, n);
}

/*
 * Search for byte c in the range [p, last).
 *
 * Test-local reimplementation of the NGINX primitive because the
 * production symbol cannot be linked in the unit harness.
 *
 * Divergence risk: low — mirrors ngx_strlchr in
 * src/core/ngx_string.c.
 *
 * Parameters:
 *   p    - start of search range (inclusive).
 *   last - end of search range (exclusive).
 *   c    - byte value to find.
 *
 * Return: pointer to the first occurrence of c, or NULL if not found.
 *
 * Side effects: none.
 */
static u_char *
ngx_strlchr(u_char *p, u_char *last, u_char c)
{
    while (p < last) {
        if (*p == c) {
            return p;
        }
        p++;
    }

    return NULL;
}

/*
 * Zero-fill wrapper delegating to memset(3).
 *
 * Mirrors production ngx_memzero; test-local reimplementation
 * because the production macro cannot be linked in the unit harness.
 *
 * Divergence risk: low — direct transliteration of the production
 * macro.
 *
 * Parameters:
 *   p - pointer to the memory region to zero.
 *   n - number of bytes to zero.
 *
 * Return: void.
 *
 * Side effects: modifies the memory region pointed to by p.
 */
static void
ngx_memzero(void *p, size_t n)
{
    memset(p, 0, n);
}

/*
 * Pool allocator stub delegating to malloc(3).
 *
 * Does not zero-initialize (unlike ngx_pcalloc).  The pool
 * argument is ignored; the unit harness does not simulate pool
 * ownership or cleanup.
 *
 * Divergence risk: medium — production ngx_palloc may return
 * previously-freed pool memory or trigger pool expansion; this
 * stub always calls malloc, so allocation patterns differ.
 *
 * Parameters:
 *   pool - memory pool (unused).
 *   size - number of bytes to allocate.
 *
 * Return: pointer to allocated memory, or NULL on failure.
 *
 * Side effects: allocates heap memory via malloc(3).
 */
static int g_next_palloc_fails;

static void *
ngx_palloc(ngx_pool_t *pool, size_t size)
{
    UNUSED(pool);
    if (g_next_palloc_fails > 0) {
        g_next_palloc_fails--;
        return NULL;
    }
    return malloc(size);
}

/*
 * Array creation stub.  Allocates the array header and element
 * storage via calloc(3).  The pool argument is ignored.
 *
 * Divergence risk: medium — production ngx_array_create allocates
 * from the pool and does not guarantee zero-initialization of
 * elements; this stub uses calloc, so elements are always zeroed.
 *
 * Parameters:
 *   pool - memory pool (unused).
 *   n    - initial number of elements to allocate (0 is promoted to 1).
 *   size - size of each element in bytes.
 *
 * Return: pointer to the new array, or NULL on allocation failure.
 *
 * Side effects: allocates heap memory via calloc(3).
 */
static ngx_array_t *
ngx_array_create(ngx_pool_t *pool, ngx_uint_t n, size_t size)
{
    ngx_array_t *a;

    UNUSED(pool);

    a = calloc(1, sizeof(ngx_array_t));
    if (a == NULL) {
        return NULL;
    }

    a->size = size;
    a->nalloc = (n == 0) ? 1 : n;
    a->pool = pool;
    a->elts = calloc(a->nalloc, size);
    if (a->elts == NULL) {
        free(a);
        return NULL;
    }

    return a;
}

/*
 * Array push stub.  Doubles storage on overflow via realloc(3),
 * zero-initializing new slots.  Returns NULL on NULL input or
 * allocation failure.
 *
 * Divergence risk: medium — production ngx_array_push allocates
 * from the pool and may not zero-initialize new elements; this
 * stub uses realloc and explicit memset, so behaviour differs
 * for uninitialized-element reads.
 *
 * Parameters:
 *   a - pointer to the array to push into.
 *
 * Return: pointer to the newly pushed element (zero-initialized),
 *         or NULL on NULL input or allocation failure.
 *
 * Side effects: may reallocate the element buffer; modifies a->nelts
 *               and a->nalloc on growth.
 */
static void *
ngx_array_push(ngx_array_t *a)
{
    void *elt;

    if (a == NULL) {
        return NULL;
    }

    if (a->nelts >= a->nalloc) {
        void      *new_elts;
        ngx_uint_t new_nalloc;

        new_nalloc = a->nalloc * 2;
        new_elts = realloc(a->elts, new_nalloc * a->size);
        if (new_elts == NULL) {
            return NULL;
        }

        memset((u_char *) new_elts + (a->nalloc * a->size),
               0,
               (new_nalloc - a->nalloc) * a->size);

        a->elts = new_elts;
        a->nalloc = new_nalloc;
    }

    elt = (u_char *) a->elts + (a->nelts * a->size);
    memset(elt, 0, a->size);
    a->nelts++;

    return elt;
}

/*
 * Complex value compilation stub.  Copies the input string to the
 * output complex_value and returns g_compile_complex_rc, allowing
 * tests to control compilation success or failure.
 *
 * Divergence risk: high — production ngx_http_compile_complex_value
 * parses NGINX variable expressions and builds a bytecode program;
 * this stub performs a shallow copy only, so variable resolution
 * at request time is not exercised.
 *
 * Parameters:
 *   ccv - compilation context containing cf, value, and
 *         complex_value pointers.
 *
 * Return: g_compile_complex_rc (NGX_OK or NGX_ERROR as set by
 *         the test), or NGX_ERROR if ccv or its members are NULL.
 *
 * Side effects: writes to ccv->complex_value->value on success.
 */
static ngx_int_t
ngx_http_compile_complex_value(ngx_http_compile_complex_value_t *ccv)
{
    if (ccv == NULL || ccv->value == NULL || ccv->complex_value == NULL) {
        return NGX_ERROR;
    }

    ccv->complex_value->value = *ccv->value;
    return g_compile_complex_rc;
}

/*
 * Global buffer for capturing ngx_conf_log_error output.
 * Tests can inspect this after calling handlers that emit
 * configuration error messages.
 */
static char g_conf_log_buf[1024];
static ngx_uint_t g_conf_log_level;

/*
 * Capturing stub for ngx_conf_log_error.  Formats the message
 * into g_conf_log_buf so tests can assert on error content.
 *
 * Parameters:
 *   level - log level (captured in g_conf_log_level).
 *   cf    - configuration context (unused).
 *   err   - error code (unused).
 *   fmt   - printf-style format string.
 *   ...   - format arguments.
 *
 * Return: void.
 *
 * Side effects: writes to g_conf_log_buf and g_conf_log_level.
 */
static void
ngx_conf_log_error(ngx_uint_t level, ngx_conf_t *cf, ngx_err_t err,
    const char *fmt, ...)
{
    va_list  ap;
    char    *p;
    char    *end;

    UNUSED(cf);
    UNUSED(err);

    g_conf_log_level = level;
    p = g_conf_log_buf;
    end = g_conf_log_buf + sizeof(g_conf_log_buf) - 1;

    va_start(ap, fmt);

    /*
     * Minimal format expansion supporting %V (ngx_str_t *) and %s.
     * Sufficient for the reject-removed-directive handler and other
     * simple config error messages.
     */
    while (*fmt && p < end) {
        if (*fmt == '%' && *(fmt + 1) == 'V') {
            ngx_str_t *s = va_arg(ap, ngx_str_t *);
            size_t     n;

            n = (size_t) (end - p);
            if (n > s->len) {
                n = s->len;
            }
            memcpy(p, s->data, n);
            p += n;
            fmt += 2;
        } else if (*fmt == '%' && *(fmt + 1) == 's') {
            const char *s = va_arg(ap, const char *);
            size_t      slen;
            size_t      n;

            slen = strlen(s);
            n = (size_t) (end - p);
            if (n > slen) {
                n = slen;
            }
            memcpy(p, s, n);
            p += n;
            fmt += 2;
        } else if (*fmt == '%' && *(fmt + 1) == 'd') {
            int  val = va_arg(ap, int);
            int  written;

            written = snprintf(p, (size_t) (end - p), "%d", val);
            if (written > 0) {
                p += written;
            }
            fmt += 2;
        } else if (*fmt == '"' && *(fmt + 1) == '%') {
            /* pass the literal quote character */
            *p++ = *fmt++;
        } else {
            *p++ = *fmt++;
        }
    }

    va_end(ap);
    *p = '\0';
}

/*
 * Returns the preconfigured g_clcf pointer, allowing tests to
 * control the core location configuration without linking the
 * full NGINX HTTP module infrastructure.
 *
 * Parameters:
 *   cf     - configuration context (unused).
 *   module - module identifier (unused).
 *
 * Return: g_clcf as set by the test.
 *
 * Side effects: none.
 */
static void *
ngx_http_conf_get_module_loc_conf(ngx_conf_t *cf, ngx_module_t module)
{
    UNUSED(cf);
    return module.dummy == ngx_http_core_module.dummy
        ? (void *) g_clcf : (void *) g_module_loc_conf;
}

/*
 * Returns the test instance of ngx_http_markdown_main_conf_t,
 * allowing ngx_http_markdown_set_dynconf_path to read and write
 * dynconf_path_configured / dynconf_first_path without linking
 * the full NGINX configuration infrastructure.
 *
 * Parameters:
 *   cf     - configuration context (unused).
 *   module - module identifier (unused).
 *
 * Return: pointer to g_main_conf.
 *
 * Side effects: none.
 */
static void *
ngx_http_conf_get_module_main_conf(ngx_conf_t *cf, ngx_module_t module)
{
    UNUSED(cf);
    UNUSED(module);
    return &g_main_conf;
}

/*
 * spec 47: stubs for the trusted-proxy FFI used by the
 * markdown_trusted_proxies directive handler.  The C unit-test build does not
 * link the Rust library, so the CIDR set handle and validation are stubbed.
 * g_trusted_push_rc lets a test force an invalid-CIDR rejection; the dummy
 * handle is never dereferenced.
 */
#ifndef NGX_HTTP_MAIN_CONF
#define NGX_HTTP_MAIN_CONF 0x02000000
#endif
#ifndef NGX_HTTP_SRV_CONF
#define NGX_HTTP_SRV_CONF 0x04000000
#endif
#ifndef NGX_HTTP_LOC_CONF
#define NGX_HTTP_LOC_CONF 0x08000000
#endif
#ifndef TRUSTED_PROXIES_PUSH_OK
#define TRUSTED_PROXIES_PUSH_OK 0
#endif
#ifndef TRUSTED_PROXIES_PUSH_INVALID_CIDR
#define TRUSTED_PROXIES_PUSH_INVALID_CIDR 1
#endif
#ifndef TRUSTED_PROXIES_PUSH_NULL
#define TRUSTED_PROXIES_PUSH_NULL 2
#endif

typedef struct {
    void  (*handler)(void *data);
    void   *data;
} ngx_pool_cleanup_t;

static ngx_pool_cleanup_t g_trusted_cleanup;
static uint8_t            g_trusted_push_rc = TRUSTED_PROXIES_PUSH_OK;
static ngx_uint_t         g_trusted_new_calls;
static ngx_uint_t         g_trusted_push_calls;
static ngx_uint_t         g_trusted_free_calls;
static struct MarkdownTrustedProxies *g_trusted_dummy =
    (struct MarkdownTrustedProxies *) (uintptr_t) 0x1;

static ngx_pool_cleanup_t *
ngx_pool_cleanup_add(ngx_pool_t *p, size_t size)
{
    UNUSED(p);
    UNUSED(size);
    g_trusted_cleanup.handler = NULL;
    g_trusted_cleanup.data = NULL;
    return &g_trusted_cleanup;
}

struct MarkdownTrustedProxies *
markdown_trusted_proxies_new(void) /* SONAR_NOTE: matches FFI signature */
{
    g_trusted_new_calls++;
    return g_trusted_dummy;
}

uint8_t
markdown_trusted_proxies_push(struct MarkdownTrustedProxies *handle,
    const uint8_t *cidr, uintptr_t cidr_len) /* SONAR_NOTE: FFI signature */
{
    g_trusted_push_calls++;
    if (handle == NULL || cidr == NULL || cidr_len == 0) {
        return TRUSTED_PROXIES_PUSH_NULL;
    }
    return g_trusted_push_rc;
}

void
markdown_trusted_proxies_free(struct MarkdownTrustedProxies *handle)
{
    UNUSED(handle);
    g_trusted_free_calls++;
}

#include "../../src/ngx_http_markdown_config_handlers_impl.h"

static ngx_pool_t g_pool;
/*
 * Assign a C string literal to an ngx_str_t.  Casts through
 * uintptr_t for u_char* compatibility to avoid compiler warnings
 * about discarding const from string literals.
 *
 * Parameters:
 *   arg - pointer to the ngx_str_t to populate.
 *   s   - null-terminated C string literal.
 *
 * Return: void.
 *
 * Side effects: modifies arg->data and arg->len.
 */
static void
set_arg(ngx_str_t *arg, const char *s)
{
    arg->data = (u_char *) (uintptr_t) s;
    arg->len = strlen(s);
}

/*
 * Wire up an ngx_conf_t with a pool and an args array pointing to
 * the given values array.  Prepares the configuration structure
 * used by directive handler invocations in tests.
 *
 * Parameters:
 *   cf    - pointer to the ngx_conf_t to initialize.
 *   args  - pointer to the ngx_array_t to use as the args array.
 *   values - array of ngx_str_t values to serve as array elements.
 *   count  - number of elements in values.
 *
 * Return: void.
 *
 * Side effects: modifies cf->pool, cf->args, and all fields of args.
 */
static void
setup_cf(ngx_conf_t *cf, ngx_array_t *args, ngx_str_t *values,
    ngx_uint_t count)
{
    args->elts = values;
    args->nelts = count;
    args->size = sizeof(ngx_str_t);
    args->nalloc = count;
    args->pool = &g_pool;

    cf->pool = &g_pool;
    cf->args = args;
}

/*
 * Zero-initialize a location conf and set all enum/pointer fields
 * to their NGINX unset sentinels.  Ensures each test starts from a
 * clean, well-defined configuration state.
 *
 * Parameters:
 *   mcf - pointer to the ngx_http_markdown_conf_t to initialize.
 *
 * Return: void.
 *
 * Side effects: overwrites all fields of *mcf.
 */
static void
init_conf(ngx_http_markdown_conf_t *mcf)
{
    memset(mcf, 0, sizeof(*mcf));

    mcf->enabled_source = NGX_HTTP_MARKDOWN_ENABLED_UNSET;
    mcf->enabled_complex = NULL;
    mcf->on_error = NGX_CONF_UNSET_UINT;
    mcf->flavor = NGX_CONF_UNSET_UINT;
    mcf->policy.auth_policy = NGX_CONF_UNSET_UINT;
    mcf->policy.auth_cookies = NGX_CONF_UNSET_PTR;
    mcf->routing.content_types = NGX_CONF_UNSET_PTR;
    mcf->policy.conditional_requests = NGX_CONF_UNSET_UINT;
    mcf->policy.log_verbosity = NGX_CONF_UNSET_UINT;
    mcf->ops.metrics_enabled = NGX_CONF_UNSET;
    mcf->routing.large_body_threshold = NGX_CONF_UNSET_SIZE;
    mcf->stream.policy = NGX_CONF_UNSET_UINT;
    mcf->stream.policy_explicit = -1;
    mcf->stream.excluded_types = NGX_CONF_UNSET_PTR;
}

/*
 * Verify ngx_http_markdown_arg_equals: NULL data, case-insensitive
 * match, and length mismatch.
 *
 * Semantic contract mirrored: the production arg_equals helper
 * returns 1 for an exact (case-insensitive, length-equal) match
 * and 0 otherwise.
 *
 * Return: void.
 *
 * Side effects: none (assertions only).
 */
static void
test_arg_equals(void)
{
    ngx_str_t arg;

    TEST_SUBSECTION("arg_equals helper");

    arg.data = NULL;
    arg.len = 0;
    TEST_ASSERT(ngx_http_markdown_arg_equals(&arg, (u_char *) "on", 2) == 0,
        "NULL arg data should not match");

    set_arg(&arg, "On");
    TEST_ASSERT(ngx_http_markdown_arg_equals(&arg, (u_char *) "on", 2) == 1,
        "matching token should be case-insensitive");

    TEST_ASSERT(ngx_http_markdown_arg_equals(&arg, (u_char *) "on", 3) == 0,
        "mismatched length should fail");

    TEST_PASS("arg_equals branches covered");
}

/*
 * Verify the markdown_filter directive handler: on/off, duplicate
 * detection, variable compilation, invalid token, and compile
 * failure.
 *
 * Semantic contract mirrored: ngx_http_markdown_filter sets
 * mcf->enabled and mcf->enabled_source for static tokens, or
 * mcf->enabled_complex for variable expressions; it rejects
 * duplicates and invalid tokens.
 *
 * Return: void.
 *
 * Side effects: modifies g_compile_complex_rc; asserts on mcf fields.
 */
static void
test_markdown_filter_handler(void)
{
    ngx_conf_t               cf;
    ngx_array_t              args;
    ngx_str_t                values[2];
    ngx_command_t            cmd;
    ngx_http_markdown_conf_t mcf;
    const char              *rc;

    TEST_SUBSECTION("markdown_filter handler");

    init_conf(&mcf);
    setup_cf(&cf, &args, values, 2);
    set_arg(&cmd.name, "markdown_filter");
    set_arg(&values[0], "markdown_filter");

    set_arg(&values[1], "on");
    rc = ngx_http_markdown_filter(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "on should parse");
    TEST_ASSERT(mcf.enabled == 1, "enabled should be 1");
    TEST_ASSERT(mcf.enabled_source == NGX_HTTP_MARKDOWN_ENABLED_STATIC,
        "enabled source should be static");

    rc = ngx_http_markdown_filter(&cf, &cmd, &mcf);
    TEST_ASSERT(strcmp(rc, "is duplicate") == 0,
        "duplicate should be rejected");

    init_conf(&mcf);
    set_arg(&values[1], "off");
    rc = ngx_http_markdown_filter(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "off should parse");
    TEST_ASSERT(mcf.enabled == 0, "enabled should be 0");

    init_conf(&mcf);
    set_arg(&values[1], "$convert");
    g_compile_complex_rc = NGX_OK;
    rc = ngx_http_markdown_filter(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "variable should compile");
    TEST_ASSERT(mcf.enabled_source == NGX_HTTP_MARKDOWN_ENABLED_COMPLEX,
        "variable should set complex source");
    TEST_ASSERT(mcf.enabled_complex != NULL,
        "complex value should be stored");

    init_conf(&mcf);
    set_arg(&values[1], "yes");
    rc = ngx_http_markdown_filter(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "invalid static token should fail");

    init_conf(&mcf);
    set_arg(&values[1], "$bad_compile");
    g_compile_complex_rc = NGX_ERROR;
    rc = ngx_http_markdown_filter(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "compile failure should return error");

    g_compile_complex_rc = NGX_OK;

    TEST_PASS("markdown_filter branches covered");
}

/*
 * Verify that ngx_http_markdown_filter correctly handles non-NUL-terminated
 * ngx_str_t data for the "on" and "off" tokens.
 *
 * Regression test: the handler previously used ngx_strcasecmp which reads
 * until a NUL byte, potentially reading past the valid length of the
 * ngx_str_t.  The fix uses ngx_http_markdown_arg_equals (length-bounded
 * comparison via ngx_strncasecmp).
 *
 * This test constructs buffers where the bytes immediately following the
 * token are NOT NUL, proving that the comparison respects .len and does
 * not rely on NUL termination.
 *
 * Return: void.
 *
 * Side effects: assertions only.
 */
static void
test_markdown_filter_non_nul_terminated(void)
{
    ngx_conf_t               cf;
    ngx_array_t              args;
    ngx_str_t                values[2];
    ngx_command_t            cmd;
    ngx_http_markdown_conf_t mcf;
    const char              *rc;

    /*
     * Buffer layout: "onXYZ" — the token "on" occupies bytes 0-1,
     * but byte 2 is 'X' (not NUL).  If the comparison reads past
     * len==2, it would see 'X' and potentially mismatch or read
     * out of bounds.
     */
    static u_char on_buf[] = "onXYZ";
    static u_char off_buf[] = "offABC";

    TEST_SUBSECTION("markdown_filter non-NUL-terminated args");

    setup_cf(&cf, &args, values, 2);
    set_arg(&cmd.name, "markdown_filter");
    set_arg(&values[0], "markdown_filter");

    /* Test "on" with non-NUL-terminated data */
    init_conf(&mcf);
    values[1].data = on_buf;
    values[1].len = 2;
    rc = ngx_http_markdown_filter(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK,
        "non-NUL-terminated 'on' should parse");
    TEST_ASSERT(mcf.enabled == 1,
        "enabled should be 1 for non-NUL-terminated 'on'");
    TEST_ASSERT(mcf.enabled_source == NGX_HTTP_MARKDOWN_ENABLED_STATIC,
        "source should be static for non-NUL-terminated 'on'");

    /* Test "off" with non-NUL-terminated data */
    init_conf(&mcf);
    values[1].data = off_buf;
    values[1].len = 3;
    rc = ngx_http_markdown_filter(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK,
        "non-NUL-terminated 'off' should parse");
    TEST_ASSERT(mcf.enabled == 0,
        "enabled should be 0 for non-NUL-terminated 'off'");
    TEST_ASSERT(mcf.enabled_source == NGX_HTTP_MARKDOWN_ENABLED_STATIC,
        "source should be static for non-NUL-terminated 'off'");

    /* Test case-insensitive "ON" with non-NUL-terminated data */
    init_conf(&mcf);
    values[1].data = (u_char *) "ONgarbage";
    values[1].len = 2;
    rc = ngx_http_markdown_filter(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK,
        "non-NUL-terminated 'ON' (uppercase) should parse");
    TEST_ASSERT(mcf.enabled == 1,
        "enabled should be 1 for uppercase 'ON'");

    /* Test case-insensitive "Off" with non-NUL-terminated data */
    init_conf(&mcf);
    values[1].data = (u_char *) "Offmore";
    values[1].len = 3;
    rc = ngx_http_markdown_filter(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK,
        "non-NUL-terminated 'Off' (mixed case) should parse");
    TEST_ASSERT(mcf.enabled == 0,
        "enabled should be 0 for mixed-case 'Off'");

    TEST_PASS("non-NUL-terminated markdown_filter args handled safely");
}

/*
 * Verify on_error, flavor, and auth_policy handlers: valid values,
 * duplicate detection, and invalid values.
 *
 * Semantic contract mirrored: each handler maps a string token to
 * the corresponding enum value in mcf, rejects duplicates, and
 * returns NGX_CONF_ERROR for unrecognized tokens.
 *
 * Return: void.
 *
 * Side effects: asserts on mcf enum fields.
 */
static void
test_simple_enum_handlers(void)
{
    ngx_conf_t               cf;
    ngx_array_t              args;
    ngx_str_t                values[3];
    ngx_command_t            cmd;
    ngx_http_markdown_conf_t mcf;
    const char              *rc;

    TEST_SUBSECTION("error_policy/flavor/auth_policy handlers");

    setup_cf(&cf, &args, values, 2);

    init_conf(&mcf);
    set_arg(&cmd.name, "markdown_error_policy");
    set_arg(&values[0], "markdown_error_policy");
    set_arg(&values[1], "pass");
    rc = ngx_http_markdown_error_policy(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "pass should parse");
    TEST_ASSERT(mcf.on_error == NGX_HTTP_MARKDOWN_ON_ERROR_PASS,
        "pass should map to on_error=PASS");
    rc = ngx_http_markdown_error_policy(&cf, &cmd, &mcf);
    TEST_ASSERT(strcmp(rc, "is duplicate") == 0,
        "duplicate error_policy should fail");

    init_conf(&mcf);
    set_arg(&values[1], "fail_closed");
    rc = ngx_http_markdown_error_policy(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "fail_closed should parse");
    TEST_ASSERT(mcf.on_error == NGX_HTTP_MARKDOWN_ON_ERROR_REJECT,
        "fail_closed should map to on_error=REJECT");
    TEST_ASSERT(mcf.error_status == 502,
        "fail_closed should map to status 502");

    init_conf(&mcf);
    set_arg(&values[1], "bad");
    rc = ngx_http_markdown_error_policy(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "invalid error_policy should fail");

    /* status <code> takes two arguments */
    setup_cf(&cf, &args, values, 3);
    set_arg(&values[0], "markdown_error_policy");
    init_conf(&mcf);
    set_arg(&values[1], "status");
    set_arg(&values[2], "503");
    rc = ngx_http_markdown_error_policy(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "status 503 should parse");
    TEST_ASSERT(mcf.on_error == NGX_HTTP_MARKDOWN_ON_ERROR_REJECT,
        "status should map to on_error=REJECT");
    TEST_ASSERT(mcf.error_status == 503, "status 503 should store 503");

    init_conf(&mcf);
    set_arg(&values[1], "status");
    set_arg(&values[2], "429");
    rc = ngx_http_markdown_error_policy(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "status 429 should parse");
    TEST_ASSERT(mcf.on_error == NGX_HTTP_MARKDOWN_ON_ERROR_REJECT,
        "status 429 should map to on_error=REJECT");
    TEST_ASSERT(mcf.error_status == 429, "status 429 should store 429");

    init_conf(&mcf);
    set_arg(&values[1], "status");
    set_arg(&values[2], "418");
    rc = ngx_http_markdown_error_policy(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "disallowed status code should fail");

    init_conf(&mcf);
    set_arg(&values[1], "status");
    set_arg(&values[2], "502");
    rc = ngx_http_markdown_error_policy(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "status 502 should fail and prompt to use fail_closed");

    setup_cf(&cf, &args, values, 2);

    init_conf(&mcf);
    set_arg(&cmd.name, "markdown_flavor");
    set_arg(&values[0], "markdown_flavor");
    set_arg(&values[1], "gfm");
    rc = ngx_http_markdown_flavor(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "gfm should parse");
    TEST_ASSERT(mcf.flavor == NGX_HTTP_MARKDOWN_FLAVOR_GFM,
        "flavor should be gfm");

    init_conf(&mcf);
    set_arg(&values[1], "mdx");
    g_conf_log_buf[0] = '\0';
    rc = ngx_http_markdown_flavor(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "mdx should be rejected");
    TEST_ASSERT(strstr(g_conf_log_buf, "markdown_flavor commonmark") != NULL
            && strstr(g_conf_log_buf, "markdown_flavor gfm") != NULL,
        "mdx rejection should name supported flavor replacements");

    init_conf(&mcf);
    set_arg(&values[1], "org-mode");
    g_conf_log_buf[0] = '\0';
    rc = ngx_http_markdown_flavor(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "org-mode should be rejected");
    TEST_ASSERT(strstr(g_conf_log_buf, "markdown_flavor commonmark") != NULL
            && strstr(g_conf_log_buf, "markdown_flavor gfm") != NULL,
        "org-mode rejection should name supported flavor replacements");

    init_conf(&mcf);
    set_arg(&values[1], "markdown");
    rc = ngx_http_markdown_flavor(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "invalid flavor should fail");

    init_conf(&mcf);
    set_arg(&cmd.name, "markdown_auth_policy");
    set_arg(&values[0], "markdown_auth_policy");
    set_arg(&values[1], "deny");
    rc = ngx_http_markdown_auth_policy(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "deny should parse");
    TEST_ASSERT(mcf.policy.auth_policy == NGX_HTTP_MARKDOWN_AUTH_POLICY_DENY,
        "auth_policy should be deny");

    init_conf(&mcf);
    set_arg(&values[1], "block");
    rc = ngx_http_markdown_auth_policy(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "invalid auth policy should fail");

    TEST_PASS("simple enum handlers covered");
}

/*
 * Verify auth_cookies handler: multiple patterns, duplicate
 * detection, and empty pattern rejection.
 *
 * Semantic contract mirrored: ngx_http_markdown_auth_cookies
 * collects one or more glob patterns into an ngx_array_t stored in
 * mcf->policy.policy.auth_cookies; it rejects duplicates and empty patterns.
 *
 * Return: void.
 *
 * Side effects: asserts on mcf.policy.auth_cookies array contents.
 */
static void
test_auth_cookies_handler(void)
{
    ngx_conf_t               cf;
    ngx_array_t              args;
    ngx_str_t                values[4];
    ngx_command_t            cmd;
    ngx_http_markdown_conf_t mcf;
    const ngx_str_t         *elts;
    const char              *rc;

    TEST_SUBSECTION("auth_cookies handler");

    init_conf(&mcf);
    setup_cf(&cf, &args, values, 4);
    set_arg(&cmd.name, "markdown_auth_cookies");

    set_arg(&values[0], "markdown_auth_cookies");
    set_arg(&values[1], "session*");
    set_arg(&values[2], "*token");
    set_arg(&values[3], "auth");

    rc = ngx_http_markdown_auth_cookies(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "cookie patterns should parse");
    TEST_ASSERT(mcf.policy.auth_cookies != NULL, "cookie array should be created");
    TEST_ASSERT(mcf.policy.auth_cookies->nelts == 3, "three patterns expected");

    elts = mcf.policy.auth_cookies->elts;
    TEST_ASSERT(elts[0].len == strlen("session*"), "pattern 0 length");
    TEST_ASSERT(elts[1].len == strlen("*token"), "pattern 1 length");
    TEST_ASSERT(elts[2].len == strlen("auth"), "pattern 2 length");

    rc = ngx_http_markdown_auth_cookies(&cf, &cmd, &mcf);
    TEST_ASSERT(strcmp(rc, "is duplicate") == 0,
        "duplicate auth_cookies should fail");

    init_conf(&mcf);
    set_arg(&values[1], "");
    rc = ngx_http_markdown_auth_cookies(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "empty pattern should fail");

    TEST_PASS("auth_cookies branches covered");
}

/*
 * Verify conditional_requests and log_verbosity handlers: valid
 * and invalid enum values.
 *
 * Semantic contract mirrored: each handler maps a string token to
 * the corresponding enum value, rejects duplicates, and returns
 * NGX_CONF_ERROR for unrecognized tokens.
 *
 * Return: void.
 *
 * Side effects: asserts on mcf enum fields.
 */
static void
test_conditional_and_log_verbosity_handlers(void)
{
    ngx_conf_t               cf;
    ngx_array_t              args;
    ngx_str_t                values[2];
    ngx_command_t            cmd;
    ngx_http_markdown_conf_t mcf;
    const char              *rc;

    TEST_SUBSECTION("cache_validation/log_verbosity handlers");

    setup_cf(&cf, &args, values, 2);
    set_arg(&values[0], "directive");

    init_conf(&mcf);
    set_arg(&cmd.name, "markdown_cache_validation");
    set_arg(&values[1], "ims_only");
    rc = ngx_http_markdown_cache_validation(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "ims_only should parse");
    TEST_ASSERT(mcf.policy.conditional_requests
        == NGX_HTTP_MARKDOWN_CONDITIONAL_IF_MODIFIED_SINCE,
        "conditional mode should match");
    TEST_ASSERT(mcf.policy.generate_etag == 0,
        "ims_only should disable etag generation");

    init_conf(&mcf);
    set_arg(&values[1], "full");
    rc = ngx_http_markdown_cache_validation(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "full should parse");
    TEST_ASSERT(mcf.policy.conditional_requests
        == NGX_HTTP_MARKDOWN_CONDITIONAL_FULL_SUPPORT,
        "full should enable full conditional support");
    TEST_ASSERT(mcf.policy.generate_etag == 1,
        "full should enable etag generation");

    init_conf(&mcf);
    set_arg(&values[1], "off");
    rc = ngx_http_markdown_cache_validation(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "off should parse");
    TEST_ASSERT(mcf.policy.conditional_requests
        == NGX_HTTP_MARKDOWN_CONDITIONAL_DISABLED,
        "off should disable conditional support");

    init_conf(&mcf);
    set_arg(&values[1], "invalid");
    rc = ngx_http_markdown_cache_validation(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "invalid cache_validation mode should fail");

    init_conf(&mcf);
    set_arg(&cmd.name, "markdown_log_verbosity");
    set_arg(&values[1], "debug");
    rc = ngx_http_markdown_log_verbosity(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "debug should parse");
    TEST_ASSERT(mcf.policy.log_verbosity == NGX_HTTP_MARKDOWN_LOG_DEBUG,
        "log verbosity should be debug");

    init_conf(&mcf);
    set_arg(&values[1], "error");
    rc = ngx_http_markdown_log_verbosity(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "error should parse");

    init_conf(&mcf);
    set_arg(&values[1], "trace");
    rc = ngx_http_markdown_log_verbosity(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "invalid log verbosity should fail");

    TEST_PASS("conditional/log_verbosity branches covered");
}

/*
 * Verify markdown_streaming off|auto|force handler (spec 49):
 * valid enum tokens, duplicate detection, invalid token rejection,
 * and that policy_explicit is recorded.
 *
 * Semantic contract mirrored: ngx_http_markdown_streaming maps a
 * string token to the NGX_HTTP_MARKDOWN_STREAMING_* enum, rejects
 * duplicates ("is duplicate"), returns NGX_CONF_ERROR for unknown
 * tokens, and sets stream.policy_explicit on success.
 *
 * Return: void.
 *
 * Side effects: asserts on mcf->stream fields.
 */
static void
test_streaming_policy_handler(void)
{
    ngx_conf_t               cf;
    ngx_array_t              args;
    ngx_str_t                values[2];
    ngx_command_t            cmd;
    ngx_http_markdown_conf_t mcf;
    const char              *rc;

    TEST_SUBSECTION("markdown_streaming policy handler (spec 49)");

    setup_cf(&cf, &args, values, 2);
    set_arg(&values[0], "markdown_streaming");
    set_arg(&cmd.name, "markdown_streaming");

    init_conf(&mcf);
    set_arg(&values[1], "off");
    rc = ngx_http_markdown_streaming(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "off should parse");
    TEST_ASSERT(mcf.stream.policy == NGX_HTTP_MARKDOWN_STREAMING_OFF,
        "policy should be OFF");
    TEST_ASSERT(mcf.stream.policy_explicit == 1,
        "policy_explicit should be recorded");

    init_conf(&mcf);
    set_arg(&values[1], "auto");
    rc = ngx_http_markdown_streaming(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "auto should parse");
    TEST_ASSERT(mcf.stream.policy == NGX_HTTP_MARKDOWN_STREAMING_AUTO,
        "policy should be AUTO");

    init_conf(&mcf);
    set_arg(&values[1], "force");
    rc = ngx_http_markdown_streaming(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "force should parse");
    TEST_ASSERT(mcf.stream.policy == NGX_HTTP_MARKDOWN_STREAMING_FORCE,
        "policy should be FORCE");
    TEST_ASSERT(mcf.stream.policy_explicit == 1,
        "policy_explicit should be recorded for force");

    /* Duplicate detection: a second set on the same conf is rejected. */
    set_arg(&values[1], "auto");
    rc = ngx_http_markdown_streaming(&cf, &cmd, &mcf);
    TEST_ASSERT(rc != NGX_CONF_OK && rc != NGX_CONF_ERROR,
        "second markdown_streaming should be \"is duplicate\"");

    init_conf(&mcf);
    set_arg(&values[1], "on");   /* engine token, not a valid policy */
    rc = ngx_http_markdown_streaming(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "invalid policy token \"on\" should fail");

    init_conf(&mcf);
    set_arg(&values[1], "bogus");
    rc = ngx_http_markdown_streaming(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "invalid policy token should fail");

    TEST_PASS("markdown_streaming policy handler branches covered");
}

/* Verify stream_types handler: valid types, duplicate detection. */
/*
 * Verify the markdown_limits multi-key handler: each key maps to its
 * backing field, plus unknown-key, missing-'=', zero-value, malformed-value,
 * size-overflow, and duplicate-key rejection.
 *
 * Semantic contract mirrored: ngx_http_markdown_limits parses space-separated
 * key=value tokens (memory|timeout|streaming_buffer|max_inflight), writes the
 * corresponding backing field, and rejects duplicates/unknown/zero/malformed
 * values at parse time.
 *
 * Return: void.  Side effects: asserts on mcf fields.
 */
static void
test_limits_handler(void)
{
    ngx_conf_t               cf;
    ngx_array_t              args;
    ngx_str_t                values[5];
    ngx_command_t            cmd;
    ngx_http_markdown_conf_t mcf;
    const char              *rc;

    TEST_SUBSECTION("limits handler");

    set_arg(&cmd.name, "markdown_limits");

    /* All eight keys (testing a subset of 4 here). */
    init_conf(&mcf);
    setup_cf(&cf, &args, values, 5);
    set_arg(&values[0], "markdown_limits");
    set_arg(&values[1], "conversion_memory=8m");
    set_arg(&values[2], "conversion_timeout=2s");
    set_arg(&values[3], "streaming_buffer=256k");
    set_arg(&values[4], "max_inflight=64");
    rc = ngx_http_markdown_limits(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "full limits should parse");
    TEST_ASSERT(mcf.limits.conversion_memory == 8 * 1024 * 1024,
        "conversion_memory maps to limits.conversion_memory");
    TEST_ASSERT(mcf.limits.conversion_timeout == 2000,
        "conversion_timeout=2s maps to 2000ms");
    TEST_ASSERT(mcf.limits.streaming_buffer == 256 * 1024,
        "streaming_buffer maps to limits.streaming_buffer");
    TEST_ASSERT(mcf.limits.max_inflight == 64, "max_inflight maps");

    /* Single-key tests reuse a 2-arg layout. */
    setup_cf(&cf, &args, values, 2);
    set_arg(&values[0], "markdown_limits");

    init_conf(&mcf);
    set_arg(&values[1], "conversion_timeout=500ms");
    rc = ngx_http_markdown_limits(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "ms timeout should parse");
    TEST_ASSERT(mcf.limits.conversion_timeout == 500,
        "conversion_timeout=500ms maps to 500");

    init_conf(&mcf);
    set_arg(&values[1], "bogus=1");
    rc = ngx_http_markdown_limits(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "unknown key should fail");

    init_conf(&mcf);
    set_arg(&values[1], "conversion_memory");
    rc = ngx_http_markdown_limits(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "missing '=' should fail");

    init_conf(&mcf);
    set_arg(&values[1], "conversion_memory=0");
    rc = ngx_http_markdown_limits(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "zero conversion_memory should fail");

    init_conf(&mcf);
    set_arg(&values[1], "max_inflight=0");
    rc = ngx_http_markdown_limits(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "zero max_inflight should fail (must be > 0)");

    init_conf(&mcf);
    set_arg(&values[1], "conversion_memory=bad");
    rc = ngx_http_markdown_limits(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "malformed memory should fail");

    init_conf(&mcf);
    {
        char overflow_token[50];
        size_t overflow_value;

        overflow_value = (NGX_MAX_SIZE_T_VALUE
                          / ((size_t) 1024 * 1024 * 1024)) + 1;
        snprintf(overflow_token, sizeof(overflow_token),
            "conversion_memory=%zuG", overflow_value);
        set_arg(&values[1], overflow_token);
        rc = ngx_http_markdown_limits(&cf, &cmd, &mcf);
        TEST_ASSERT(rc == NGX_CONF_ERROR,
            "overflow memory token should fail");
    }

    /* Duplicate key within one directive. */
    init_conf(&mcf);
    setup_cf(&cf, &args, values, 3);
    set_arg(&values[0], "markdown_limits");
    set_arg(&values[1], "conversion_memory=8m");
    set_arg(&values[2], "conversion_memory=4m");
    rc = ngx_http_markdown_limits(&cf, &cmd, &mcf);
    TEST_ASSERT(strcmp(rc,
        "has a duplicate \"conversion_memory\" key") == 0,
        "duplicate conversion_memory key should fail");

    TEST_PASS("limits branches covered");
}

/*
 * Verify metrics_format and metrics directive handlers: valid
 * formats, invalid format, handler installation, and duplicate
 * content handler.
 *
 * Semantic contract mirrored: ngx_http_markdown_metrics_format
 * maps format tokens to enum values; ngx_http_markdown_metrics_directive
 * installs the metrics content handler in the core location
 * configuration and rejects duplicates.
 *
 * Return: void.
 *
 * Side effects: modifies g_clcf; asserts on mcf.ops.metrics_format
 *               and clcf.handler.
 */
static void
test_metrics_handlers(void)
{
    ngx_conf_t                 cf;
    ngx_array_t                args;
    ngx_str_t                  values[2];
    ngx_command_t              cmd;
    ngx_http_markdown_conf_t   mcf;
    ngx_http_core_loc_conf_t   clcf;
    const char                *rc;

    TEST_SUBSECTION("metrics handlers");

    setup_cf(&cf, &args, values, 2);

    init_conf(&mcf);
    set_arg(&cmd.name, "markdown_metrics");

    g_clcf = NULL;
    rc = ngx_http_markdown_metrics_directive(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "missing core loc conf should fail");

    memset(&clcf, 0, sizeof(clcf));
    g_clcf = &clcf;
    rc = ngx_http_markdown_metrics_directive(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK,
        "metrics directive should install handler");
    TEST_ASSERT(clcf.handler == ngx_http_markdown_metrics_handler,
        "metrics handler should be registered");

    init_conf(&mcf);
    rc = ngx_http_markdown_metrics_directive(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "duplicate content handler should fail");

    g_clcf = NULL;

    TEST_PASS("metrics handler branches covered");
}


/*
 * Verify v0.8.0 streaming directive handlers that live in the production
 * handler header: threshold, flush_min, and excluded_types.
 *
 * Return: void.
 *
 * Side effects: allocates test arrays via the local ngx_array_create stub.
 */
static void
test_v080_stream_directive_handlers(void)
{
    ngx_conf_t               cf;
    ngx_array_t              args;
    ngx_str_t                values[3];
    ngx_command_t            cmd;
    ngx_http_markdown_conf_t mcf;
    const ngx_str_t         *types;
    const char              *rc;

    TEST_SUBSECTION("v0.8 stream directive handlers");

    setup_cf(&cf, &args, values, 2);

    init_conf(&mcf);
    setup_cf(&cf, &args, values, 3);
    set_arg(&cmd.name, "markdown_stream_excluded_types");
    set_arg(&values[0], "markdown_stream_excluded_types");
    set_arg(&values[1], "text/event-stream");
    set_arg(&values[2], "application/x-ndjson");
    rc = ngx_http_markdown_stream_excluded_types_handler(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "stream excluded_types should parse");
    TEST_ASSERT(mcf.stream.excluded_types != NULL,
        "stream excluded_types should allocate array");
    TEST_ASSERT(mcf.stream.excluded_types->nelts == 2,
        "stream excluded_types should store both values");

    types = mcf.stream.excluded_types->elts;
    TEST_ASSERT(types != NULL, "excluded type entries should be available");
    TEST_ASSERT(types[0].len == strlen("text/event-stream"),
        "first excluded type length should match");
    TEST_ASSERT(memcmp(types[0].data, "text/event-stream",
                       types[0].len) == 0,
        "first excluded type value should match");

    TEST_PASS("v0.8 stream directive handler branches covered");
}

/*
 * Verify ngx_http_markdown_parse_size edge cases: NULL input,
 * oversized input, negative input, and bare number (no suffix).
 *
 * Semantic contract mirrored: parse_size returns (size_t) NGX_ERROR
 * for NULL/empty/oversized inputs, and returns the raw value when
 * no suffix is present (default case in suffix switch).
 *
 * Return: void.
 *
 * Side effects: none (assertions only).
 */
static void
test_parse_size_edge_cases(void)
{
    ngx_str_t line;
    size_t    result;

    TEST_SUBSECTION("parse_size edge cases");

    line.data = NULL;
    line.len = 0;
    result = ngx_http_markdown_parse_size(&line);
    TEST_ASSERT(result == (size_t) NGX_ERROR,
        "NULL data should return NGX_ERROR");

    line.data = (u_char *) "123";
    line.len = 0;
    result = ngx_http_markdown_parse_size(&line);
    TEST_ASSERT(result == (size_t) NGX_ERROR,
        "zero length should return NGX_ERROR");

    {
        volatile u_char long_buf[128];
        line.data = (u_char *) long_buf;
        line.len = sizeof(long_buf) - 1;
        memset((u_char *) long_buf, '1', sizeof(long_buf) - 1);
        ((u_char *) long_buf)[sizeof(long_buf) - 1] = '\0';
        result = ngx_http_markdown_parse_size(&line);
        TEST_ASSERT(result == (size_t) NGX_ERROR,
            "oversized input should return NGX_ERROR");
    }

    {
        u_char max_valid_buf[64];
        line.data = max_valid_buf;
        line.len = sizeof(max_valid_buf) - 1;
        memset(max_valid_buf, ' ', sizeof(max_valid_buf) - 3);
        max_valid_buf[sizeof(max_valid_buf) - 3] = '1';
        max_valid_buf[sizeof(max_valid_buf) - 2] = 'k';
        result = ngx_http_markdown_parse_size(&line);
        TEST_ASSERT(result == 1024,
            "max valid length input (63 bytes, leading spaces + \"1k\") should parse as 1024");
    }

    set_arg(&line, "2048");
    result = ngx_http_markdown_parse_size(&line);
    TEST_ASSERT(result == 2048,
        "bare number (no suffix) should return value directly");

    set_arg(&line, "0");
    result = ngx_http_markdown_parse_size(&line);
    TEST_ASSERT(result == 0,
        "zero value should parse");

    set_arg(&line, "-2");
    result = ngx_http_markdown_parse_size(&line);
    TEST_ASSERT(result == (size_t) NGX_ERROR,
        "negative bare size should return NGX_ERROR");

    set_arg(&line, " -2k");
    result = ngx_http_markdown_parse_size(&line);
    TEST_ASSERT(result == (size_t) NGX_ERROR,
        "negative suffixed size with leading space should return NGX_ERROR");

    set_arg(&line, "   ");
    result = ngx_http_markdown_parse_size(&line);
    TEST_ASSERT(result == (size_t) NGX_ERROR,
        "all-whitespace input should return NGX_ERROR (empty after trim)");

    set_arg(&line, "   abc");
    result = ngx_http_markdown_parse_size(&line);
    TEST_ASSERT(result == (size_t) NGX_ERROR,
        "whitespace followed by non-digits should return NGX_ERROR");

    set_arg(&line, "   12abc");
    result = ngx_http_markdown_parse_size(&line);
    TEST_ASSERT(result == (size_t) NGX_ERROR,
        "digits followed by non-numeric trailing should return NGX_ERROR");

    TEST_PASS("parse_size edge cases covered");
}

/*
 * Verify ngx_http_markdown_filter palloc failure path.
 *
 * Simulates pool allocation failure by setting a flag that makes
 * ngx_palloc return NULL for the next call, covering the error
 * branch in the filter handler.
 *
 * Return: void.
 *
 * Side effects: modifies g_next_palloc_fails; asserts on return code.
 */
static void
test_markdown_filter_palloc_failure(void)
{
    ngx_conf_t               cf;
    ngx_array_t              args;
    ngx_str_t                values[2];
    ngx_command_t            cmd;
    ngx_http_markdown_conf_t mcf;
    const char              *rc;

    TEST_SUBSECTION("markdown_filter palloc failure");

    init_conf(&mcf);
    setup_cf(&cf, &args, values, 2);
    set_arg(&cmd.name, "markdown_filter");
    set_arg(&values[0], "markdown_filter");
    set_arg(&values[1], "$var");

    g_compile_complex_rc = NGX_OK;
    g_next_palloc_fails = 1;
    rc = ngx_http_markdown_filter(&cf, &cmd, &mcf);
    g_next_palloc_fails = 0;
    TEST_ASSERT(rc == NGX_CONF_ERROR,
        "palloc failure should return NGX_CONF_ERROR");

    TEST_PASS("markdown_filter palloc failure covered");
}

/*
 * Verify ngx_http_markdown_set_dynconf_path: normal path,
 * empty value, duplicate rejection, and command-context lookup.
 *
 * Semantic contract mirrored: set_dynconf_path sets mcf->advanced.advanced.dynconf_path,
 * records the path in main_conf for duplicate detection, and returns
 * NGX_CONF_ERROR on duplicate or invalid inputs.
 *
 * Return: void.
 *
 * Side effects: modifies g_main_conf; asserts on mcf and mmcf fields.
 */
static void
test_set_dynconf_path(void)
{
    ngx_conf_t                 cf;
    ngx_array_t                args;
    ngx_str_t                  values[2];
    ngx_command_t              cmd;
    ngx_http_markdown_conf_t   mcf;
    ngx_http_markdown_conf_t   duplicate_mcf;
    const char                *rc;

    TEST_SUBSECTION("set_dynconf_path handler");

    memset(&g_main_conf, 0, sizeof(g_main_conf));
    init_conf(&mcf);
    g_module_loc_conf = &mcf;
    setup_cf(&cf, &args, values, 2);
    set_arg(&cmd.name, "markdown_dynamic_config_path");
    set_arg(&values[0], "markdown_dynamic_config_path");
    set_arg(&values[1], "/etc/nginx/dynconf.conf");

    rc = ngx_http_markdown_set_dynconf_path(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "valid path should parse");
    TEST_ASSERT(mcf.advanced.dynconf_path.len == strlen("/etc/nginx/dynconf.conf"),
                "dynconf_path stored in loc conf");
    TEST_ASSERT(g_main_conf.dynconf_path_configured == 1,
                "main conf marked as configured");
    TEST_ASSERT(g_main_conf.dynconf_first_path.len > 0,
                "first path recorded in main conf");
    TEST_ASSERT(g_main_conf.dynconf_owner_conf == &mcf,
                "main conf should retain the path owner config");

    /* Duplicate should fail */
    init_conf(&duplicate_mcf);
    rc = ngx_http_markdown_set_dynconf_path(&cf, &cmd, &duplicate_mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
                "duplicate path should be rejected");
    TEST_ASSERT(g_main_conf.dynconf_owner_conf == &mcf,
                "duplicate path must not replace the original owner");

    /* Empty value should succeed (no-op) */
    memset(&g_main_conf, 0, sizeof(g_main_conf));
    init_conf(&mcf);
    set_arg(&values[1], "");
    rc = ngx_http_markdown_set_dynconf_path(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK,
                "empty value should return OK (no-op)");

    /* The H-only command receives main-conf storage; the handler resolves
     * the location snapshot from the configuration context. */
    memset(&g_main_conf, 0, sizeof(g_main_conf));
    init_conf(&mcf);
    set_arg(&values[1], "/etc/nginx/dynconf.conf");
    rc = ngx_http_markdown_set_dynconf_path(&cf, &cmd, NULL);
    TEST_ASSERT(rc == NGX_CONF_OK,
                "handler should resolve H-only loc conf from context");

    g_module_loc_conf = NULL;
    TEST_PASS("set_dynconf_path branches covered");
}

/*
 * Verify diagnostics directive handler: on/off, invalid value,
 * handler installation, and duplicate content handler.
 */
static void
test_diagnostics_handler(void)
{
    ngx_conf_t                 cf;
    ngx_array_t                args;
    ngx_str_t                  values[2];
    ngx_command_t              cmd;
    ngx_http_markdown_conf_t   mcf;
    ngx_http_core_loc_conf_t   clcf;
    const char                *rc;

    TEST_SUBSECTION("diagnostics handler");

    setup_cf(&cf, &args, values, 2);
    set_arg(&cmd.name, "markdown_diagnostics");
    set_arg(&values[0], "markdown_diagnostics");

    /* Test "on" value */
    init_conf(&mcf);
    memset(&clcf, 0, sizeof(clcf));
    g_diagnostics_recording_requested = 0;
    g_clcf = &clcf;
    set_arg(&values[1], "on");
    rc = ngx_http_markdown_diagnostics_directive(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "on should parse");
    TEST_ASSERT(mcf.ops.diagnostics_enabled == 1, "diagnostics should be enabled");
    TEST_ASSERT(clcf.handler == ngx_http_markdown_diagnostics_handler,
        "diagnostics handler should be registered");
    TEST_ASSERT(g_diagnostics_recording_requested == 1,
        "diagnostics on should request decision recording");

    /* Duplicate handler should fail */
    rc = ngx_http_markdown_diagnostics_directive(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "duplicate handler should fail");

    /* Test "off" value */
    init_conf(&mcf);
    set_arg(&values[1], "off");
    rc = ngx_http_markdown_diagnostics_directive(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "off should parse");
    TEST_ASSERT(mcf.ops.diagnostics_enabled == 0, "diagnostics should be disabled");

    /* Test invalid value */
    init_conf(&mcf);
    set_arg(&values[1], "invalid");
    rc = ngx_http_markdown_diagnostics_directive(&cf, &cmd, &mcf);
    TEST_ASSERT(rc != NGX_CONF_OK, "invalid value should fail");

    /* Test NULL clcf */
    init_conf(&mcf);
    g_clcf = NULL;
    set_arg(&values[1], "on");
    rc = ngx_http_markdown_diagnostics_directive(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "NULL clcf should fail");

    g_clcf = NULL;

    TEST_PASS("diagnostics handler branches covered");
}

/*
 * Verify content_types handler validation: empty type, no slash,
 * leading slash, trailing slash, multiple slashes.
 */
static void
test_content_types_validation(void)
{
    ngx_conf_t               cf;
    ngx_array_t              args;
    ngx_str_t                values[2];
    ngx_command_t            cmd;
    ngx_http_markdown_conf_t mcf;
    const char              *rc;

    TEST_SUBSECTION("content_types validation");

    setup_cf(&cf, &args, values, 2);
    set_arg(&cmd.name, "markdown_content_types");
    set_arg(&values[0], "markdown_content_types");

    /* Empty type should fail */
    init_conf(&mcf);
    set_arg(&values[1], "");
    rc = ngx_http_markdown_content_types(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "empty content type should fail");

    /* No slash should fail */
    init_conf(&mcf);
    set_arg(&values[1], "texthtml");
    rc = ngx_http_markdown_content_types(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "no slash should fail");

    /* Leading slash should fail */
    init_conf(&mcf);
    set_arg(&values[1], "/html");
    rc = ngx_http_markdown_content_types(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "leading slash should fail");

    /* Trailing slash should fail */
    init_conf(&mcf);
    set_arg(&values[1], "text/");
    rc = ngx_http_markdown_content_types(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "trailing slash should fail");

    /* Multiple slashes should fail */
    init_conf(&mcf);
    set_arg(&values[1], "text/html/xml");
    rc = ngx_http_markdown_content_types(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "multiple slashes should fail");

    TEST_PASS("content_types validation branches covered");
}

static void
test_markdown_content_types_handler(void)
{
    ngx_conf_t               cf;
    ngx_array_t              args;
    ngx_str_t                values[3];
    ngx_command_t            cmd;
    ngx_http_markdown_conf_t mcf;
    const ngx_str_t         *types;
    const char              *rc;

    TEST_SUBSECTION("markdown_content_types handler");

    init_conf(&mcf);
    setup_cf(&cf, &args, values, 3);
    set_arg(&cmd.name, "markdown_content_types");
    set_arg(&values[0], "markdown_content_types");
    set_arg(&values[1], "text/html");
    set_arg(&values[2], "application/xhtml+xml");

    rc = ngx_http_markdown_content_types(&cf, &cmd, &mcf);
    TEST_ASSERT(rc == NGX_CONF_OK, "valid content types should parse");
    TEST_ASSERT(mcf.routing.content_types != NULL,
        "content_types array allocated");
    TEST_ASSERT(mcf.routing.content_types->nelts == 2,
        "two content types stored");

    types = mcf.routing.content_types->elts;
    TEST_ASSERT(types != NULL, "content_types entries should be available");
    TEST_ASSERT(types[0].len == strlen("text/html"),
                "first content type length should match");
    TEST_ASSERT(memcmp(types[0].data, "text/html", types[0].len) == 0,
                "first content type value should match");
    TEST_ASSERT(types[1].len == strlen("application/xhtml+xml"),
                "second content type length should match");
    TEST_ASSERT(memcmp(types[1].data, "application/xhtml+xml", types[1].len) == 0,
                "second content type value should match");

    rc = ngx_http_markdown_content_types(&cf, &cmd, &mcf);
    TEST_ASSERT(strcmp(rc, "is duplicate") == 0,
                "duplicate content_types should be rejected");

    TEST_PASS("content_types branches covered");
}

/*
 * spec 47: markdown_trusted_proxies directive handler.
 *
 * Covers the C thin-wrapper golden errors and marshaling: http-only context
 * enforcement, "off", duplicate detection, valid CIDR push, and invalid-CIDR
 * rejection.  The CIDR parsing itself lives in Rust (covered by Rust tests);
 * here the FFI is stubbed so only the C wrapper behavior is exercised.
 */
static void
test_trusted_proxies_handler(void)
{
    ngx_command_t cmd;
    ngx_conf_t    cf;
    ngx_array_t   args;
    ngx_str_t     values[3];
    char         *rc;

    TEST_SUBSECTION("markdown_trusted_proxies directive handler");

    set_arg(&cmd.name, "markdown_trusted_proxies");

    /* http context, valid IPv4 + IPv6 CIDRs -> OK, pushes both. */
    memset(&g_main_conf, 0, sizeof(g_main_conf));
    g_trusted_push_rc = TRUSTED_PROXIES_PUSH_OK;
    g_trusted_push_calls = 0;
    set_arg(&values[0], "markdown_trusted_proxies");
    set_arg(&values[1], "10.0.0.0/8");
    set_arg(&values[2], "2001:db8::/32");
    setup_cf(&cf, &args, values, 3);
    cf.cmd_type = NGX_HTTP_MAIN_CONF;
    rc = ngx_http_markdown_trusted_proxies(&cf, &cmd, &g_main_conf);
    TEST_ASSERT(rc == NGX_CONF_OK, "valid CIDRs in http context should pass");
    TEST_ASSERT(g_main_conf.trusted_proxies_configured == 1,
                "configured flag should be set");
    TEST_ASSERT(g_main_conf.trusted_proxies != NULL,
                "handle should be stored for non-off config");
    TEST_ASSERT(g_trusted_push_calls == 2, "both CIDRs should be pushed");

    /* server/location context -> golden error. */
    memset(&g_main_conf, 0, sizeof(g_main_conf));
    setup_cf(&cf, &args, values, 2);
    cf.cmd_type = NGX_HTTP_SRV_CONF;
    g_conf_log_buf[0] = '\0';
    rc = ngx_http_markdown_trusted_proxies(&cf, &cmd, &g_main_conf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
                "server context should be rejected");
    TEST_ASSERT(strstr(g_conf_log_buf, "only valid in the http context")
                != NULL,
                "server rejection should explain the http-only contract");
    cf.cmd_type = NGX_HTTP_LOC_CONF;
    g_conf_log_buf[0] = '\0';
    rc = ngx_http_markdown_trusted_proxies(&cf, &cmd, &g_main_conf);
    TEST_ASSERT(rc == NGX_CONF_ERROR,
                "location context should be rejected");
    TEST_ASSERT(strstr(g_conf_log_buf, "only valid in the http context")
                != NULL,
                "location rejection should explain the http-only contract");

    /* "off" -> configured, no handle. */
    memset(&g_main_conf, 0, sizeof(g_main_conf));
    set_arg(&values[1], "off");
    setup_cf(&cf, &args, values, 2);
    cf.cmd_type = NGX_HTTP_MAIN_CONF;
    rc = ngx_http_markdown_trusted_proxies(&cf, &cmd, &g_main_conf);
    TEST_ASSERT(rc == NGX_CONF_OK, "\"off\" should pass");
    TEST_ASSERT(g_main_conf.trusted_proxies_configured == 1,
                "\"off\" should set configured flag");
    TEST_ASSERT(g_main_conf.trusted_proxies == NULL,
                "\"off\" should not store a handle");

    /* duplicate -> error. */
    set_arg(&values[1], "10.0.0.0/8");
    setup_cf(&cf, &args, values, 2);
    cf.cmd_type = NGX_HTTP_MAIN_CONF;
    rc = ngx_http_markdown_trusted_proxies(&cf, &cmd, &g_main_conf);
    TEST_ASSERT(rc != NGX_CONF_OK, "duplicate directive should be rejected");

    /* invalid CIDR -> golden error (push returns INVALID_CIDR). */
    memset(&g_main_conf, 0, sizeof(g_main_conf));
    g_trusted_push_rc = TRUSTED_PROXIES_PUSH_INVALID_CIDR;
    set_arg(&values[1], "not-a-cidr");
    setup_cf(&cf, &args, values, 2);
    cf.cmd_type = NGX_HTTP_MAIN_CONF;
    rc = ngx_http_markdown_trusted_proxies(&cf, &cmd, &g_main_conf);
    TEST_ASSERT(rc == NGX_CONF_ERROR, "invalid CIDR should be rejected");

    g_trusted_push_rc = TRUSTED_PROXIES_PUSH_OK;

    TEST_PASS("markdown_trusted_proxies handler correct");
}


/*
 * Entry point: run all config_handlers_impl unit tests.
 *
 * Return: 0 on success (all assertions pass).
 *
 * Side effects: writes test progress to stdout.
 */
int
main(void)
{
    printf("\n========================================\n");
    printf("config_handlers_impl Tests\n");
    printf("========================================\n");

    g_compile_complex_rc = NGX_OK;
    memset(&g_main_conf, 0, sizeof(g_main_conf));

    test_arg_equals();
    test_markdown_filter_handler();
    test_markdown_filter_non_nul_terminated();
    test_simple_enum_handlers();
    test_auth_cookies_handler();
    test_conditional_and_log_verbosity_handlers();
    test_streaming_policy_handler();
    test_limits_handler();
    test_metrics_handlers();
    test_v080_stream_directive_handlers();
    test_parse_size_edge_cases();
    test_markdown_filter_palloc_failure();
    test_set_dynconf_path();
    test_diagnostics_handler();
    test_content_types_validation();
    test_markdown_content_types_handler();
    test_trusted_proxies_handler();

    printf("\n========================================\n");
    printf("All tests passed!\n");
    printf("========================================\n\n");

    return 0;
}
