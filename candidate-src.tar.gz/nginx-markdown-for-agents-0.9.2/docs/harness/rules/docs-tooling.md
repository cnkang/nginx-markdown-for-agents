---
domain: docs-tooling
rules: [9, 49]
paths:
  - "docs/**"
  - "tools/**"
  - "README.md"
  - "INSTALLATION.md"
  - "THIRD-PARTY-NOTICES"
---

## Docs & Tooling Drift

### 9. Docs/tooling drift (README vs INSTALLATION vs validators)
Historical issues: `726865e`, `2b0bd5d`, `83eca29`, `18dfb8c`, `4b2b761`, `09f5d1d`.

Required:
- Keep Quick Start, installation guide, and packaging validators semantically consistent.
- Validation scripts must compare the same scope/section intended by spec (for example Shortest Success Path).
- Handle duplicates/order mismatches explicitly with actionable diagnostics.
- Avoid false positives by preserving meaningful URL path semantics in curl checks.
- Metric names documented in tables/examples must match emitted JSON keys and
  Prometheus series names exactly (no synthetic prefixes or renamed aliases).
- Operator-facing docs (cookbooks, rollout guides) that reference metrics must
  use the exact retrievable key path or series name.  For JSON, use the nested
  object path (for example `streaming.postcommit_error_total`).  For
  Prometheus, use the full series name with labels (for example
  `nginx_markdown_streaming_total{result="postcommit_error"}`).  Do not invent
  flat metric names that do not exist in any output format.
- When docs reference derived rates (for example `shadow_diff_rate`), include
  the computation formula using real metric names so operators can reproduce
  the calculation (for example `shadow_diff_total / shadow_total`).  Verify
  that the denominator is scoped to the same population as the numerator —
  using a global request count as denominator for a streaming-only failure
  count will dilute the rate during partial rollout and mask real problems.
- Verification commands in operator docs (curl + grep/jq/python) must specify
  an explicit `Accept` header matching the output format they parse.  The
  default plain-text format uses human-readable labels that differ from JSON
  keys and Prometheus series names; omitting `Accept` causes false negatives
  when grepping for snake_case keys.
- `tools/harness/detect_doc_sync.py` owns the blocking v0.9.1 public-config
  drift contract. It reads the current worktree directly, including untracked
  files under the owned production/example/E2E/Sonar surfaces. It verifies the
  active `markdown_streaming` registration, reject-only
  `markdown_streaming_engine` stub, Helm `markdown.streaming.mode` mapping,
  removal of production `stream.engine`/`STREAM_ENGINE` symbols, the
  commonmark/gfm-only flavor contract with explicit mdx/org-mode rejection,
  and the exact off-to-off, auto-to-auto, on-to-force migration table.
- This detector is blocking in the existing CI docs job through
  `make docs-check` and also runs through `make harness-security-checks`; its
  positive and negative fixtures run through `make test-harness`.

### 49. THIRD-PARTY-NOTICES drift with dependency changes
Required:
- When any dependency is added, removed, or has its version changed (in
  Cargo.toml, Cargo.lock, or C/NGINX build files), the corresponding entry
  in `THIRD-PARTY-NOTICES` must be updated in the same changeset.
- Version numbers in THIRD-PARTY-NOTICES must match the resolved versions in
  `Cargo.lock` (not the semver range in Cargo.toml).
- New dependencies must be added with correct license type, copyright notice,
  and license text. Removed dependencies must be deleted.
- Verify with: `diff <(grep '^version =' Cargo.lock) <(grep '[0-9]\+\.[0-9]\+' THIRD-PARTY-NOTICES)`
